// Copyright 2021-2023 SICK AG. All rights reserved.
#pragma once

#include "CushionWinHeaders.h"
#include "GenIStreamDll.h"
#include <GenApi/Synch.h>

namespace genistream {

/**
 * A mutex to lock a \ref NodeMap for exclusive access by a single thread. The
 * mutex works in a re-entrant fashion, i.e., a thread can lock the mutex while
 * already having the lock, without causing deadlock.
 *
 * The GenApi node map, which is wrapped in \ref NodeMap, internally has a
 * `GenApi::CLock` object which works as a mutex. This class acts as a wrapper
 * around such object to fulfill the C++ standard requirements of being
 * "Lockable". This is to be able to use std::lock_guard, std::unique_lock and
 * similar, in a RAII fashion rather than explicitly calling functions to lock
 * and unlock.
 */
class GENISTREAM_API NodeMapMutex
{
public:
  NodeMapMutex(const NodeMapMutex&) = delete;
  NodeMapMutex& operator=(const NodeMapMutex&) = delete;

  bool try_lock() { return mLock.TryLock(); }
  void lock() { mLock.Lock(); }
  void unlock() { mLock.Unlock(); }

private:
  friend class NodeMap;
  friend class NodeInvalidationDispatcher;
  explicit NodeMapMutex(GenApi::CLock& lock)
    : mLock(lock)
  {
  }

private:
  GenApi::CLock& mLock;
};

}
