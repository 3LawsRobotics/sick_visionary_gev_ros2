// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include "IDeviceInfo.h"

#include "../../public/gentlcpp/CApi.h"
#include "../genistream/GenIStreamDll.h"

namespace genistream {
class CameraDiscoveryTest;
}

namespace gentlcpp {

class Interface;
class CApi;

class GENISTREAM_API DeviceInfo : public IDeviceInfo
{
public:
  DeviceInfo(const DeviceInfo&) = delete;
  ~DeviceInfo() noexcept override;

  DeviceId getId() const override;
  std::string getVendor() const override;
  std::string getModel() const override;
  std::string getTransportLayerType() const override;
  std::string getDisplayName() const override;
  GenTL::DEVICE_ACCESS_STATUS_LIST getAccessStatus() const override;
  std::string getUserDefinedName() const override;
  std::string getSerialNumber() const override;
  std::string getVersion() const override;

  template<typename T>
  T getInfo(GenTL::DEVICE_INFO_CMD_LIST command) const
  {
    T value;
    size_t size = sizeof(T);
    GenTL::INFO_DATATYPE dataType;
    ThrowIfError(mCApi,
                 mCApi->IFGetDeviceInfo(getParentHandle(),
                                        getId().c_str(),
                                        command,
                                        &dataType,
                                        &value,
                                        &size));
    return value;
  }

  template<typename T>
  T getInfo(uint32_t customCommand) const
  {
    return getInfo<T>(static_cast<GenTL::DEVICE_INFO_CMD_LIST>(customCommand));
  }

  uint32_t getInfoUint32(uint32_t customCommand) override;
  uint64_t getInfoUint64(uint32_t customCommand) override;

  std::shared_ptr<IInterface> getParent() override;

#ifdef SWIG
    EXPLODE_TEMPLATE_TYPES(getInfo);
#endif

private:
  friend class Interface;
  friend class genistream::CameraDiscoveryTest;

  DeviceInfo(std::shared_ptr<const CApi> cApi,
             std::shared_ptr<Interface> iface,
             const DeviceId& deviceId);

  GenTL::IF_HANDLE getParentHandle() const;

private:
  std::shared_ptr<const CApi> mCApi;
  std::shared_ptr<Interface> mParent;
  DeviceId mDeviceId;
};

/* (explicit specialization has to be declared in a scope where primary template can be defined) */
template<>
std::string DeviceInfo::getInfo(GenTL::DEVICE_INFO_CMD_LIST command) const;

}
