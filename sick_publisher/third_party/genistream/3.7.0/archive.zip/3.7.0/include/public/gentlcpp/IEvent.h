// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "Exception.h"
#include "../genistream/GenIStreamDll.h"

#include <TLI/GenTL.h>

#include <chrono>
#include <memory>

namespace gentlcpp {

class IModule;

/** Common event reading outcomes that are not exceptional in any way. */
enum class ResultStatus
{
  SUCCESS,
  TIMED_OUT,
  ABORTED
};

/** Returns the buffer size filled in event data retrieval. */
struct EventResult
{
  ResultStatus status;
  size_t filledBufferSize;
};


/**
 * Instances of this interface represent a specific GenTL event type. To get
 * notified when an event is signaled the \ref IEvent::getData() function should
 * be called.
 *
 * Event objects can be retrieved from the corresponding module object, for
 * instance, \ref IDevice::registerEvent().
 */
class GENISTREAM_API IEvent
{
public:
  virtual ~IEvent() noexcept = default;

  virtual void unregister() = 0;
  virtual void flush() = 0;
  virtual GenTL::EVENT_HANDLE getHandle() = 0;
  virtual std::shared_ptr<const IModule> getParentModule() const = 0;

  /**
   * Wait for the event and fill pOutBuffer with the returned event data.
   *
   * \return the number of bytes that were written to pOutBuffer
   */
  virtual EventResult getData(void* pOutBuffer,
                              size_t bufferSize,
                              std::chrono::milliseconds timeout) const = 0;

  /**
   * Wait for the event with an infinite timeout and fill pOutBuffer with the
   * returned event data.
   *
   * \return the number of bytes that were written to pOutBuffer
   */
  virtual EventResult getData(void* pOutBuffer, size_t bufferSize) const = 0;

  virtual GenTL::EVENT_TYPE_LIST getEventType() const = 0;
  virtual size_t getQueuedCount() const = 0;
  virtual uint64_t getFiredCount() const = 0;
  virtual size_t getMaxSize() const = 0;
  virtual size_t getInfoDataMaxSize() const = 0;
  virtual uint64_t getDataNumericId(const void* pEventBuffer,
                                    size_t eventBufferSize) const = 0;
};

}
