// Copyright 2021-2023 SICK AG. All rights reserved.
#pragma once

#include "genistream/GenIStreamDll.h"
#include "IAdditionalInfoBuilder.h"

#include <sstream>

namespace gentlcpp {
class IDevice;
class ITransportLayer;
}

namespace genistream {
class IAnyParameters;
class ICamera;
namespace frame {

/**
 * Concrete implementation of \ref IAdditionalInfoBuilder.
 *
 * \lowlevel Prefer using \ref ICamera::createFrameGrabber() since it creates
 *           instance for you to be used by the \ref FrameGrabber returned.
 */
class GENISTREAM_API AdditionalInfoBuilder : public IAdditionalInfoBuilder
{
public:
  /**
   * \param infoToAdd controls which info is actually added to the XML string.
   */
  AVOID AdditionalInfoBuilder(AdditionalInfo infoToAdd);

  AVOID void setAcquisitionStartTime() override;
  AVOID void setGrabTime() override;
  AVOID void setDataStreamStatistics(
    std::shared_ptr<IAnyParameters> dataStreamParameters) override;
  AVOID std::string getXml() const override;

  /** Adds information on the GenTL producer. */
  AVOID void addGenTlProducerInfo(
    std::shared_ptr<gentlcpp::ITransportLayer> transportLayer);
  /**
   * Adds information on the device from GenTL, e.g., model and serial number.
   */
  AVOID void addDeviceInfo(std::shared_ptr<gentlcpp::IDevice> device);
  /**
   * Adds information on the device from camera parameters, e.g., firmware
   * version and current boot path.
   */
  AVOID void
  addDeviceInfoFromParameters(std::shared_ptr<IAnyParameters> parameters);
  /**
   * Adds GigE Vision information, e.g., stream channel packet size. This may
   * cause network requests.
   */
  AVOID void
  addGevInfoFromParameters(std::shared_ptr<IAnyParameters> parameters);
  /**
   * Adds the complete camera configuration, i.e., the complete set of
   * parameters, same as produced by \refcs{ICamera.ExportParametersToFile}
   * \refcpp{ICamera::exportParameters()}. This causes a lot of network requests
   * and thus takes a long time.
   */
  AVOID void addConfiguration(std::shared_ptr<ICamera> camera);

private:
  AdditionalInfo mInfoToAdd;
  std::string mAcquisitionStartTime;
  std::string mGrabTime;
  std::string mDataStreamStatistics;
  std::ostringstream mStream;

  // Allow implementation of interface functions marked as deprecated
#pragma warning(suppress : 4996)
};

}
}
