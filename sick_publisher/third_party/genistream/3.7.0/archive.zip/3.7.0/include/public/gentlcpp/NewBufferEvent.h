// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include "Event.h"
#include "INewBufferEvent.h"
#include "../genistream/GenIStreamDll.h"

#include <memory>

namespace gentlcpp {

class IModule;

/** This is a convenience class for the "new buffer event" type. */
class GENISTREAM_API NewBufferEvent : public INewBufferEvent, public Event
{
public:
  NewBufferEvent(std::shared_ptr<const CApi> cApi,
                 std::shared_ptr<const IModule> module,
                 GenTL::EVENT_TYPE_LIST eventType,
                 GenTL::EVENTSRC_HANDLE eventSrcHandle);
  ~NewBufferEvent() noexcept override;

  NewBufferEventResult
  getData(std::chrono::milliseconds timeout) const override;

  NewBufferEventResult getData() const override;

  // Allow dreaded diamond to allow interface to inherit interface
#pragma warning(suppress : 4250)
};

}
