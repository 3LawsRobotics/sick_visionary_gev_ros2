// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include "BasicTypes.h"
#include "IModule.h"
#include "../genistream/GenIStreamDll.h"

#include <chrono>
#include <memory>
#include <string>
#include <vector>

namespace gentlcpp {

class IDeviceInfo;
class IDevice;
class Port;
class ITransportLayer;

/**
 * Represents an interface in the GenTL interface module.
 *
 * \see \ref ITransportLayer::openInterface() to get an instance
 */
class GENISTREAM_API IInterface : public IModule
{
public:
  virtual std::shared_ptr<IEvent>
  registerEvent(GenTL::EVENT_TYPE_LIST eventType) override = 0;

  virtual GenTL::IF_HANDLE getHandle() = 0;
  virtual std::shared_ptr<ITransportLayer> getParent() const = 0;

  virtual bool updateDeviceList(std::chrono::milliseconds timeout) = 0;
  virtual std::vector<std::shared_ptr<IDeviceInfo>> getDevices() = 0;

  virtual std::shared_ptr<IDevice>
  openDevice(const DeviceId& deviceId,
             GenTL::DEVICE_ACCESS_FLAGS_LIST accessFlags) = 0;

  virtual DeviceId getId() const = 0;
  virtual std::string getDisplayName() const = 0;
  virtual std::string getTransportLayerType() const = 0;
  virtual std::shared_ptr<Port> getPort() = 0;
};

}
