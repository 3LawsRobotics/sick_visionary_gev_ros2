// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include "BasicTypes.h"
#include "../genistream/GenIStreamDll.h"

#include <string>

namespace gentlcpp {

/**
 * Represents information about an interface which can be retrieved without
 * being opening it.
 *
 * \see \ref ITransportLayer::getInterfaces() to get instances
 */
class GENISTREAM_API IInterfaceInfo
{
public:
  virtual ~IInterfaceInfo() noexcept = default;
  virtual InterfaceId getId() const = 0;
  virtual std::string getDisplayName() const = 0;
  virtual std::string getTransportLayerType() const = 0;
};

}
