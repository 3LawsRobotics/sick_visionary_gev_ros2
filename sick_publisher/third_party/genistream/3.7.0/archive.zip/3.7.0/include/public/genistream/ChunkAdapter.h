// Copyright 2018-2023 SICK AG. All rights reserved.
#pragma once

#include "NodeMap.h"

#include "CushionWinHeaders.h"
#include "GenIStreamDll.h"
#include <GenApi/ChunkAdapterGEV.h>

#include <memory>

namespace gentlcpp {
class IBuffer;
}

namespace genistream {

/**
 * Wrapper class for a GigE Vision chunk adapter. Creating an instance of this
 * class and attaching it to a node map and a buffer will make sure you can
 * access chunk meta data via the node map.
 *
 * \lowlevel Prefer accessing chunk metadata through \ref
 *           frame::IFrame::getLineMetadata.
 */
class GENISTREAM_API ChunkAdapter
{
public:
  /**
   * You should normally not have to use this constructor. Use \ref
   * frame::IFrame::getLineMetadata to access chunk metadata.
   *
   * \lowlevel Prefer using \ref frame::IFrame::getLineMetadata.
   */
  AVOID static std::unique_ptr<ChunkAdapter>
  create(std::shared_ptr<NodeMap> nodeMap,
         std::shared_ptr<GenApi::CChunkAdapter> adapter);

  /** Detaches any attached buffer. */
  ~ChunkAdapter();

  /**
   * Attach the chunk adapter to a specific buffer. This allows access to the
   * chunk metadata carried in the buffer.
   *
   * \throws ChunkFormatException if the chunk format is incorrect.
   */
  void attachBuffer(std::shared_ptr<gentlcpp::IBuffer> buffer);

  /**
   * Same as \ref attachBuffer but returns a boolean value indicating if the
   * chunk format was correct instead of throwing exception.
   *
   * \return false if the chunk format is incorrect
   */
  bool tryAttachBuffer(std::shared_ptr<gentlcpp::IBuffer> buffer);

  /**
   * \return the error message corresponding to the last failure of \ref
   *         tryAttachBuffer.
   */
  std::string getErrorMessage() const;

  /** Detach the from the buffer when done with it. */
  void detachBuffer();

private:
  explicit ChunkAdapter(std::shared_ptr<NodeMap> nodeMap,
                        std::shared_ptr<GenApi::CChunkAdapter> adapter);

  bool attachBufferOrMessage(std::shared_ptr<gentlcpp::IBuffer>& buffer,
                             std::string& message);

private:
  std::shared_ptr<NodeMap> mNodeMap;
  std::shared_ptr<gentlcpp::IBuffer> mBuffer;
  std::shared_ptr<GenApi::CChunkAdapter> mAdapter;
  std::string mErrorMessage;
};

}
