// Copyright 2022-2023 SICK AG. All rights reserved.
#pragma once

#include "Avoid.h"
#include "GenIStreamDll.h"
#include <memory>

namespace gentlcpp {
class IDataStream;
}

namespace genistream {

/**
 * Container for status of the buffers allocated and announced on a GenTL data
 * stream, i.e., the buffers managed by a BufferManager and in turn usually
 * handled by a \ref FrameGrabber.
 *
 * \see \refcpp{BufferManager}
 * \incubating
 */
struct GENISTREAM_API BufferStatus
{
  /** \lowlevel Prefer using \ref FrameGrabber::getBufferStatus(). */
  AVOID static BufferStatus
  createFrom(std::shared_ptr<gentlcpp::IDataStream> dataStream);

  bool operator==(const BufferStatus& other) const;
  bool operator!=(const BufferStatus& other) const
  {
    return !operator==(other);
  }

public:
  /**
   * The total amount of buffers announced on the GenTL data stream, i.e., the
   * number of buffers specified when creating your \ref FrameGrabber. This maps
   * to the GenTL::STREAM_INFO_NUM_ANNOUNCED information.
   */
  size_t totalBuffers;

  /**
   * The amount of buffers that are empty, readily available to start filling,
   * or currently being filled. In GenTL terms it is the number of queued
   * buffers in the input queue, corresponding to the
   * GenTL::STREAM_INFO_NUM_QUEUED information.
   */
  size_t availableBuffers;

  /**
   * The number of buffers filled and ready to be delivered, i.e., the number of
   * buffers you can grab with the \ref FrameGrabber without a blocking call.
   * This corresponds to the GenTL::STREAM_INFO_NUM_AWAIT_DELIVERY information.
   */
  size_t awaitingDelivery;

  /**
   * The number of buffers that have been delivered but not yet returned to be
   * re-used, i.e., the number of buffers grabbed with \ref FrameGrabber but the
   * surrounding \ref frame::IFrame has not been released. This is basically the
   * \ref totalBuffers - \ref availableBuffers - \ref awaitingDelivery.
   */
  size_t deliveredBuffers;
};

std::ostream& operator<<(std::ostream& os, const BufferStatus& status);

}
