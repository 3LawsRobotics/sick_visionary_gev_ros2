// Copyright 2022-2023 SICK AG. All rights reserved.
#pragma once

#include "ISubscription.h"
#include "genistream/Avoid.h"
#include "../GenIStreamDll.h"
#include "genistream/NodeMapMutex.h"

#include <memory>
#include <mutex>
#include <utility>

namespace genistream { namespace event {

/**
 * A wrapper class used as result type when registering subscriptions,
 * consisting of a mutex lock and a subscription object.
 *
 * To ensure that you can unsubscribe (by destroying the \ref ISubscription
 * object) within a callback function, we need to guarantee that no invocation
 * of the callback function is done until the subscription object is assigned.
 * Otherwise we risk trying to delete an unassigned subscription object. For
 * this to work we need to return a mutex lock together with the \ref
 * ISubscription object.
 *
 * As a user, you should not have to deal with this, just work with your \ref
 * ISubscription%s. Thus this interface hides the mutex lock and can be used to
 * automatically take the ownership of the \ref ISubscription.
 *
 * Avoid using `auto` when subscribing since your type will then be the envelope
 * rather than the subscription and you will hold the lock longer than
 * necessary, possibly causing delayed notifications or dead-locks.
 *
 * \code{.cpp}
 * std::unique_ptr<ISubscription> subscription = subscribeToSomething([]() {
 *     // Do something important
 *   });
 * \endcode
 *
 * Do this to be able to unsubscribe within a listener:
 *
 * \code{.cpp}
 * std::unique_ptr<ISubscription> subscription;
 * subscription = subscribeToSomething([&subscription]() {
 *     // Do something important
 *     subscription.reset();
 *   });
 * \endcode
 */
class GENISTREAM_API SubscriptionEnvelope
{
public:
  /** \internal You should never create objects of this class yourself. */
  AVOID SubscriptionEnvelope(std::unique_lock<std::recursive_mutex> lock,
                             std::unique_ptr<ISubscription> subscription);

  /** \internal You should never create objects of this class yourself. */
  AVOID SubscriptionEnvelope(std::unique_lock<NodeMapMutex> lock,
                             std::unique_ptr<ISubscription> subscription);

  SubscriptionEnvelope(SubscriptionEnvelope&& other) noexcept;

// Add extra member both when SWIG parses this header, and also when the
// generated code is compiled. This is a workaround since SWIG does not support
// move semantics.
#if defined(SWIG) || defined(SWIG_GENERATED_CODE)
  // Warning ugly hack!!!
  // Default constructor to create a dummy SubscriptionEnvelope without actual
  // subscription
  AVOID SubscriptionEnvelope()
    : mRecursiveMutexLock(std::unique_lock<std::recursive_mutex>{})
    , mSubscription(nullptr)
  {
  }
#endif

  virtual ~SubscriptionEnvelope() = default;

  /**
   * Call this function to acquire the ownership of the \ref ISubscription
   * object.
   */
  std::unique_ptr<ISubscription> acquire() { return std::move(mSubscription); }

  /**
   * Same as \ref acquire, but used to implicitly take the ownership of the \ref
   * ISubscription by type conversion.
   */
  operator std::unique_ptr<ISubscription>() { return std::move(mSubscription); }

  SubscriptionEnvelope& operator=(SubscriptionEnvelope&& other) noexcept;

  /**
   * Maps an envelope for one subscription into an envelope for a new, higher
   * level subscription. The mutex lock is transferred to the new envelope.
   *
   * \internal
   */
  AVOID SubscriptionEnvelope
  map(std::unique_ptr<ISubscription> newSubscription);

private:
  SubscriptionEnvelope(std::unique_lock<NodeMapMutex>&& nodeMapLock,
                       std::unique_lock<std::recursive_mutex>&& lock,
                       std::unique_ptr<ISubscription>&& subscription);

private:
  // The envelope will only contain a lock on one of the mutexes, but we avoided
  // making separate classes or template to keep backwards compatibility and
  // make code more readable.
  std::unique_lock<NodeMapMutex> mNodeMapMutexLock;
  std::unique_lock<std::recursive_mutex> mRecursiveMutexLock;

  std::unique_ptr<ISubscription> mSubscription;
};

}}
