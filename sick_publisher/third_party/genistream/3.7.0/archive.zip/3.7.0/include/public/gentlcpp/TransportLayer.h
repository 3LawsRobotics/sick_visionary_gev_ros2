// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include "ITransportLayer.h"

#include "../../public/gentlcpp/CApi.h"
#include "../genistream/GenIStreamDll.h"

namespace gentlcpp {

class CApi;
class Producer;

#ifdef SWIG
class GENISTREAM_API TransportLayer : public ITransportLayer
#else
class GENISTREAM_API TransportLayer : public std::enable_shared_from_this<TransportLayer>,
                       public ITransportLayer
#endif
{
public:
  TransportLayer(const TransportLayer&) = delete;
  ~TransportLayer() noexcept override;

  std::shared_ptr<IEvent> registerEvent(GenTL::EVENT_TYPE_LIST eventType)
    override;
  bool updateInterfaceList(std::chrono::milliseconds timeout) override;
  std::shared_ptr<Port> getPort() override;
  std::vector<std::shared_ptr<const IInterfaceInfo>> getInterfaces() override;
  GenTL::TL_HANDLE getHandle() override;

  std::shared_ptr<IInterface> openInterface(const InterfaceId& interfaceId)
    override;

  std::string getModel() const override;
  std::string getVersion() const override;

  template<typename T>
  T getInfo(GenTL::TL_INFO_CMD_LIST command) const
  {
    T value;
    size_t size = sizeof(T);
    GenTL::INFO_DATATYPE dataType;
    ThrowIfError(mCApi,
                 mCApi->TLGetInfo(mHandle, command, &dataType, &value, &size));
    return value;
  }

private:
  friend class Producer;

  TransportLayer(std::shared_ptr<const CApi> cApi,
                 std::shared_ptr<Producer> producer);

  std::vector<InterfaceId> getInterfaceList() const;
  InterfaceId getInterfaceId(uint32_t index) const;

private:
  std::shared_ptr<const CApi> mCApi;
  // Hold a reference to parent to make sure objects are destructed in correct
  // order
  std::shared_ptr<const Producer> mParent;
  GenTL::TL_HANDLE mHandle;
};

/* (explicit specialization has to be declared in a scope where primary template can be defined) */
template<>
std::string TransportLayer::getInfo(GenTL::TL_INFO_CMD_LIST command) const;

}
