// Copyright 2021-2023 SICK AG. All rights reserved.
#pragma once
#include "Avoid.h"
#include "GenIStreamDll.h"

#include <memory>

namespace gentlcpp {
class IDataStream;
}

namespace genistream {
class IAnyParameters;

/**
 * Container for data stream statistics from GigE Vision transport layer, as
 * seen by GenTL producer on host (receiver) side of network.
 *
 * The statistics consist of some GigE Vision packet and block metrics counters,
 * exposed by the SickGigEVisionTL GenTL producer implementation, hence the
 * statistics might not be compatible with using other GenTL producer
 * implementations.
 *
 * Please see the GigE Vision standard for a thorough explanation of the terms
 * <i>packet</i> and <i>block</i>. Simply put a packet is a GigE Vision data
 * stream UDP payload packet on the network between camera and connected
 * receiver. A block consists of one or more packets, to build up an entire
 * acquired camera data frame sent on the network. A GigE Vision block is also
 * the content of a received buffer in the GenTL producer's acquisition engine.
 *
 * A simplified way to interpret the different statistics counters is that, for
 * a healthy data stream, the counters should be in line with the following:
 *
 * <ol>
 * <li>Counters \ref seenPacketCount and \ref deliveredPacketCount should have
 * the same value.</li>
 *
 * <li>Counters \ref resendCommandCount and \ref resendPacketCount are ideally
 * zero but can be non-zero, depending on conditions on the network.</li>
 *
 * <li>All other counters should be zero.</li>
 * </ol>
 *
 * \incubating
 */
struct DataStreamStatistics
{
  /** \lowlevel Prefer using \ref ICamera::getDataStreamStatistics(). */
  AVOID static DataStreamStatistics
  createFrom(std::shared_ptr<gentlcpp::IDataStream> dataStream);

  /** \lowlevel Prefer using \ref ICamera::getDataStreamStatistics(). */
  AVOID static DataStreamStatistics
  createFrom(std::shared_ptr<IAnyParameters> dataStreamParameters);

  bool operator==(const DataStreamStatistics& other) const;
  bool operator!=(const DataStreamStatistics& other) const
  {
    return !operator==(other);
  }

  /**
   * Does a <i>simplified</i> evaluation of whether the statistics counters seem
   * to be healthy, according to the rules given in \ref DataStreamStatistics.
   *
   * \return true if statistics is deemed healthy
   */
  bool isHealthy() const;

public:
  /**
   * Overall packets seen. Any packets, including invalid and duplicate, seen by
   * the GenTL producer acquisition engine.
   */
  int64_t seenPacketCount;

  /**
   * All packets missing, even after resend requests, in the delivered blocks.
   */
  int64_t lostPacketCount;

  /**
   * Total number of resend request commands, no matter if single or
   * multi-packet ones.
   */
  int64_t resendCommandCount;

  /** Number of packets requested to be resent. */
  int64_t resendPacketCount;

  /** All packets successfully received in all the delivered blocks. */
  int64_t deliveredPacketCount;

  /**
   * All packets explicitly announced as unavailable by the camera, possibly
   * after resend request. Possibly unavailable since no longer kept in memory
   * in camera.
   */
  int64_t unavailablePacketCount;

  /** Packets that were received two or more times. Likely due to resend. */
  int64_t duplicatePacketCount;

  /**
   * Number of blocks that were skipped somewhere. Blocks for which no packet
   * was seen. Can for instance happen if all packages in a block are lost on
   * the network, or if camera for some speed-related reason needed to skip
   * block.
   */
  int64_t skippedBlockCount;

  /**
   * Number of incoming blocks that were discarded because no buffers were
   * available when block arrived. Possibly due to buffers not released back
   * into the acquisition engine after previous use.
   */
  int64_t engineUnderrunCount;

  /**
   * Number of blocks that were discarded in the receiving producer for some
   * reason.
   */
  int64_t discardedBlockCount;

  /** Number of blocks that were incomplete but still delivered. */
  int64_t incompleteBlockCount;

  /**
   * Number of blocks that were detected as oversized, as in overflowing the
   * buffer in acquisition engine.
   */
  int64_t oversizedBlockCount;
};

std::ostream& operator<<(std::ostream& os, const DataStreamStatistics& stats);

}
