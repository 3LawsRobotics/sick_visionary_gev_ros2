// Copyright 2019-2023 SICK AG. All rights reserved.
#pragma once

/**
 * \file
 *
 * Macros to indicate that functions should be avoided and macros to still allow
 * using such functions without getting a warning. Sometimes you need to use
 * functions that should be avoided for various reasons but this way you at
 * least get a clear indication in the code.
 *
 * The allow macros have the same implementation since the same warning is
 * issued but the macros are separate to indicate the semantical difference.
 */

/**
 * \def AVOID
 *
 * This macro is used to indicate that a construct should be avoided to be used
 * unless absolutely necessary. In Visual Studio it will cause a deprecation
 * warning.
 */
#ifdef _MSC_VER
#  define AVOID __declspec(deprecated("Avoid using this function"))
#else
#  define AVOID
#endif

/**
 * \def AVOID_IN_CPP
 *
 * Same as \ref AVOID but semantically meaning the function should be avoid in
 * native code (C++) but is fine to use in C# or other languages.
 */
#define AVOID_IN_CPP AVOID

/**
 * \def ALLOW_LOWLEVEL
 *
 * Functions marked as lowlevel are also marked with the \ref AVOID macro. To
 * allow an expression to use such functions you can surround it with this
 * macro.
 */
// clang-format off
#ifdef _MSC_VER
#define ALLOW_LOWLEVEL(expression)                                             \
  __pragma(warning(push))                                                      \
  __pragma(warning(disable : 4996))                                            \
  expression                                                                   \
  __pragma(warning(pop))
#else
#define ALLOW_LOWLEVEL(expression)                                             \
  expression                                                                   
#endif
// clang-format on

/**
 * \def ALLOW_DEPRECATED
 *
 * Functions marked as deprecated are also marked with the \ref AVOID macro. To
 * allow an expression to use such functions you can surround it with this
 * macro.
 */
// clang-format off
#ifdef _MSC_VER
#define ALLOW_DEPRECATED(expression)                                           \
  __pragma(warning(push))                                                      \
  __pragma(warning(disable : 4996))                                            \
  expression                                                                   \
  __pragma(warning(pop))
#else
#define ALLOW_DEPRECATED(expression)                                             \
  expression                                                                   
#endif
// clang-format on
