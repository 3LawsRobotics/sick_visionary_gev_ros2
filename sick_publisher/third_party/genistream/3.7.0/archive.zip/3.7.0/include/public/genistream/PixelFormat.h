// Copyright 2019-2023 SICK AG. All rights reserved.
#pragma once

#include "Avoid.h"
#include "CameraParameters.h"
#include "GenIStreamDll.h"

#include <cstdint>

namespace genistream { namespace pixelformat {

/**
 * The data type used to represent a pixel in a channel.
 *
 * \incubating
 */
enum class PixelDataType
{
  UINT8,
  UINT16,
  UINT32,
  /** Corresponds to float in C++ and C#. */
  FLOAT32,
  /** Corresponds to double in C++ and C#. */
  FLOAT64,
};

/** \return the number of bits per pixel */
uint8_t bitsPerPixel(PixelFormat format);

/** \return the number of bits per channel of each pixel */
uint8_t bitsPerChannel(PixelFormat format);

/**
 * \return the data type used to represent a pixel in each channel
 * \incubating
 */
PixelDataType channelDataType(PixelFormat format);

/**
 * \return true if the pixel contains one type of value (single channel images)
 */
bool hasSingleChannel(PixelFormat format);

/**
 * \deprecated Prefer using \ref hasSingleChannel().
 * \deprecatedsince 2.7
 */
AVOID bool hasSingleComponent(PixelFormat format);

/**
 * \return true if the pixel contains multiple types of values (multi-channel
 *         images)
 */
bool hasMultipleChannels(PixelFormat format);

/**
 * \deprecated Prefer using \ref hasMultipleChannels().
 * \deprecatedsince 2.7
 */
AVOID bool hasMultipleComponents(PixelFormat format);

/** \return the number of channels in each pixel */
size_t getNumberOfChannels(PixelFormat format);

/** \return true if the pixel is a 3D coordinate */
bool isCoord3d(PixelFormat format);

/** \return true if the pixel is a 3D coordinate in the A direction */
bool isCoord3dA(PixelFormat format);

/** \return true if the pixel is a 3D coordinate in the B direction */
bool isCoord3dB(PixelFormat format);

/** \return true if the pixel is a 3D coordinate in the C direction */
bool isCoord3dC(PixelFormat format);

/** \return true if the pixel is monochrome */
bool isMono(PixelFormat format);

/** \return the numeric min value of a pixel of the format */
double getMin(PixelFormat format);

/** \return the numeric max value of each channel in a pixel of the format */
double getMaxPerChannel(PixelFormat format);

/**
 * \return the numeric max value of a pixel of the format
 * \deprecated Prefer using \ref getMaxPerChannel.
 * \deprecatedsince 2.9
 */
AVOID double getMax(PixelFormat format);

/**
 * \return true if the pixel format is packed, i.e., is there are no spaces
 *         between pixels value when they are not complete bytes
 */
bool isPacked(PixelFormat pixelFormat);

/**
 * \return true if the pixel format is planar. This means multi-channel
 *         components are stored separately, rather than interlaced per pixel.
 */
bool isPlanar(PixelFormat pixelFormat);

/** \return true if the pixel formats data type is float */
bool isFloatingPoint(PixelFormat pixelFormat);

/**
 * \return the formats merged into a combined format if possible. The function
 *         is order sensitive for the formats vector.
 * \throws GenIStreamExeception if the formats can not be merged
 */
PixelFormat merge(const std::vector<PixelFormat>& formats);

/** \return the format split into its smallest parts */
std::vector<PixelFormat> split(PixelFormat format);

}}
