// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "IEvent.h"
#include "../genistream/GenIStreamDll.h"

namespace gentlcpp {

/** Returns the new buffer data result. */
struct NewBufferEventResult
{
  ResultStatus status;
  GenTL::S_EVENT_NEW_BUFFER newBuffer;

  /** Convenience method that returns successful value or throws exception. */
  GenTL::S_EVENT_NEW_BUFFER successOrThrow() const
  {
    if (status == ResultStatus::TIMED_OUT)
    {
      throw TimeoutException("Unsuccessful result - timed out");
    }
    if (status == ResultStatus::ABORTED)
    {
      throw AbortException("Unsuccessful result - aborted");
    }
    // successful result
    return newBuffer;
  }
};

/** This is a convenience interface for the "new buffer event" type. */
class GENISTREAM_API INewBufferEvent : public virtual IEvent
{
public:
  /**
   * Wait for a new buffer to be available.
   *
   * \param timeout If a buffer is not received within this period, an exception
   *        will be thrown.
   */
  virtual NewBufferEventResult
  getData(std::chrono::milliseconds timeout) const = 0;

  /**
   * Wait for a new buffer to be available with infinite timeout, i.e., the
   * function will not return unless a buffer is received.
   */
  virtual NewBufferEventResult getData() const = 0;
};

}
