// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "gentlcpp/BasicTypes.h"
#include "genistream/GenIStreamDll.h"

#include <chrono>
#include <functional>

namespace genistream { namespace event {

/** Severity level of a log message. */
enum class CameraLogLevel
{
  FINE = 0,
  INFO = 1,
  WARNING = 2,
  SEVERE = 3
};

/**
 * A clock that measures time since the camera has booted. It is used to
 * separate the different timestamps in \ref CameraLogMessage, via strong
 * typing.
 */
struct GENISTREAM_API CameraUptime
{
  using duration = std::chrono::nanoseconds;

  static std::chrono::time_point<CameraUptime>
  fromNanoseconds(std::chrono::nanoseconds duration);
};

/** Log message from a camera. */
struct GENISTREAM_API CameraLogMessage
{
  gentlcpp::DeviceId cameraId;
  /**
   * High-resolution timestamp when the event was sent from the camera. Measured
   * in nanoseconds.
   */
  std::chrono::time_point<CameraUptime> cameraTimestamp;
  /** The point in time the message was received by the PC. */
  std::chrono::time_point<std::chrono::system_clock> receivedTimestamp;
  CameraLogLevel level = CameraLogLevel::FINE;
  std::string text;

  bool operator==(const CameraLogMessage& other) const;

  /**
   * \return a string representation of the date and time in local timezone the
   *         log message was received in the format YYYY-MM-DD hh:mm:ss.sss
   */
  std::string receivedAtLocalTimeString() const;

  std::string levelString() const;
};

/** A callback function that handles a log message. */
typedef std::function<void(const CameraLogMessage&)> LogCallback;

}}
