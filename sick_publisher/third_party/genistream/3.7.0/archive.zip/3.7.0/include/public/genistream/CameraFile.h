// Copyright 2021-2023 SICK AG. All rights reserved.
#pragma once

#include "Avoid.h"
#include "GenIStreamDll.h"

#include <memory>
#include <string>
#include <vector>

namespace genistream {

class IAnyParameters;
class ICamera;

/** An object representing a file on a camera. */
class GENISTREAM_API CameraFile
{
public:
  /**
   * \return true if the file is implemented on the camera, i.e., supports
   *         having such a file. This does not mean there is an actual file with
   *         the name available on the camera.
   */
  static bool isImplemented(std::shared_ptr<ICamera> camera,
                            const std::string& filename);

  /**
   * \return file objects for all files found in given parameters
   * \lowlevel Prefer using \ref ICamera::listFiles()
   */
  AVOID static std::vector<std::shared_ptr<CameraFile>>
  listFilesInParameters(std::shared_ptr<IAnyParameters> parameters,
                        std::shared_ptr<ICamera> camera = nullptr);

  /**
   * \return file objects for all files found in given parameters
   * \throws InvalidFileOperationException if there is no file with the given
   *         name
   * \lowlevel Prefer using \ref ICamera::getFile()
   */
  AVOID static std::shared_ptr<CameraFile>
  getFileInParameters(const std::string& filename,
                      std::shared_ptr<IAnyParameters> parameters,
                      std::shared_ptr<ICamera> camera = nullptr);

  std::string symbolicName() const;
  std::string displayName() const;
  std::string description() const;

  /**
   * \return true if the file is visible in GenApi. If it is not visible it
   *         should not be shown in a user interface and is likely an alias for
   *         another file.
   */
  bool isVisible() const;
  bool isWritable() const;
  bool isReadable() const;
  bool isDeletable() const;
  std::string toString() const;

  /**
   * Deletes the file from the camera.
   *
   * \throws InvalidFileOperationException if the file operation is invalid
   * \throws DisconnectedException if the camera is disconnected
   */
  void deleteFromCamera() const;

  /**
   * Sends contents to the camera file.
   *
   * \param content the content to write to the camera file
   * \throws InvalidFileOperationException if the file operation is invalid
   * \throws DisconnectedException if the camera is disconnected
   */
  void sendFileContentToCamera(const std::string& content) const;

  /**
   * Sends a file to the camera file.
   *
   * \param filePath path to the file
   * \throws InvalidFileOperationException if the file operation is invalid
   * \throws DisconnectedException if the camera is disconnected
   */
  void sendFileToCamera(const std::string& filePath) const;

  /**
   * Retrieves the contents of the camera file.
   *
   * \return the camera file contents
   * \throws InvalidFileOperationException if the file operation is invalid.
   * \throws DisconnectedException if the camera is disconnected.
   */
  std::string retrieveFileContentFromCamera() const;

  /**
   * Saves a camera file to a file path
   *
   * \param destinationFilePath path where to save the camera file
   * \throws InvalidFileOperationException if the file operation is invalid
   * \throws DisconnectedException if the camera is disconnected
   */

  void retrieveFileFromCamera(const std::string& destinationFilePath) const;

  bool operator==(const CameraFile& other) const;
  bool operator!=(const CameraFile& other) const;

private:
  friend class CameraFileTest;

  static std::shared_ptr<CameraFile>
  create(const std::string& id,
         std::shared_ptr<IAnyParameters> params,
         std::shared_ptr<ICamera> camera);

  CameraFile(std::string id,
             std::string symbolicName,
             std::string displayName,
             std::string description,
             std::weak_ptr<ICamera> camera);

  std::shared_ptr<ICamera> getCameraOrThrow() const;

private:
  std::string mId;
  std::string mSymbolicName;
  std::string mDisplayName;
  std::string mDescription;

  // The camera object does not affect comparison and toString
  std::weak_ptr<ICamera> mCamera;
};

inline std::ostream& operator<<(std::ostream& os, const CameraFile& cf)
{
  return os << cf.toString();
}

}
