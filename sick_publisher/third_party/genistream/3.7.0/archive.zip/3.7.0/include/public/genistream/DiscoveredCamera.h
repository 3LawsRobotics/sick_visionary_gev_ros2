// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "Avoid.h"
#include "GenIStreamDll.h"
#include "Ip4Address.h"
#include "MacAddress.h"
#include "gentlcpp/BasicTypes.h"
#include "GenIStreamDll.h"

#include <memory>
#include <string>

namespace gentlcpp {
class IInterface;
class IDeviceInfo;
}

namespace genistream {

class Ip4Address;
class MacAddress;

/**
 * Represents a camera that has been found via \ref CameraDiscovery. It is
 * designed to not hold any underlying resources open.
 */
class GENISTREAM_API DiscoveredCamera
{
public:
  /**
   * Accessibility for the camera. Corresponds to
   * GenTL::DEVICE_ACCESS_STATUS_LIST.
   */
  enum class AccessStatus
  {
    /** The camera accessibility is not known. */
    UNKNOWN = 0,
    /** The camera is available for read/write access. */
    READ_WRITE = 1,
    /** The camera is available for read only access. */
    READ_ONLY = 2,
    /** The camera is not accessible. */
    NO_ACCESS = 3,
    /** The camera has already been opened by another process/host. */
    BUSY = 4,
    /** The camera has already been opened by this process. */
    OPEN_READ_WRITE = 5,
    /** The camera has already been opened by this process. */
    OPEN_READ = 6
  };

  /**
   * You should normally not have to use this method. Instead use \ref
   * CameraDiscovery::scanForCameras(std::chrono::milliseconds).
   *
   * \lowlevel
   */
  AVOID static std::shared_ptr<DiscoveredCamera>
  create(std::shared_ptr<gentlcpp::IDeviceInfo> deviceInfo,
         gentlcpp::InterfaceId interfaceId);

  /**
   * You should normally not have to use this constructor. Instead use \ref
   * CameraDiscovery::scanForCameras(std::chrono::milliseconds).
   *
   * \lowlevel
   */
  AVOID DiscoveredCamera(gentlcpp::DeviceId deviceId,
                         gentlcpp::InterfaceId interfaceId,
                         const std::string& userDefinedName,
                         const std::string& displayName,
                         const std::string& serialNumber,
                         const std::string& model,
                         const std::string& vendor,
                         const std::string& version,
                         Ip4Address ipAddress,
                         Ip4Address subnetMask,
                         MacAddress macAddress,
                         AccessStatus accessStatus);

  /** \return the ID of the camera */
  const gentlcpp::DeviceId& getId() const;

  /** \return the ID of the interface where the camera was discovered */
  const gentlcpp::InterfaceId& getInterfaceId() const;

  /** \return the name set by the in the GenICam parameter DeviceUserID */
  const std::string& getUserDefinedName() const;

  /** \return the display name of the camera */
  const std::string& getDisplayName() const;

  /** \return the unique serial number of the camera */
  const std::string& getSerialNumber() const;

  /** \return the model of the camera */
  const std::string& getModel() const;

  /** \return the vendor of the camera */
  const std::string& getVendor() const;

  /** \return the version of the camera */
  const std::string& getVersion() const;

  /** \return the current IP address of the camera */
  Ip4Address getIpAddress() const;
  /** \return the current subnet mask of the camera */
  Ip4Address getSubnetMask() const;

  /** \return the MAC address of the camera */
  MacAddress getMacAddress() const;

  /**
   * \return the access status at the time of discovery, i.e., whether the
   *         camera is busy or can be connected to.
   */
  AccessStatus getAccessStatus();

private:
  gentlcpp::DeviceId mDeviceId;
  gentlcpp::InterfaceId mInterfaceId;
  std::string mUserDefinedName;
  std::string mDisplayName;
  std::string mSerialNumber;
  std::string mModel;
  std::string mVendor;
  std::string mVersion;
  Ip4Address mIpAddress;
  Ip4Address mSubnetMask;
  MacAddress mMacAddress;
  AccessStatus mAccessStatus;
};

}
