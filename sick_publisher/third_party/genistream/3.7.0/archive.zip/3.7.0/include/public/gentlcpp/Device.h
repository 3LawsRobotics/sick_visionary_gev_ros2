// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include "BasicTypes.h"
#include "IDevice.h"

#include "../../public/gentlcpp/CApi.h"
#include "../genistream/GenIStreamDll.h"

#include <memory>
#include <string>
#include <vector>

namespace gentlcpp {

class Interface;
class DataStream;
class Port;


#ifdef SWIG
class GENISTREAM_API Device : public IDevice
#else
class GENISTREAM_API Device : public std::enable_shared_from_this<Device>, public IDevice
#endif
{
public:
  Device(const Device&) = delete;
  ~Device() noexcept override;

  void disconnect() override;
  bool isConnected() const override;

  GenTL::DEV_HANDLE getHandle() override;
  std::shared_ptr<IInterface> getParent() const override;

  std::shared_ptr<IEvent> registerEvent(GenTL::EVENT_TYPE_LIST eventType)
    override;

  std::vector<DataStreamId> getDataStreamIds() const override;
  std::shared_ptr<IDataStream> openDataStream(const DataStreamId& dataStreamId)
    override;

  std::shared_ptr<Port> getLocalPort() override;
  std::shared_ptr<Port> getRemotePort() override;
  DeviceId getId() const override;
  std::string getVendor() const override;
  std::string getModel() const override;
  std::string getTransportLayerType() const override;
  std::string getDisplayName() const override;
  GenTL::DEVICE_ACCESS_STATUS_LIST getAccessStatus() const override;
  std::string getUserDefinedName() const override;
  std::string getSerialNumber() const override;
  std::string getVersion() const override;

  template<typename T>
  T getInfo(GenTL::DEVICE_INFO_CMD_LIST command) const
  {
    T value;
    size_t size = sizeof(T);
    GenTL::INFO_DATATYPE dataType;
    ThrowIfError(mCApi,
                 mCApi->DevGetInfo(mHandle, command, &dataType, &value, &size));
    return value;
  }


  template<typename T>
  T getInfo(uint32_t customCommand) const
  {
    return getInfo<T>(static_cast<GenTL::DEVICE_INFO_CMD_LIST>(customCommand));
  }

#ifdef SWIG
    EXPLODE_TEMPLATE_TYPES(getInfo);
#endif

private:
  friend class Interface;

  Device(std::shared_ptr<const CApi> cApi,
         std::shared_ptr<Interface> iface,
         const DeviceId& deviceId,
         GenTL::DEVICE_ACCESS_FLAGS_LIST accessFlags);

  void throwIfDisconnected() const;
  uint32_t getDataStreamCount() const;
  DataStreamId getDataStreamId(uint32_t index) const;

private:
  std::shared_ptr<const CApi> mCApi;
  // Hold a reference to parent to make sure objects are destructed in correct
  // order
  std::shared_ptr<Interface> mParent;
  GenTL::DEV_HANDLE mHandle;
};


/* (explicit specialization has to be declared in a scope where primary template can be defined) */
template<>
std::string Device::getInfo(GenTL::DEVICE_INFO_CMD_LIST customCommand) const;

}
