// Copyright 2018-2023 SICK AG. All rights reserved.
#pragma once

#include "GenIStreamDll.h"
#include <cstdint>
#include <memory>
#include <vector>

namespace genistream {

/**
 * Container for metadata per scan line in Ranger3/Ruler3000 family of cameras.
 */
struct GENISTREAM_API LineMetadata
{
  LineMetadata() = default;
  LineMetadata(uint64_t timestamp,
               int32_t encoderValue,
               uint8_t overtriggerCount,
               bool frameTriggerActive,
               bool lineTriggerActive,
               bool encoderResetActive,
               bool encoderA,
               bool encoderB)
    : timestamp(timestamp)
    , encoderValue(encoderValue)
    , overtriggerCount(overtriggerCount)
    , frameTriggerActive(frameTriggerActive)
    , lineTriggerActive(lineTriggerActive)
    , encoderResetActive(encoderResetActive)
    , encoderA(encoderA)
    , encoderB(encoderB)
  {
  }

  bool operator==(const LineMetadata& rhs) const
  {
    return timestamp == rhs.timestamp && encoderValue == rhs.encoderValue
           && overtriggerCount == rhs.overtriggerCount
           && frameTriggerActive == rhs.frameTriggerActive
           && lineTriggerActive == rhs.lineTriggerActive
           && encoderResetActive == rhs.encoderResetActive
           && encoderA == rhs.encoderA && encoderB == rhs.encoderB;
  }

  bool operator!=(const LineMetadata& rhs) const { return !operator==(rhs); }

  /** Timestamp in nanoseconds. */
  uint64_t timestamp = 0;
  /**
   * The encoder counter's value when the profile exposure is triggered for each
   * scan line included in the payload.
   */
  int32_t encoderValue = 0;

  /**
   * 1 if a line trigger has been requested before the sensor was actually ready
   * for a new trigger.
   */
  uint8_t overtriggerCount = 0;
  /** 1 if frame trigger pin (IO pin 1) is high, otherwise 0. */
  bool frameTriggerActive = false;
  /** 1 if line trigger pin (IO pin 2) is high, otherwise 0. */
  bool lineTriggerActive = false;
  /** 1 if Encoder Reset (IO pin 3) is high, otherwise 0. */
  bool encoderResetActive = false;
  /** Value 0 (for low) or 1 (for high) at encoder channel A. */
  bool encoderA = false;
  /** Value 0 (for low) or 1 (for high) at encoder channel B. */
  bool encoderB = false;
};

/** Pointer to vector of constant metadata for each line scanned. */
typedef std::shared_ptr<const std::vector<LineMetadata>>
  ConstLineMetadataVectorPtr;

/** Pointer to vector metadata for each line scanned. */
typedef std::shared_ptr<std::vector<LineMetadata>> LineMetadataVectorPtr;

}
