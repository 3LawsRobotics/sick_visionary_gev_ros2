// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "CameraLog.h"
#include "genistream/GenIStreamDll.h"
#include "genistream/WaitResult.h"

#include <chrono>
#include <memory>

namespace genistream { namespace event {

class ICameraLogDispatcher;

template<typename DispatcherType, typename EventDataType>
class EventPoller;

/**
 * This class allows polling for log messages from the camera.
 *
 * \see \refcpp{ICamera::subscribeToLogEvent()} \refcs{ICamera.LogReceived} for
 *      an API that provides notifications on a callback function.
 * \incubating
 */
class GENISTREAM_API CameraLogPoller
{
public:
  /**
   * Creates an object to poll log messages from a camera. Prefer using \ref
   * ICamera::createLogPoller().
   *
   * From the point of creation, camera log events are listened for. Received
   * camera log messages are stored, i.e., you are guaranteed not to miss any
   * logs when polling. It also means you should ensure that polling is
   * performed so that the stored amount of log messages does not build up.
   */
  static std::shared_ptr<CameraLogPoller>
  create(std::shared_ptr<ICameraLogDispatcher> dispatcher);

  /** Destruction of the object will implicitly do \ref stopListening(). */
  ~CameraLogPoller() = default;

  /**
   * Stops listening for camera log events. If this is done while polling from
   * another thread, \ref poll(std::chrono::milliseconds) will return a result
   * which indicates that the operation has aborted.
   */
  void stopListening();

  /** \return true if listening for camera log events */
  bool isListening() const;

  /**
   * Polls to see if there is a log message from the camera available.
   *
   * \return a \refcpp{WaitResult} \refcs{LogMessageResult} object wrapping a
   *         \ref CameraLogMessage, if a message is available. Otherwise an
   *         object indicating timeout or aborted operation.
   */
  WaitResult<CameraLogMessage> poll(std::chrono::milliseconds timeout);

  /**
   * Polls to see if there is a log message from the camera available. This
   * method will never time out while waiting for new log messages.
   *
   * \return a \refcpp{WaitResult} \refcs{LogMessageResult} object wrapping a
   *         \ref CameraLogMessage, if a message is available. Otherwise an
   *         object indicating aborted operation.
   */
  WaitResult<CameraLogMessage> poll();

private:
  CameraLogPoller(std::shared_ptr<ICameraLogDispatcher> dispatcher);

private:
  std::unique_ptr<EventPoller<ICameraLogDispatcher, CameraLogMessage>> mPoller;
};

}}
