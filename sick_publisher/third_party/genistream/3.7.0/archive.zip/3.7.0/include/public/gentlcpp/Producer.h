// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include <TLI/GenTL.h>

#include "genistream/Avoid.h"
#include "../genistream/GenIStreamDll.h"

#include "../../public/gentlcpp/CApi.h"

#include <memory>
#include <string>

namespace gentlcpp {

class CApi;
class ITransportLayer;

/**
 * Entry point to the object oriented bindings for GenTL. This class takes care
 * of loading the .cti-file and library initialization.
 */
#ifdef SWIG
class GENISTREAM_API Producer
#else
class GENISTREAM_API Producer : public std::enable_shared_from_this<Producer>
#endif
{
public:
  static std::string getCompliantGenTlVersion();

  static std::shared_ptr<Producer> create(std::shared_ptr<const CApi> cApi);

  /**
   * You should normally not have to create gentlcpp objects yourself. Use \ref
   * genistream::CameraDiscovery() as entry point of the API instead.
   *
   * \lowlevel
   */
  AVOID static std::shared_ptr<Producer> load(const std::string& ctiFilePath);

  Producer(const Producer&) = delete;
  ~Producer() noexcept;

  /** Opens the GenTL transport layer. */
  std::shared_ptr<ITransportLayer> openTransportLayer();

  /**
   * \return a pointer to the internally used CApi
   * \internal
   */
  AVOID void* getCApiPtr();

  std::string getVendor() const;
  std::string getModel() const;
  std::string getVersion() const;
  std::string getTlType() const;
  std::string getName() const;
  std::string getPathname() const;
  std::string getDisplayname() const;
  uint32_t getGenTlVersionMajor() const;
  uint32_t getGenTlVersionMinor() const;

  template<typename T>
  T getInfo(GenTL::TL_INFO_CMD_LIST command) const
  {
    T value;
    size_t size = sizeof(value);
    GenTL::INFO_DATATYPE dataType;
    ThrowIfError(mCApi, mCApi->GCGetInfo(command, &dataType, &value, &size));
    return value;
  }

  template<typename T>
  T getInfo(uint32_t customCommand) const
  {
    return getInfo<T>(static_cast<GenTL::TL_INFO_CMD_LIST>(customCommand));
  }

#ifdef SWIG
    EXPLODE_TEMPLATE_TYPES(getInfo);
#endif

private:
  Producer(std::shared_ptr<const CApi> cApi);

private:
  std::shared_ptr<const CApi> mCApi;

  // Debugging id to be able to track object allocations more easily
  int mInternalId;

  static int msNextInternalId;
};

/* (explicit specialization has to be declared in a scope where primary template can be defined) */
template<>
std::string Producer::getInfo(GenTL::TL_INFO_CMD_LIST command) const;

}
