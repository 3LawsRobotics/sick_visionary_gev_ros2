// Copyright 2019-2023 SICK AG. All rights reserved.
#pragma once

#include "Avoid.h"
#include "GenIStreamDll.h"

#include <TLI/GenTL.h>


#include <memory>
#include <vector>

namespace gentlcpp {
class IBuffer;
class IDataStream;
}

namespace genistream {

/**
 * Keeps track of allocated memory and GenTL buffer handles. The memory is owned
 * by this class and freed with \ref revokeAndFreeAllBuffers or by the
 * destructor.
 *
 * A buffer can be in one of the following states:
 * - Allocated and announced: memory and a buffer handle is allocated
 * - Queued in input pool: ready for being filled with received data
 * - Fill: currently being filled with received data
 * - Pending in output queue: filled with data and ready to be processed
 *
 * For more details, see the GenTL documentation chapter 5: Acquisition Engine.
 *
 * \lowlevel Prefer working with \ref FrameGrabber.
 */
class GENISTREAM_API BufferManager
{
public:
  /**
   * Different behaviors when queueing buffers.
   *
   * \lowlevel
   */
  enum class QueueBehavior
  {
    /**
     * Default behavior is to set buffer contents to "missing data", i.e.,
     * zeroes to avoid confusion. Otherwise a re-used buffer may contain data
     * from an old frame that was grabbed earlier.
     */
    FILL_WITH_MISSING_DATA_AND_QUEUE,
    /**
     * Only queue buffer without changing data, may be useful to reduce CPU load
     * in some scenarios.
     */
    QUEUE_ONLY,
  };

public:
  /**
   * You should normally not have to use this constructor. Instead use a \ref
   * FrameGrabber.
   *
   * \lowlevel
   */
  AVOID explicit BufferManager(
    std::shared_ptr<gentlcpp::IDataStream> dataStream);

  ~BufferManager();

  /**
   * Allocates memory for one buffer and announces it to the data stream.
   *
   * \return A handle to the newly allocated buffer
   */
  std::shared_ptr<gentlcpp::IBuffer> allocateAndAnnounce(size_t byteCount);

  /**
   * Allocates memory for several buffers at once and announces them to the data
   * stream.
   */
  void allocateAndAnnounce(size_t bufferCount, size_t byteCount);

  /** Queues one buffer into the input pool. */
  void queueBuffer(std::shared_ptr<gentlcpp::IBuffer> buffer);

  /** Marks a buffer as grabbed. */
  void markAsGrabbed(std::shared_ptr<gentlcpp::IBuffer> buffer);

  /**
   * Re-queues all buffers that have not been marked as grabbed. This is needed
   * to not leak buffers when doing start/stop without actually grabbing.
   */
  void requeueAllNotGrabbed();

  /** Queues all announced buffers into the input pool. */
  void queueAllBuffers();

  /** Sets the behavior to use when buffers are queued. */
  void setQueueBehavior(QueueBehavior behavior);

  /**
   * Discards all buffers from the data stream. This will put them in the
   * announced state.
   */
  void discardAllBuffers();

  /** Revokes all buffers from the data stream and frees the memory. */
  void revokeAndFreeAllBuffers();

  /** \return a pointer to the start of the buffer data for a given handle. */
  uint8_t* dataPtrFromHandle(GenTL::BUFFER_HANDLE handle) const;

  std::shared_ptr<gentlcpp::IBuffer>
  bufferFromHandle(GenTL::BUFFER_HANDLE handle) const;

  /** \return the allocated memory in bytes */
  size_t calculateAllocatedMemory() const;

  /**
   * \return the underlying \ref gentlcpp::DataStream
   * \lowlevel
   */
  AVOID std::shared_ptr<gentlcpp::IDataStream> getDataStream();

private:
  friend class BufferManagerTest;

  /** An allocated buffer with both memory and a handle. */
  class BufferAllocation
  {
  public:
    BufferAllocation(std::shared_ptr<gentlcpp::IDataStream> dataStream,
                     size_t size);
    BufferAllocation(std::shared_ptr<gentlcpp::IBuffer> buffer, size_t size);

  public:
    // Using std::unique_ptr to ensure data is deallocated even if an exception
    // is thrown during destruction
    std::unique_ptr<uint8_t[]> bufferData;
    std::shared_ptr<gentlcpp::IBuffer> buffer;
    bool grabbedFlag = false;
  };

private:
  uint8_t* injectBuffer(std::shared_ptr<gentlcpp::IBuffer> buffer,
                        size_t bufferSize);

  BufferAllocation& fromBuffer(std::shared_ptr<gentlcpp::IBuffer> buffer);
  const BufferAllocation& fromHandle(GenTL::BUFFER_HANDLE handle) const;

private:
  std::shared_ptr<gentlcpp::IDataStream> mDataStream;
  std::vector<BufferAllocation> mAllocatedBuffers;
  QueueBehavior mQueueBehavior =
    QueueBehavior::FILL_WITH_MISSING_DATA_AND_QUEUE;
};

}
