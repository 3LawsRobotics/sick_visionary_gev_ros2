// Copyright 2019-2023 SICK AG. All rights reserved.
#pragma once

#include "Aoi.h"
#include "CoordinateSystem.h"
#include "IRegion.h"
#include "genistream/GenIStreamDll.h"

namespace genistream { namespace frame {

class Component;

/**
 * This is a concrete implementation of the \ref IRegion interface which can be
 * used to build regions within \ref Frame%s.
 *
 * There are public functions within this class, not exposed in the \ref IRegion
 * interface, for building. Instances are created with, e.g., \ref
 * Frame::addRegion(RegionId).
 */
#ifdef SWIG
class Region : public IRegion
#else
class GENISTREAM_API Region : public IRegion, public std::enable_shared_from_this<Region>
#endif
{
public:
  /** Sets the \ref Aoi. */
  std::shared_ptr<Region> aoi(Aoi aoi);
  /** Sets the \ref Scan3dExtractionMethod. */
  std::shared_ptr<Region> extractionMethod(
    Scan3dExtractionMethod extractionMethod);
  /** Sets the \ref Scan3dOutputMode. */
  std::shared_ptr<Region> outputMode(Scan3dOutputMode outputMode);

  /**
   * \return the \ref Component with the \ref ComponentId or nullptr if it has
   *         not been added
   */
  std::shared_ptr<Component> findComponent(ComponentId componentId) const;

  /**
   * Adds a \ref Component to the region.
   *
   * \return the created \ref Component object
   * \throws GenIStreamException if the \ref ComponentId has already been added
   */
  std::shared_ptr<Component> addComponent(ComponentId componentId);

  /**
   * Adds a \ref Component to the region and lets you modify the Component
   * object in a lambda.
   *
   * \return the region itself
   * \throws GenIStreamException if the \ref ComponentId has already been added
   */
  std::shared_ptr<Region> addComponent(
    ComponentId componentId,
    std::function<void(std::shared_ptr<Component>)> modifyComponent);

  RegionId getId() const override;

  ConstComponentList getComponents() const override;
  bool hasComponent(ComponentId componentId) const override;
  std::shared_ptr<const IComponent> getComponent(ComponentId componentId)
    const override;

  Aoi getAoi() const override;
  AVOID const CoordinateSystem& getRangeSystem() const override;
  double getYResolution() const override;
  void setYResolution(double yResolution) override;

  Scan3dExtractionMethod getExtractionMethod() const override;
  Scan3dOutputMode getOutputMode() const override;

  std::shared_ptr<IRegion> copy() const override;

  void logTo(std::ostream & s, size_t indentLevel) const override;

private:
  friend class Frame;
  friend class RegionTest;
  Region(RegionId regionId);
  std::shared_ptr<Region> copyConcrete() const;
  static std::shared_ptr<Region> concatenate(const ConstRegionList& regions);

private:
  RegionId mRegionId;
  std::vector<std::shared_ptr<Component>> mComponents;
  Aoi mAoi;
  Scan3dExtractionMethod mExtractionMethod = Scan3dExtractionMethod::HI_3D;
  Scan3dOutputMode mOutputMode = Scan3dOutputMode::UNCALIBRATED_C;

// To allow implementing the deprecated getBuffer() function
#pragma warning(suppress : 4996)
};

}}
