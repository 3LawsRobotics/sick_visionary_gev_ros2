// Copyright 2021-2023 SICK AG. All rights reserved.
#pragma once

#include "../GenIStreamDll.h"
#include <functional>

namespace genistream { namespace util {

/**
 * A generic class to perform an action when destructed. Useful helper to clean
 * something up in RAII style.
 */
class AtScopeExit
{
public:
  AtScopeExit(std::function<void()> action) noexcept
    : mAction(std::move(action))
  {
  }
  AtScopeExit(AtScopeExit&& other) = default;

  ~AtScopeExit() { mAction(); }

  AtScopeExit(const AtScopeExit&) = delete;
  AtScopeExit& operator=(const AtScopeExit&) = delete;
  AtScopeExit& operator=(AtScopeExit&&) = delete;

private:
  std::function<void()> mAction;
};

}}
