// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "GenIStreamDll.h"
#include <gentlcpp/BasicTypes.h>

#include <chrono>
#include <memory>
#include <vector>

namespace gentlcpp {
class IInterfaceInfo;
class IInterface;
}

namespace genistream {

/**
 * A cache of open network interfaces for a transport layer instance.
 *
 * This is useful to keep the interfaces open and to prevent errors from GenTL
 * by avoiding to open the same network interface more than once.
 *
 * \lowlevel
 */
class GENISTREAM_API ICachedInterfaces
{
public:
  virtual ~ICachedInterfaces() = default;

  /** \return information on all available network interfaces */
  virtual std::vector<std::shared_ptr<const gentlcpp::IInterfaceInfo>>
  getInterfaces(std::chrono::milliseconds timeout) = 0;

  /**
   * Opens a network interface unless it is not already opened.
   *
   * \return the open interface
   */
  virtual std::shared_ptr<gentlcpp::IInterface>
  ensureOpen(const gentlcpp::InterfaceId& id) = 0;
};

}
