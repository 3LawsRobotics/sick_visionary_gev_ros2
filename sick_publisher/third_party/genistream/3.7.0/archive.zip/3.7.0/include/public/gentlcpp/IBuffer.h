// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include <TLI/GenTL.h>
#include "../genistream/GenIStreamDll.h"

#include <cstdint>
#include <memory>
#include <string>

#include "BasicTypes.h"

namespace gentlcpp {

class IBufferPart;
class IDataStream;

/**
 * Represents a buffer in the GenTL buffer module.
 *
 * \see \ref IDataStream::announceBuffer() to get an instance
 */
class GENISTREAM_API IBuffer
{
public:
  virtual ~IBuffer() noexcept = default;

  /** Clears all data from the allocated buffer. */
  virtual void clear() = 0;

  virtual GenTL::BUFFER_HANDLE getHandle() const = 0;

  virtual BufferUserData getUserData() const = 0;
  virtual GenTL::PAYLOADTYPE_INFO_IDS getPayloadType() const = 0;
  virtual bool containsChunkData() const = 0;
  virtual size_t getDeliveredChunkPayloadSize() const = 0;
  virtual BufferPointerType getBase() = 0;
  virtual size_t getSize() const = 0;
  virtual size_t getSizeFilled() const = 0;
  virtual size_t getDataSize() const = 0;
  virtual uint64_t getFrameId() const = 0;
  virtual uint64_t getTimeStamp() const = 0;
  virtual size_t getWidth() const = 0;
  /**
   * The expected height of the buffer. May differ from \ref
   * getDeliveredHeight() if the acquisition is stopped early and
   * AcquisitionStopMode is Immediate.
   */
  virtual size_t getConfiguredHeight() const = 0;
  /**
   * The delivered height of the buffer. May differ from \ref
   * getConfiguredHeight() if the acquisition is stopped early
   * AcquisitionStopMode is Immediate.
   */
  virtual size_t getDeliveredHeight() const = 0;
  virtual uint64_t getPixelFormat() const = 0;
  virtual bool hasNewData() const = 0;
  virtual bool isQueued() const = 0;
  virtual bool isAcquiring() const = 0;
  virtual bool isIncomplete() const = 0;
  virtual std::string getTransportLayerType() const = 0;

  // Multi-part functionality
  virtual uint32_t getBufferPartCount() const = 0;
  virtual std::shared_ptr<IBufferPart> getBufferPart(uint32_t partIndex) = 0;
};

}
