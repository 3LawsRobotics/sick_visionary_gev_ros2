// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include "IInterface.h"
#include "../genistream/GenIStreamDll.h"

namespace gentlcpp {

class CApi;
class ITransportLayer;

#ifdef SWIG
class GENISTREAM_API Interface : public IInterface
#else
class GENISTREAM_API Interface : public std::enable_shared_from_this<Interface>,
                  public IInterface
#endif
{
public:
  Interface(const Interface&) = delete;
  ~Interface() noexcept override;

  GenTL::IF_HANDLE getHandle() override;
  std::shared_ptr<ITransportLayer> getParent() const override;

  std::shared_ptr<IEvent> registerEvent(GenTL::EVENT_TYPE_LIST eventType)
    override;

  bool updateDeviceList(std::chrono::milliseconds timeout) override;
  std::vector<std::shared_ptr<IDeviceInfo>> getDevices() override;

  std::shared_ptr<IDevice> openDevice(
    const DeviceId& deviceId, GenTL::DEVICE_ACCESS_FLAGS_LIST accessFlags)
    override;

  DeviceId getId() const override;
  std::string getDisplayName() const override;
  std::string getTransportLayerType() const override;
  std::shared_ptr<Port> getPort() override;

  // General get info methods (for the interface)
  template<typename T>
  T getInfo(GenTL::INTERFACE_INFO_CMD_LIST command) const
  {
    T value;
    size_t size = sizeof(T);
    GenTL::INFO_DATATYPE dataType;
    ThrowIfError(mCApi, IFGetInfo(mHandle, command, &dataType, &value, &size));
    return value;
  }

  template<typename T>
  T getInfo(uint32_t customCommand) const
  {
    return getInfo<T>(
      static_cast<GenTL::INTERFACE_INFO_CMD_LIST>(customCommand));
  }

#ifdef SWIG
    EXPLODE_TEMPLATE_TYPES(getInfo);
#endif

private:
  friend class TransportLayer;

  Interface(std::shared_ptr<const CApi> cApi,
            std::shared_ptr<ITransportLayer> transportLayer,
            const InterfaceId& interfaceId);

  uint32_t getDeviceCount();
  DeviceId getDeviceId(uint32_t index);

private:
  std::shared_ptr<const CApi> mCApi;
  // Hold a reference to parent to make sure objects are destructed in correct
  // order
  std::shared_ptr<ITransportLayer> mParent;
  GenTL::IF_HANDLE mHandle;
};


/* (explicit specialization has to be declared in a scope where primary template can be defined) */
template<>
std::string Interface::getInfo(GenTL::INTERFACE_INFO_CMD_LIST command) const;
}
