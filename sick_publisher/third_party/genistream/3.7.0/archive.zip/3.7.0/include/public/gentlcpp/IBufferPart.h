// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include "BasicTypes.h"
#include <TLI/GenTL.h>
#include "../genistream/GenIStreamDll.h"

namespace gentlcpp {

/**
 * Represents a single part of a multi-part buffer in the GenTL buffer module.
 *
 * \see \ref IBuffer::getBufferPart() to get an instance.
 */
class GENISTREAM_API IBufferPart
{
public:
  virtual ~IBufferPart() noexcept = default;

  virtual uint32_t getIndex() const = 0;
  virtual BufferPointerType getBase() = 0;
  /**
   * \return the offset in bytes from the start of the buffer to the start of
   *         this part
   */
  virtual ptrdiff_t getDataOffset() = 0;
  virtual size_t getDataSize() = 0;
  virtual GenTL::PARTDATATYPE_IDS getDataType() const = 0;
  virtual uint64_t getDataFormat() const = 0;
  virtual GenTL::PIXELFORMAT_NAMESPACE_IDS getDataFormatNamespace() const = 0;
  virtual size_t getWidth() const = 0;
  virtual size_t getConfiguredHeight() const = 0;
  virtual size_t getXOffset() const = 0;
  virtual size_t getYOffset() const = 0;
  virtual size_t getXPadding() const = 0;
  virtual uint64_t getSourceId() const = 0;
  virtual size_t getDeliveredHeight() const = 0;

  virtual uint64_t getInfo64(uint32_t customCommand) const = 0;
};

}
