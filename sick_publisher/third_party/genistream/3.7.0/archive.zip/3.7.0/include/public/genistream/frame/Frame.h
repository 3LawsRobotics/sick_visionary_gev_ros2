// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "genistream/GenIStreamDll.h"
#include "IFrame.h"

namespace genistream { namespace frame {

class Region;

/**
 * This is a concrete implementation of the \ref IFrame interface which can be
 * used to build frames with \ref Region%s and \ref Component%s.
 *
 * There are public functions within this class, not exposed in the \ref IFrame
 * interface, for building.
 *
 * \note This class currently supports only a single region in the write/save
 *       functionality.
 */
#ifdef SWIG
class GENISTREAM_API Frame : public IFrame
#else
class GENISTREAM_API Frame : public IFrame, public std::enable_shared_from_this<Frame>
#endif
{
public:
  /** Creates a frame. */
  static std::shared_ptr<Frame> create();

  /** Sets the frame ID. */
  std::shared_ptr<Frame> frameId(uint64_t frameId);
  /** Sets whether the frame is incomplete. */
  std::shared_ptr<Frame> incomplete(bool isIncomplete);
  /** Sets the line metadata. */
  std::shared_ptr<Frame> lineMetadata(ConstLineMetadataVectorPtr lineMetadata);
  /** Sets the frame metadata. */
  std::shared_ptr<Frame> frameMetadata(FrameMetadata frameMetadata);

  /**
   * Sets arbitrary, additional information attached to frame, e.g., regarding
   * the state of the system during acquisition.
   *
   * \incubating
   */
  std::shared_ptr<Frame> additionalInfo(std::string info);

  /**
   * Sets the \ref gentlcpp::Buffer the frame is created from, if that is the
   * source.
   *
   * \lowlevel
   */
  std::shared_ptr<Frame> buffer(std::weak_ptr<gentlcpp::IBuffer> buffer);

  /**
   * \return the \ref Region with the \ref RegionId or nullptr if it has not
   *         been added
   */
  std::shared_ptr<Region> findRegion(RegionId regionId) const;

  /**
   * Adds a \ref Region to the frame.
   *
   * \return the created \ref Region object
   * \throws GenIStreamException if the \ref RegionId has already been added
   */
  std::shared_ptr<Region> addRegion(RegionId regionId);

  /**
   * Adds a \ref Region to the frame and lets you modify the Region object in a
   * lambda.
   *
   * \return the frame itself
   * \throws GenIStreamException if the \ref RegionId has already been added
   */
  std::shared_ptr<Frame> addRegion(
    RegionId regionId,
    std::function<void(std::shared_ptr<Region>)> modifyRegion);

  size_t getDeliveredLineCount() const override;
  size_t getConfiguredLineCount() const override;
  bool hasLineCount() const override;
  bool wasEndedEarly() const override;

  RegionList getRegions() override;
  bool hasRegion(RegionId regionId) const override;
  std::shared_ptr<IRegion> getRegion(RegionId regionId) override;

  std::shared_ptr<const IComponent> getComponent(ComponentId componentId)
    const override;

  ConstLineMetadataVectorPtr getLineMetadata() const override;
  const FrameMetadata& getFrameMetadata() const override;
  std::string getAdditionalInfo() const override;

  uint64_t getFrameId() const override;
  bool isIncomplete() const override;

  void release() override;

  void save(const std::string& filePath,
            SaveCalibratedMode mode = SaveCalibratedMode::RANGE_AS_UNSIGNED)
    const override;
  void write(std::ostream & xmlStream,
             std::ostream & datStream,
             SaveCalibratedMode mode = SaveCalibratedMode::RANGE_AS_UNSIGNED)
    const override;

  std::weak_ptr<gentlcpp::IBuffer> getBuffer() override;
  std::shared_ptr<IFrame> copy() const override;
  std::shared_ptr<IFrame> concatenate(std::shared_ptr<const IFrame> other)
    const override;
  static std::shared_ptr<IFrame> concatenate(
    const std::vector<std::shared_ptr<const IFrame>>& frames);

protected:
  Frame();

private:
  std::vector<std::shared_ptr<Region>> mRegions;
  FrameMetadata mFrameMetadata;
  ConstLineMetadataVectorPtr mLineMetadata;

  // Meta information stored to allow access even if the device is disconnected
  uint64_t mFrameId = 0;
  bool mIsIncomplete = false;

  // Note: Avoid accessing the buffer. All interesting information should be
  // cached in this object to be able to handle a case where the device is
  // disconnected.
  std::weak_ptr<gentlcpp::IBuffer> mBuffer;

  std::string mAdditionalInfo;

// To allow implementing the deprecated getBuffer() function
#pragma warning(suppress : 4996)
};

}}
