// Copyright 2021-2023 SICK AG. All rights reserved.
#pragma once

#include "BasicTypes.h"
#include "IModule.h"
#include "../genistream/GenIStreamDll.h"

#include <chrono>
#include <vector>

namespace gentlcpp {

class IInterface;
class IInterfaceInfo;
class Port;

/**
 * Represents the GenTL system module, also known as transport layer.
 *
 * \see \ref Producer::openTransportLayer() to get a shared pointer to the
 *      instance
 */
class GENISTREAM_API ITransportLayer : public IModule
{
public:
  virtual std::shared_ptr<IEvent>
  registerEvent(GenTL::EVENT_TYPE_LIST eventType) override = 0;

  virtual bool updateInterfaceList(std::chrono::milliseconds timeout) = 0;
  virtual std::shared_ptr<Port> getPort() = 0;
  virtual std::vector<std::shared_ptr<const IInterfaceInfo>>
  getInterfaces() = 0;
  virtual GenTL::TL_HANDLE getHandle() = 0;

  virtual std::shared_ptr<IInterface>
  openInterface(const InterfaceId& interfaceId) = 0;

  virtual std::string getModel() const = 0;
  virtual std::string getVersion() const = 0;
};

}
