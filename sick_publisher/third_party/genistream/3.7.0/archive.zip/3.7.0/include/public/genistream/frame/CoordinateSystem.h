// Copyright 2019-2023 SICK AG. All rights reserved.
#pragma once

#include "genistream/GenIStreamDll.h"
#include "genistream/CameraParameters.h"

#include <cstdint>
#include <limits>

namespace genistream { namespace frame {

/** Unit of data in a \ref genistream::frame::IComponent. */
enum class Unit
{
  MILLIMETER,
  PIXEL
};

/** \return the unit as a readable string */
std::string toString(Unit unit);

/**
 * A type of coordinate.
 *
 * The A, B, C coordinate types describe an axis of a 3D position. More
 * information can be found in <a
 * href="https://www.emva.org/wp-content/uploads/GenICam_SFNC_v2_6.pdf">GenICam
 * SFNC 2.6</a> section 21.4 Scan 3D Features.
 *
 * For a line scan device (A, B, C) is an (X, Y, Z) coordinate. Mono is used for
 * all data which describes scalar values, e.g., reflectance, rather than a
 * position.
 *
 * \deprecated
 * \deprecatedsince 3.4
 */
enum class CoordinateType
{
  A,
  B,
  C,
  Mono
};

/**
 * Information on an axis to be able to linearly transform a value to an
 * absolute coordinate system.
 */
struct GENISTREAM_API AxisTransform
{
  bool operator==(const AxisTransform& rhs) const;
  bool operator!=(const AxisTransform& rhs) const;

  bool compare(const AxisTransform& rhs, double allowedFraction = 0.0) const;

  /** \return the value transformed using scale and offset */
  double apply(double value) const { return value * scale + offset; }

  /** \return the min value in the transformed value space */
  double transformedMin() const { return apply(scale >= 0 ? min : max); }

  /** \return the max value in the transformed value space */
  double transformedMax() const { return apply(scale >= 0 ? max : min); }

  /**
   * Minimum axis value in raw values, i.e., before scale and offset are
   * applied.
   */
  double min = -std::numeric_limits<double>::infinity();

  /**
   * Maximum axis value in raw values, i.e., before scale and offset are
   * applied.
   */
  double max = std::numeric_limits<double>::infinity();

  /** Scale of axis values. */
  double scale = 1.0;

  /** Offset of axis values. */
  double offset = 0.0;
};

/**
 * Represents coordinate information for a specific axis.
 *
 * Axis holds coordinate information that can be gained from frame metadata
 * carried as GenICam chunks. More information can be found in <a
 * href="https://www.emva.org/wp-content/uploads/GenICam_SFNC_v2_6.pdf">GenICam
 * SFNC 2.6</a> section 23.58 to 23.68 Chunk Data Control.
 */
struct GENISTREAM_API Axis
{
  bool operator==(const Axis& rhs) const;
  bool operator!=(const Axis& rhs) const;

  bool compare(const Axis& rhs, double allowedFraction = 0.0) const;

  /**
   * Corresponds to ChunkScan3dAxisMax, ChunkScan3dAxisMin,
   * ChunkScan3dCoordinateScale and ChunkScan3dCoordinateOffset.
   */
  AxisTransform transform;

  /**
   * Indicates whether the axis has a specific value representing missing data.
   *
   * If the axis contains missing data that value is available in \ref
   * missingDataValue. This corresponds to ChunkScan3dInvalidDataFlag.
   */
  bool missingData = false;

  /**
   * MissingData value on the axis, corresponds to ChunkScan3dInvalidDataValue.
   */
  double missingDataValue = 0;

private:
  friend struct CoordinateSystem;
  friend std::ostream& operator<<(std::ostream&, const Axis&);
  void logTo(std::ostream& s, size_t indentLevel) const;
};

/** Logs information about a \ref Axis. */
std::ostream& operator<<(std::ostream& s, const Axis& axis);

/**
 * Generic 3D coordinate system.
 *
 * The defined coordinate systems are right-hand oriented Cartesian (X,Y,Z),
 * Spherical (Theta, Phi, Rho), Cylindrical (Theta, Y,Rho) and (X,Y,R) for
 * Ranger/Ruler cameras. <a
 * href="https://supportportal.sick.com/faq/ranger3calibration/">Ranger
 * Calibration Principles</a> contains more information regarding Ranger/Ruler
 * specific coordinate systems.
 *
 * More information regarding different coordinate systems can be found in <a
 * href="https://www.emva.org/wp-content/uploads/GenICam_SFNC_v2_6.pdf">GenICam
 * SFNC 2.6</a> section 21.2.1 Coordinate systems.
 */
struct GENISTREAM_API CoordinateSystem
{
  bool operator==(const CoordinateSystem& rhs) const;
  bool operator!=(const CoordinateSystem& rhs) const;

  bool compare(const CoordinateSystem& rhs, double allowedFraction = 0.0) const;

  /** The a-axis represents a X or Theta axis. */
  Axis a;

  /** The b-axis represents a Y or Phi axis. */
  Axis b;

  /**
   * The c-axis represents a Z, R or Rho axis.
   *
   * Always represents the distance coordinate.
   */
  Axis c;

  /**
   * Unit of data in a region, corresponds to ChunkScan3dDistanceUnit. This is
   * the unit of the data after axis transform has been applied.
   */
  Unit unit = Unit::PIXEL;

private:
  friend class Component;
  friend class Region;
  friend std::ostream& operator<<(std::ostream&, const CoordinateSystem&);
  void logTo(std::ostream& s, size_t indentLevel) const;
};

/** Logs information about a \ref CoordinateSystem. */
std::ostream& operator<<(std::ostream& s, const CoordinateSystem& system);

/**
 * Creates a coordinate system where the axis transforms coordinates to
 * themselves.
 *
 * \internal
 */
AVOID CoordinateSystem createIdentitySystem(PixelFormat pixelFormat,
                                            size_t width);

}}
