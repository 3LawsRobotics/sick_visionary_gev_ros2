// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include "BasicTypes.h"
#include "IBuffer.h"
#include "IModule.h"

#include <TLI/GenTL.h>
#include "../genistream/GenIStreamDll.h"


#include <memory>

namespace gentlcpp {

class INewBufferEvent;
class Port;

/**
 * Represents a data stream from a device in the GenTL data stream module.
 *
 * \see \ref IDevice::openDataStream() to get an instance
 */
class GENISTREAM_API IDataStream : public IModule
{
public:
  virtual GenTL::DS_HANDLE getHandle() = 0;

  virtual std::shared_ptr<IEvent>
  registerEvent(GenTL::EVENT_TYPE_LIST eventType) override = 0;
  virtual std::shared_ptr<INewBufferEvent> registerNewBufferEvent() = 0;

  virtual std::shared_ptr<Port> getPort() = 0;

  virtual std::shared_ptr<IBuffer>
  announceBuffer(void* pOutBuffer, size_t size, BufferUserData userPointer) = 0;

  virtual BufferUserData
  revokeBuffer(std::shared_ptr<const IBuffer> buffer) = 0;

  /** Queues the buffer with the option to clear it or not. */
  virtual void queueBuffer(std::shared_ptr<IBuffer> buffer) = 0;

  virtual void flushQueue(GenTL::ACQ_QUEUE_TYPE_LIST operation) = 0;

  virtual void startAcquisition(GenTL::ACQ_START_FLAGS_LIST startFlags,
                                int64_t numToAcquire) = 0;
  virtual void stopAcquisition(GenTL::ACQ_STOP_FLAGS_LIST stopFlags) = 0;

  virtual DataStreamId getId() const = 0;
  virtual uint64_t getDeliveredCount() const = 0;
  virtual uint64_t getUnderrunCount() const = 0;
  virtual size_t getAnnouncedCount() const = 0;
  virtual size_t getQueuedCount() const = 0;
  virtual size_t getAwaitingDeliveryCount() const = 0;
  virtual uint64_t getStartedCount() const = 0;
  virtual size_t getPayloadSize() const = 0;
  virtual bool isGrabbing() const = 0;
  virtual bool definesPayloadSize() const = 0;
  virtual std::string getTransportLayerType() const = 0;
  virtual size_t getMaxChunkCount() const = 0;
  virtual size_t getMinBufferAnnounceCount() const = 0;
  virtual size_t getBufferAlignment() const = 0;
};

}
