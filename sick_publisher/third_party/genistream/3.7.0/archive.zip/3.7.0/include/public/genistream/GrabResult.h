// Copyright 2022-2023 SICK AG. All rights reserved.
#pragma once

#include "GenIStreamDll.h"
#include "WaitResult.h"
#include <memory>

namespace genistream {

namespace frame {
class IFrame;
}

/**
 * Result type when grabbing frames with \ref
 * FrameGrabber::grabNext(std::chrono::milliseconds). Container that contains a
 * \ref frame::IFrame if the grab was successful.
 *
 * If the grab operation timed out the result will be indicated as such. If the
 * grabber was stopped, the result will be indicated as aborted.
 *
 * When using \ref FrameGrabber::DeliveryMode::FIFO and frames have been lost
 * for some reason, the result will indicate it and not contain a frame. Entire
 * frames can be lost if there is so much packet loss on the transport layer
 * that the frame cannot be reconstructed even after requesting resends from the
 * camera, or if too few buffers have been allocated in the grabber. Frame loss
 * is detected when frame IDs are not consecutive, i.e., the found frame is
 * immediately available and is returned in the next grab call. Note that when
 * using \ref FrameGrabber::DeliveryMode::NEWEST_ONLY lost frames are not
 * considered a fault and thus the frame is returned immediately.
 *
 * The result also makes a distinction between incomplete and complete frames.
 * Incomplete frame means that some part of the data was not received, i.e., the
 * image or metadata is corrupt.
 *
 * \see \ref frame::IFrame::isIncomplete().
 * \incubating
 */
class GENISTREAM_API GrabResult
{
public:
  static GrabResult createWithFrame(std::shared_ptr<frame::IFrame> frame);
  static GrabResult lost(uint64_t firstLostFrameId, size_t lostFrameCount);
  static GrabResult aborted();
  static GrabResult timedOut();

  /** \return true if the result contains a complete frame */
  bool hasCompleteFrame() const { return mStatus == Status::COMPLETE_FRAME; }
  /** \return true if the result contains an incomplete frame */
  bool hasIncompleteFrame() const
  {
    return mStatus == Status::INCOMPLETE_FRAME;
  }
  /** \return true if the result contains a frame, complete or incomplete */
  bool hasFrame() const { return mFrame != nullptr; }

  /** \return true if the result indicates that some frames have been lost */
  bool hasLostFrames() const { return mStatus == Status::LOST; }
  /**
   * \return true if the grab operation was aborted, i.e., if the camera was
   *         spontaneously disconnected or another thread stopped the \ref
   *         FrameGrabber
   */
  bool hasAborted() const { return mStatus == Status::ABORTED; }
  /**
   * \return true if the grab operation timed out, i.e., there was no available
   *         frame within the specified timeout
   */
  bool hasTimedOut() const { return mStatus == Status::TIMED_OUT; }

  /**
   * \param throwIfIncomplete controls whether an incomplete frame is considered
   *        OK
   * \return the frame if the result contains a frame and considered OK
   * \throws GenIStreamException if the result contains no frame, i.e., timed
   *         out or aborted, or the frame is not considered OK
   */
  std::shared_ptr<frame::IFrame>
  getOrThrow(bool throwIfIncomplete = true) const;

  /**
   * \return the frame ID of the first detected lost frame
   * \throws GenIStreamException if the result does not indicate lost frames
   */
  uint64_t getFirstLostFrameId() const;
  /**
   * \return the number of frames in the range of detected lost frames
   * \throws GenIStreamException if the result does not indicate lost frames
   */
  size_t getLostFrameCount() const;

  /** Executes an action on the attached frame, if available and complete. */
  const GrabResult& ifCompleteFrame(
    std::function<void(std::shared_ptr<frame::IFrame>)> action) const;

  /** Executes an action on the attached frame, if available and incomplete. */
  const GrabResult& ifIncompleteFrame(
    std::function<void(std::shared_ptr<frame::IFrame>)> action) const;

  /**
   * Executes an action if the grab operation discovered lost frames.
   *
   * The first argument to the action is the first lost frame ID, and the second
   * argument is the number of lost frames.
   */
  const GrabResult&
  ifLostFrames(std::function<void(uint64_t, size_t)> action) const;

  /**
   * Executes an action if the grab operation was aborted, i.e., if the camera
   * was spontaneously disconnected or another thread stopped the \ref
   * FrameGrabber.
   */
  const GrabResult& ifAborted(std::function<void()> action) const;

  /**
   * Executes an action if the grab operation timed out, i.e., there was no
   * available frame within the specified timeout.
   */
  const GrabResult& ifTimedOut(std::function<void()> action) const;

private:
  enum class Status
  {
    COMPLETE_FRAME,
    INCOMPLETE_FRAME,
    LOST,
    ABORTED,
    TIMED_OUT
  };

private:
  explicit GrabResult(Status status);

private:
  Status mStatus;
  std::shared_ptr<frame::IFrame> mFrame;
  uint64_t mFirstLostFrameId = 0;
  size_t mLostFrameCount = 0;
};

}
