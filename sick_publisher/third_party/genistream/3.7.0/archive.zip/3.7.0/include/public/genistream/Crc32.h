// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "GenIStreamDll.h"

#include <cstdint>
#include <istream>

namespace genistream {

/**
 * Helper class to calculate the CRC32 checksum using the polynomial used by
 * Ethernet/PKZip.
 */
class GENISTREAM_API Crc32
{
public:
  Crc32();

  /** Calculates the CRC32 checksum for the contents of the stream. */
  uint32_t calculate(std::istream& stream) const;

  /** Calculates the CRC32 checksum for the contents of a file. */
  uint32_t calculate(const std::string& path) const;

  /**
   * Calculates the CRC32 checksum of binary data.
   *
   * \param data for which to calculate the checksum
   * \param length number of bytes in the data array
   * \param startChecksum start value for the algorithm. Useful when calculating
   *        the checksum of data that is divided into different parts. The
   *        output of one calculation is then used as the start checksum of the
   *        next.
   * \returns the calculated checksum
   */
  uint32_t calculate(const uint8_t* data,
                     size_t length,
                     uint32_t startChecksum = 0) const;

private:
  uint32_t mLookup[256];
};

}
