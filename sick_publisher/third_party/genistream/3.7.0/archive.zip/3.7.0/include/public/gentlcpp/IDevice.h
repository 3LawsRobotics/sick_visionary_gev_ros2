// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "IDataStream.h"
#include "../genistream/GenIStreamDll.h"

#include <TLI/GenTL.h>
#include <memory>
#include <vector>

namespace gentlcpp {

class IEvent;
class IInterface;
class Port;

/**
 * Represents a device in the GenTL the device module.
 *
 * \see \ref Interface::openDevice() to get an instance
 */
class GENISTREAM_API IDevice : public IModule
{
public:
  virtual void disconnect() = 0;
  /**
   * \return true if connected to a device and false if \ref disconnect() has
   *         been called. Spontaneously lost connection is not detected by this
   *         function unless \ref disconnect() has been explicitly called.
   */
  virtual bool isConnected() const = 0;

  virtual GenTL::DEV_HANDLE getHandle() = 0;
  virtual std::shared_ptr<IInterface> getParent() const = 0;

  virtual std::shared_ptr<IEvent>
  registerEvent(GenTL::EVENT_TYPE_LIST eventType) override = 0;

  virtual std::vector<DataStreamId> getDataStreamIds() const = 0;
  virtual std::shared_ptr<IDataStream>
  openDataStream(const DataStreamId& dataStreamId) = 0;

  virtual std::shared_ptr<Port> getLocalPort() = 0;
  virtual std::shared_ptr<Port> getRemotePort() = 0;
  virtual DeviceId getId() const = 0;
  virtual std::string getVendor() const = 0;
  virtual std::string getModel() const = 0;
  virtual std::string getTransportLayerType() const = 0;
  virtual std::string getDisplayName() const = 0;
  virtual GenTL::DEVICE_ACCESS_STATUS_LIST getAccessStatus() const = 0;
  virtual std::string getUserDefinedName() const = 0;
  virtual std::string getSerialNumber() const = 0;
  virtual std::string getVersion() const = 0;
};

}
