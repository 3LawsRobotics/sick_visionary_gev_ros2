// Copyright 2019-2023 SICK AG. All rights reserved.
#pragma once

#include <cstdint>
#include <string>

#include "GenIStreamDll.h"

namespace genistream {

/** A representation of an IP v4 address. */
class GENISTREAM_API Ip4Address
{
public:
  /** \param address the address as an integer in host byte order */
  explicit Ip4Address(uint32_t address);
  /**
   * \param address the address as dot separated string
   * \throws InvalidIpAddress if the format is invalid
   */
  explicit Ip4Address(const std::string& address);

  /** \return the IP address as an integer in host byte order */
  uint32_t value() const;

  /** \return the IP address as dot separated string */
  std::string toString() const;

  bool operator==(const Ip4Address& rhs) const
  {
    return mAddress == rhs.mAddress;
  }

private:
  uint32_t mAddress;
};

class GENISTREAM_API IpAddressPair
{
public:
  IpAddressPair(Ip4Address ip, Ip4Address subnet)
    : ipAddress(ip)
    , subnetMask(subnet)
  {
  }
  Ip4Address getIpAddress() const { return ipAddress; }
  Ip4Address getSubnetMask() const { return subnetMask; }

private:
  Ip4Address ipAddress;
  Ip4Address subnetMask;
};

}
