// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "genistream/GenIStreamDll.h"
#include "genistream/frame/Aoi.h"
#include "genistream/frame/CoordinateSystem.h"
#include "genistream/frame/IComponent.h"

namespace genistream { namespace frame {

/**
 * Abstraction of a region within a \ref IFrame. Each IRegion contains \ref
 * IComponent%s.
 *
 * \note This object depends on its parent \ref IFrame object and \ref
 *       FrameGrabber object, i.e., to use this object you must ensure these are
 *       not destroyed. Otherwise the underlying buffer may have been
 *       deallocated or re-used by GenTL for a new frame, i.e., the data may
 *       have been replaced.
 */
class GENISTREAM_API IRegion
{
public:
  virtual ~IRegion() = default;

  /** \return the \ref RegionId of the region */
  virtual RegionId getId() const = 0;

  /**
   * \note It is important that you keep a reference to the parent \ref IFrame
   *       since it manages the memory that is accessed via the \ref IComponent.
   * \return the \ref IComponent%s within the region
   */
  virtual ConstComponentList getComponents() const = 0;

  /**
   * \return true if the region contains a \ref IComponent with the given \ref
   *         ComponentId
   */
  virtual bool hasComponent(ComponentId componentId) const = 0;

  /**
   * \note It is important that you keep a reference to the parent \ref IFrame
   *       since it manages the memory that is accessed via the \ref IComponent.
   * \return the object for a specific ComponentId
   * \throws std::invalid_argument if the ComponentId is not available
   */
  virtual std::shared_ptr<const IComponent>
  getComponent(ComponentId componentId) const = 0;

  /**
   * \return the area of interest on the sensor for the region. No assumptions
   *         can be made on these dimensions and relation to data dimensions,
   *         e.g., calibrated/rectified data might have a width that differs
   *         from the number of columns on the sensor.
   */
  virtual Aoi getAoi() const = 0;

  /**
   * \return the coordinate system for the range component in the region
   * \throws NotAvailableException if the region does not have a range
   *         component, e.g., if it is for a sensor image
   * \deprecated Prefer using \ref IComponent::getCoordinateSystem() for the
   *             range component.
   */
  AVOID virtual const CoordinateSystem& getRangeSystem() const = 0;

  /**
   * \return the data resolution in the Y direction, i.e., the distance in
   *         millimeters between profiles. This is another name for the B
   *         coordinate axis scale value. Unless changed via \ref
   *         setYResolution() this is the value delivered from the camera.
   * \incubating This may move to \ref IFrame.
   */
  virtual double getYResolution() const = 0;

  /**
   * Sets the data resolution in the Y direction, i.e., the distance in
   * millimeters between profiles.
   *
   * \incubating This may move to \ref IFrame.
   */
  virtual void setYResolution(double yResolution) = 0;

  /**
   * \return the extraction method of the region, e.g., indicating the algorithm
   *         to extract range data from the sensor image
   * \throws NotAvailableException if the region is for a sensor image
   */
  virtual Scan3dExtractionMethod getExtractionMethod() const = 0;

  /**
   * \return the output mode of the region, indicating whether data is
   *         calibrated and/or rectified.
   * \throws NotAvailableException if the region is for a sensor image
   */
  virtual Scan3dOutputMode getOutputMode() const = 0;

  /**
   * \return a copy of this \ref IRegion, including all \ref IComponent%s. The
   *         image data in components are is always copied, so the original \ref
   *         IRegion can be released to allow GenTL buffer reuse.
   */
  virtual std::shared_ptr<IRegion> copy() const = 0;

  /**
   * Logs information about a \ref IRegion and the \ref IComponent%s in it.
   *
   * \incubating Prefer using operator<<().
   */
  virtual void logTo(std::ostream& s, size_t indentLevel) const = 0;
};

typedef std::vector<std::shared_ptr<IRegion>> RegionList;
typedef std::vector<std::shared_ptr<const IRegion>> ConstRegionList;

/** Compares the regions, including meta-information and actual image data. */
bool operator==(const IRegion& lhs, const IRegion& rhs);

/** Compares the regions, including meta-information and actual image data. */
bool operator!=(const IRegion& lhs, const IRegion& rhs);

/**
 * Compares the regions, including meta-information and actual image data.
 *
 * \param lhs the left-hand side IRegion
 * \param rhs the right-hand side IRegion
 * \param allowedFraction the allowed difference fraction between
 *        meta-information that is floating point
 * \return true if the regions are considered equal
 */
bool compare(const IRegion& lhs,
             const IRegion& rhs,
             double allowedFraction = 0.0);

/** Logs information about a \ref IRegion and the \ref IComponent%s in it. */
std::ostream& operator<<(std::ostream& s, const IRegion& region);

}}
