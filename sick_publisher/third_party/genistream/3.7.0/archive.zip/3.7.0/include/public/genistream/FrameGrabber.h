// Copyright 2019-2023 SICK AG. All rights reserved.
#pragma once

#include "Avoid.h"
#include "BufferManager.h"
#include "BufferStatus.h"
#include "ChunkAdapter.h"
#include "GenIStreamDll.h"
#include "GrabResult.h"
#include "NodeMap.h"
#include "WaitResult.h"

#include <atomic>
#include <chrono>
#include <memory>

namespace std {
class recursive_mutex;
class thread;
}

namespace gentlcpp {
class IBuffer;
class IDataStream;
class IDevice;
class INewBufferEvent;
}

namespace genistream {
class FrameGrabberInternals;
namespace frame {
class IFrame;
class IAdditionalInfoBuilder;
struct FrameConfigurationInfo;
class GenTlFrameFactory;
}

/* Note: the original Windows GenIStream raises grabbing thread priority by default under Windows.
 * That step is currently skipped in the Linux version, until the final approach is decided in the
 * future fully generalized GenIStream version. We assume the priority boost will not be essential
 * under Linux and anyway is handled slightly differently (policies...) and requires privileges.
 * To be revised only if there are known runtime issues. */
#ifdef WIN32
#define GRAB_THREAD_DEFAULT_PRIORITY THREAD_PRIORITY_HIGHEST
#else
#define GRAB_THREAD_DEFAULT_PRIORITY 0
#endif

/**
 * Allows grabbing frames from a camera.
 *
 * This class takes care of memory allocation and starting of both the GenTL
 * acquisition engine and telling the camera to start acquisition.
 *
 * \note In C# you are required to explicitly dispose the object when you are
 *       done with it, to ensure that underlying resources are released
 *       immediately and are not kept open until garbage collection occurs. In
 *       C++ this is handled in a RAII fashion by ensuring all
 *       `std::shared_ptr`%s to the object are released.
 * \note This object depends on its parent \ref ICamera object, i.e., to use
 *       this object you must ensure the \ref ICamera object is connected and
 *       not destroyed.
 * \see \ref md_doc_frame-queue-design
 */
#ifdef SWIG
class GENISTREAM_API FrameGrabber
#else
class GENISTREAM_API FrameGrabber : public std::enable_shared_from_this<FrameGrabber>
#endif
{
public:
  /**
   * Different delivery behaviors, i.e., how to treat frames waiting to be
   * grabbed by the user.
   *
   * This enumeration corresponds to the `StreamBufferHandlingMode` parameter on
   * the GenTL data stream node map.
   */
  enum class DeliveryMode
  {
    /**
     * The default is to deliver all frames as they are received from the
     * camera, i.e., in a first-in-first-out style. This is the behavior most
     * applications use since usually all images are of interest.
     *
     * This value corresponds to `StreamBufferHandlingMode` `OldestFirst`.
     */
    FIFO,
    /**
     * Only deliver the latest received frame from the camera when grabbing.
     * This behavior is used by applications that is only interested in the most
     * recent information, e.g., useful for a GUI that shows a "live image" and
     * might not be able to draw images in the same pace as received from the
     * camera.
     *
     * For frames that are discarded, the underlying buffers are automatically
     * re-queued to be filled again. This means you can normally create your
     * FrameGrabber with only 3 buffers when this mode is used; one buffer for
     * frame currently being filled, one buffer for frame waiting to be
     * "grabbed" by user and one buffer for frame currently being processed by
     * user.
     *
     * This value corresponds to `StreamBufferHandlingMode` `NewestOnly`
     *
     * \note Even when using \refcpp{subscribeToFrames()}
     *       \refcs{FrameGrabber.Next} to get callbacks, some frames may be
     *       discarded if the time to process the frame in the callback is
     *       greater than the time between receiving images from the camera.
     */
    NEWEST_ONLY,
  };

  /**
   * Result type when grabbing frames with \ref grab(). Container that contains
   * a \ref frame::IFrame if the grab completed.
   *
   * If the grab operation timed out the result will be indicated as such. If
   * the grabber was stopped, the result will be indicated as aborted.
   *
   * \see \ref WaitResult
   * \deprecated Prefer using \ref GrabResult with \ref grabNext().
   * \deprecatedsince 3.2
   */
  typedef WaitResult<std::shared_ptr<frame::IFrame>> IFrameWaitResult;

  /**
   * Result type when grabbing frame with \ref grabRaw(). Container that
   * contains a \ref gentlcpp::IBuffer if the grab completed.
   *
   * If the grab operation timed out the result will be indicated as such. If
   * the grabber was stopped, the result will be indicated as aborted.
   *
   * \see \ref WaitResult
   */
  typedef WaitResult<std::shared_ptr<gentlcpp::IBuffer>> IBufferWaitResult;

  /**
   * Callback function to receive notification when new frames are received,
   * frames are lost or grabbing is aborted.
   *
   * \see \ref subscribeToFrames()
   * \incubating
   */
  typedef std::function<void(const GrabResult&)> GrabResultCallback;

  /**
   * Callback function to receive notification when new frames are received.
   *
   * \see \ref subscribeToFrames()
   * \deprecated Prefer using \ref GrabResultCallback with \ref
   *             subscribeToFrames().
   * \deprecatedsince 3.2
   */
  typedef std::function<void(std::shared_ptr<frame::IFrame>)> FrameCallback;

public:
  /**
   * Creates a FrameGrabber instance and allocates buffers that will be used to
   * store received frames. See \ref ICamera::createFrameGrabber() for more
   * information.
   *
   * \see \ref md_doc_frame-queue-design
   * \param cameraNodeMap node map to the remote device
   * \param chunkAdapter chunk adapter for reading chunks from GigEVision
   * \param device the GenTL device associated with the camera
   * \param dataStream the data stream from the camera
   * \param dataStreamParameters parameters interface for node map to the data
   *        stream
   * \param bufferCount the number of buffers to allocate
   * \param additionalInfoBuilder builder of additional info XML which is
   *        attached to each grabbed frame
   * \lowlevel Prefer using \ref ICamera::createFrameGrabber().
   */
  AVOID static std::shared_ptr<FrameGrabber> create(
    std::shared_ptr<NodeMap> cameraNodeMap,
    std::shared_ptr<frame::IAdditionalInfoBuilder> additionalInfoBuilder,
    std::unique_ptr<ChunkAdapter> chunkAdapter,
    std::shared_ptr<gentlcpp::IDevice> device,
    std::shared_ptr<gentlcpp::IDataStream> dataStream,
    std::shared_ptr<IAnyParameters> dataStreamParameters,
    size_t bufferCount);

  ~FrameGrabber();

  /**
   * Starts acquisition of both camera and receiver.
   *
   * \param mode the deliver mode to use for frames.
   * \note If you changed any configuration parameter on the camera after
   *       creating the FrameGrabber, you should create a new instance before
   *       starting acquisition.
   * \throws DisconnectedException if the camera is disconnected
   * \throws GenIStreamException if this grabber has already been started, if
   *         the camera did not allow starting acquisition or if the
   *         configuration of the camera has changed so that the payload size is
   *         different than when this grabber was created.
   */
  void start(DeliveryMode mode = DeliveryMode::FIFO);

  /** Stops acquisition of both the camera and receiver. */
  void stop();

  /**
   * Stops the camera acquisition.
   *
   * This is useful if the camera should stop acquiring frames, but the receiver
   * should continue processing everything in the queue. You can still call \ref
   * grabNext(std::chrono::milliseconds) to get frames from the queue.
   */
  void stopCamera();

  /**
   * \return true if acquisition has been started. Will still return true if
   *         \ref stopCamera() has been called.
   */
  bool isStarted() const;

  /**
   * \return true if acquisition is the camera is acquiring frames, i.e.,
   *         \refcpp{start()} \refcs{FrameGrabber.Start(DeliveryMode)} has been
   *         called and neither \ref stopCamera() or \ref stop() have been
   *         called.
   */
  bool isCameraStarted() const;

  /** \return the number of bytes of allocated buffer memory */
  size_t getFrameBufferSize() const;

  /**
   * Get the number of frames available in buffers, i.e., received already from
   * the camera but not grabbed from this object.
   *
   * \return the number of frames already available in buffers
   */
  size_t getAvailableCount() const;

  /**
   * Get the next \ref frame::IFrame available in a \ref GrabResult.
   *
   * If no frame is available the function blocks until one is available, the
   * grabber is stopped, the camera is disconnected or the timeout is reached.
   * If the function times out, a timed out \ref GrabResult without a frame is
   * returned. If the camera is disconnected, the function returns an aborted
   * \ref GrabResult.
   *
   * If the camera is in a disconnected state, the function immediately returns
   * an aborted \ref GrabResult.
   *
   * If frames have been lost, the function returns a result indicating what
   * frames are missing and the actually found frame will be returned in the
   * next call. If the frame is incomplete, i.e., some part of the data was not
   * successfully received from the camera, the returned result will contain a
   * frame but indicate that the frame is incomplete.
   *
   * \note In C# you are required to explicitly release any frame carried in the
   *       \ref GrabResult when you are done with it, to ensure the underlying
   *       GenTL buffer can be reused immediately rather than when garbage
   *       collection occurs. See \ref frame::IFrame::release(). In C++ this is
   *       handled in a RAII fashion by ensuring all `std::shared_ptr`%s to the
   *       object are released.
   * \see \ref HeadingIFramesInDotNet "Managing IFrames in GenIStream.Net"
   * \see \ref md_doc_frame-queue-design
   * \param timeout If a frame is not received within this period, a timed out
   *        result is returned.
   * \throws GenIStreamException if the grabber has not been started or there is
   *         an active subscription, see \refcpp{subscribeToFrames()}
   *         \refcs{FrameGrabber.Next}
   * \incubating
   */
  GrabResult grabNext(std::chrono::milliseconds timeout);

  /**
   * Get the next \ref frame::IFrame available in a \ref GrabResult.
   *
   * If no frame is available the function blocks indefinitely until one is
   * available, the grabber is stopped or the camera is disconnected. If the
   * camera is disconnected, the function returns an aborted \ref GrabResult.
   *
   * If frames have been lost, the function returns a result indicating what
   * frames are missing and the actually found frame will be returned in the
   * next call. If the frame is incomplete, i.e., some part of the data was not
   * successfully received from the camera, the returned result will contain a
   * frame but indicate that the frame is incomplete.
   *
   * \note In C# you are required to explicitly release any frame carried in the
   *       \ref GrabResult when you are done with it, to ensure the underlying
   *       GenTL buffer can be reused immediately rather than when garbage
   *       collection occurs. See \ref frame::IFrame::release(). In C++ this is
   *       handled in a RAII fashion by ensuring all `std::shared_ptr`%s to the
   *       object are released.
   * \see \ref HeadingIFramesInDotNet "Managing IFrames in GenIStream.Net"
   * \see \ref md_doc_frame-queue-design
   * \throws GenIStreamException if the grabber has not been started or there is
   *         an active subscription, see \refcpp{subscribeToFrames()}
   *         \refcs{FrameGrabber.Next}
   * \incubating
   */
  GrabResult grabNext();

  /**
   * Grab a frame and return a \refcpp{WaitResult} \refcs{IFrameWaitResult} with
   * a \ref frame::IFrame. If the camera is in a disconnected state, the
   * function immediately returns an aborted result.
   *
   * \note In C# you are required to explicitly release any frame carried in the
   *       \ref IFrameWaitResult when you are done with it, to ensure the
   *       underlying GenTL buffer can be reused immediately rather than when
   *       garbage collection occurs. See \ref frame::IFrame::release(). In C++
   *       this is handled in a RAII fashion by ensuring all `std::shared_ptr`%s
   *       to the object are released.
   * \see \ref HeadingIFramesInDotNet "Managing IFrames in GenIStream.Net"
   * \see \ref md_doc_frame-queue-design
   * \param timeout If a frame is not received within this period, a timed out
   *        result is returned.
   * \throws GenIStreamException if the grabber has not been started or there is
   *         an active subscription, see \refcpp{subscribeToFrames()}
   *         \refcs{FrameGrabber.FrameCallback}
   * \deprecated Prefer using grabNext() since it makes it easier to detect lost
   *             and incomplete frames.
   * \deprecatedsince 3.2
   */
  AVOID IFrameWaitResult grab(std::chrono::milliseconds timeout);

  /**
   * Grab a frame and return a \refcpp{WaitResult} \refcs{IFrameWaitResult} with
   * a \ref frame::IFrame, with infinite timeout. If the camera is in a
   * disconnected state, the function immediately returns an aborted result.
   *
   * The function will not return unless a frame is received or the FrameGrabber
   * is stopped. If the FrameGrabber was stopped, the result will indicate that
   * the operation was aborted.
   *
   * \note In C# you are required to explicitly release any frame carried in the
   *       \ref IFrameWaitResult when you are done with it, to ensure the
   *       underlying GenTL buffer can be reused immediately rather than when
   *       garbage collection occurs. See \ref frame::IFrame::release(). In C++
   *       this is handled in a RAII fashion by ensuring all `std::shared_ptr`%s
   *       to the object are released.
   * \see \ref HeadingIFramesInDotNet "Managing IFrames in GenIStream.Net"
   * \see \ref md_doc_frame-queue-design
   * \throws GenIStreamException if the grabber has not been started or there is
   *         an active subscription, see \refcpp{subscribeToFrames()}
   *         \refcs{FrameGrabber.FrameCallback}
   * \deprecated Prefer using grabNext() since it makes it easier to detect lost
   *             and incomplete frames.
   * \deprecatedsince 3.2
   */
  AVOID IFrameWaitResult grab();

  /**
   * Subscribes to get asynchronous notification when frames are received from
   * the camera. When the returned subscription object is destroyed,
   * unsubscription occurs and notifications end. Re-entrant unsubscription is
   * allowed, i.e., it is allowed to destroy the subscription object from the
   * \ref GrabResultCallback function.
   *
   * The callback function is never invoked with a timed out result, but will be
   * called with an aborted result if the camera is disconnected or the grabber
   * is stopped.
   *
   * \note The callback function will block the grabber thread. If you need to
   *       do extensive image processing in parallel on separate CPU cores, you
   *       should dispatch the received frames to threads in a thread pool from
   *       your callback function.
   * \warning The callback function is invoked from a different thread context!
   *          The user must ensure thread safety when handling the call.
   * \note In C# you are required to explicitly release any frame carried in the
   *       \ref GrabResult received in the callback function when you are done
   *       with it, to ensure the underlying GenTL buffer can be reused
   *       immediately rather than when garbage collection occurs. See \ref
   *       frame::IFrame::release(). In C++ this is handled in a RAII fashion by
   *       ensuring all `std::shared_ptr`%s to the object are released.
   * \see \ref HeadingIFramesInDotNet "Managing IFrames in GenIStream.Net"
   * \see \ref md_doc_event-subscriptions
   * \param onFrame the callback function that should be invoked when a frame is
   *        received from the camera
   * \param threadPriority the priority of the thread that grabs images, see
   *        https://docs.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-setthreadpriority
   * \return a \ref event::SubscriptionEnvelope carrying a \ref
   *         event::ISubscription object. The ISubscription should be kept until
   *         no more notifications are desired, destroying it will cause
   *         unsubscription. The envelope contains a mutex lock that is
   *         automatically kept until the ISubscription object is assigned to
   *         the final destination variable. This allows re-entrant
   *         unsubscription, i.e., subscription from within the callback
   *         function, without risk of using an uninitialized variable.
   * \throws DisconnectedException if the camera is disconnected
   * \throws GenIStreamException if the grabber has not been started or there is
   *         already an active subscription
   * \incubating
   */
  event::SubscriptionEnvelope subscribeToFrames(
    GrabResultCallback onFrame, int threadPriority = GRAB_THREAD_DEFAULT_PRIORITY);

  /**
   * Subscribes to get asynchronous notification when frames are received from
   * the camera. When the returned subscription object is destroyed,
   * unsubscription occurs and notifications end. Re-entrant unsubscription is
   * allowed, i.e., it is allowed to destroy the subscription object from the
   * \ref FrameCallback function.
   *
   * \note The callback function will block the grabber thread. If you need to
   *       do extensive image processing in parallel on separate CPU cores, you
   *       should dispatch the received frames to threads in a thread pool from
   *       your callback function.
   * \warning The callback function is invoked from a different thread context!
   *          The user must ensure thread safety when handling the call.
   * \note In C# you are required to explicitly release the frame received in
   *       the callback function when you are done with it, to ensure the
   *       underlying GenTL buffer can be reused immediately rather than when
   *       garbage collection occurs. See \ref frame::IFrame::release(). In C++
   *       this is handled in a RAII fashion by ensuring all `std::shared_ptr`%s
   *       to the object are released.
   * \see \ref HeadingIFramesInDotNet "Managing IFrames in GenIStream.Net"
   * \see \ref md_doc_event-subscriptions
   * \param onFrame the callback function that should be invoked when a frame is
   *        received from the camera
   * \param threadPriority the priority of the thread that grabs images, see
   *        https://docs.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-setthreadpriority
   * \return a \ref event::SubscriptionEnvelope carrying a \ref
   *         event::ISubscription object. The ISubscription should be kept until
   *         no more notifications are desired, destroying it will cause
   *         unsubscription. The envelope contains a mutex lock that is
   *         automatically kept until the ISubscription object is assigned to
   *         the final destination variable. This allows re-entrant
   *         unsubscription, i.e., subscription from within the callback
   *         function, without risk of using an uninitialized variable.
   * \throws DisconnectedException if the camera is disconnected
   * \throws GenIStreamException if the grabber has not been started or there is
   *         already an active subscription
   * \deprecated Prefer using the version of \ref subscribeToFrames that takes a
   *             \ref GrabResultCallback function as argument.
   * \deprecatedsince 3.2
   */
  AVOID event::SubscriptionEnvelope subscribeToFrames(
    FrameCallback onFrame, int threadPriority = GRAB_THREAD_DEFAULT_PRIORITY);

  /**
   * Grab a frame and return a \refcpp{WaitResult} \refcs{IBufferWaitResult}
   * with the raw GenTL buffer object. If the camera is in a disconnected state,
   * the function immediately returns an aborted result.
   *
   * The buffer must be explicitly requeued with \ref queueBuffer() when you are
   * done with it.
   *
   * \param timeout If a buffer is not received within this period, an exception
   *        will be thrown.
   * \throws GenIStreamException if the grabber has not been started or there is
   *         an active subscription, see\refcpp{subscribeToFrames()}
   *         \refcs{FrameGrabber.Next}
   * \lowlevel Prefer using \ref grabNext().
   */
  AVOID IBufferWaitResult grabRaw(std::chrono::milliseconds timeout);

  /**
   * Grab a frame and return a \refcpp{WaitResult} \refcs{IBufferWaitResult}
   * with the raw GenTL buffer object, with infinite timeout. If the camera is
   * in a disconnected state, the function immediately returns an aborted
   * result.
   *
   * The function will not return unless a buffer is received or stopped. If the
   * FrameGrabber was stopped, the WaitResult will indicate that the operation
   * was aborted. The buffer must be explicitly requeued with \ref queueBuffer()
   * when you are done with it.
   *
   * \throws GenIStreamException if the grabber has not been started or there is
   *         an active subscription, see \refcpp{subscribeToFrames()}
   *         \refcs{FrameGrabber.Next}
   * \lowlevel Prefer using \ref grabNext().
   */
  AVOID IBufferWaitResult grabRaw();

  /**
   * \return the status of the currently allocated buffers.
   * \lowlevel
   */
  BufferStatus getBufferStatus() const;

  /**
   * Gives the buffer back to the acquisition engine, so that the memory may be
   * reused for subsequent frames.
   *
   * \throws DisconnectedException if the camera is disconnected
   * \lowlevel
   */
  AVOID void queueBuffer(std::shared_ptr<gentlcpp::IBuffer> buffer);

  /**
   * \return the underlying \ref NodeMap for the camera
   * \lowlevel
   * \deprecated Prefer using \ref ICamera::getCameraParameters() or \ref
   *             ICamera::getAnyParameters() or, if necessary, \ref
   *             ICamera::getNodeMap().
   * \deprecatedsince 3.4
   */
  AVOID std::shared_ptr<NodeMap> getCameraNodeMap();

  /**
   * \return the underlying \ref gentlcpp::IDataStream
   * \lowlevel
   */
  AVOID std::shared_ptr<gentlcpp::IDataStream> getDataStream();

  /**
   * \return the underlying \ref BufferManager for the camera
   * \lowlevel
   */
  AVOID BufferManager& getBufferManager();

private:
  friend class FrameGrabberTest;

  FrameGrabber(
    std::shared_ptr<NodeMap> cameraNodeMap,
    std::shared_ptr<frame::IAdditionalInfoBuilder> additionalInfoBuilder,
    std::unique_ptr<ChunkAdapter> chunkAdapter,
    std::shared_ptr<gentlcpp::IDevice> device,
    std::shared_ptr<gentlcpp::IDataStream> dataStream,
    std::shared_ptr<IAnyParameters> dataStreamParameters,
    size_t bufferCount);

  void stopGrabThread();
  IBufferWaitResult grabInternal(std::chrono::milliseconds timeout);
  std::shared_ptr<frame::IFrame> fromBuffer(
    std::shared_ptr<gentlcpp::IBuffer> buffer);
  GrabResult grabResultFromRaw(const IBufferWaitResult& rawResult);
  IFrameWaitResult frameResultFromRaw(const IBufferWaitResult& rawResult);
  bool potentialBrokenEndBuffer() const;

  void grabberThreadLoop(GrabResultCallback onFrame, int threadPriority);

private:
  std::shared_ptr<NodeMap> mCameraNodeMap;
  std::shared_ptr<gentlcpp::IDevice> mDevice;
  std::shared_ptr<gentlcpp::IDataStream> mDataStream;
  std::shared_ptr<IAnyParameters> mDataStreamParameters;

  BufferManager mBuffers;
  size_t mPayloadSize;
  std::shared_ptr<gentlcpp::INewBufferEvent> mEvent;
  std::unique_ptr<frame::FrameConfigurationInfo> mConfigurationInfo;
  std::shared_ptr<frame::IAdditionalInfoBuilder> mAdditionalInfo;
  std::unique_ptr<frame::GenTlFrameFactory> mFrameFactory;
  std::atomic<bool> mCameraStopped{ true };

  // Thread and mutex in unique_ptr to so that we can avoid including thread.h.
  // Potentially making it possible to use this class from managed C++.
  std::unique_ptr<std::thread> mGrabThread;
  std::unique_ptr<std::recursive_mutex> mSubscriptionMutex;
  std::atomic<bool> mShouldStopGrabberThread;
  std::atomic<bool> mGrabberThreadHasStopped;

  std::unique_ptr<FrameGrabberInternals> mInternals;
  DeliveryMode mDeliveryMode = DeliveryMode::FIFO;
  uint64_t mPreviousFrameId = 0;
  // If a lost GrabResult is returned, we store the buffer to return in next
  // grab
  std::shared_ptr<gentlcpp::IBuffer> mWaitingBuffer;
};

}
