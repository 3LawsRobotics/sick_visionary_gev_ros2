// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "Avoid.h"
#include "GenIStreamDll.h"
#include "NodeMapMutex.h"
#include "event/SubscriptionEnvelope.h"
#include "util/AtScopeExit.h"

#include "CushionWinHeaders.h"
#include <GenApi/Types.h>

#include <functional>
#include <memory>

namespace genistream {

/**
 * Recommended visibility of a parameter. This enumeration reflects the
 * GenApi::EVisibility enumeration.
 *
 * \incubating
 */
enum class ParameterVisibility
{
  Beginner = 0,
  Expert = 1,
  Guru = 2,
  Invisible = 3,
};

/** A callback function that handles a node invalidation event. */
typedef std::function<void(const std::string& parameterName)>
  NodeInvalidationCallback;

/**
 * A RAII style object to clean up event suppression.
 *
 * \internal
 */
typedef util::AtScopeExit DeferredUnsuppression;

/**
 * Represents an enumeration entry globally unique identifier. It is a parameter
 * name that uniquely identifies an enum entry parameter among entries of other
 * enum parameters. An example identifier can be "FileOpenMode_EnumEntry_Read".
 * Example of other enum entry identifier where the symbolic names would
 * collide, but the identifies remain globally unique, is
 * "FileOperationSelector_EnumEntry_Read".
 *
 * \incubating
 */
typedef std::string EnumEntryUniqueId;

/**
 * Represents an enumeration entry symbolic name, a mnemonic shorthand for both
 * enum entry integer value and for the enum entry unique identifier. An example
 * can be the enum entry symbolic name "ReadWrite", instead of the integer value
 * 2 or the unique identifier "FileOpenMode_EnumEntry_ReadWrite".
 */
typedef std::string EnumEntrySymbolicName;

/**
 * Interface for reading and writing parameters.
 *
 * Unlike \ref CameraParameters, parameters are identified with strings which
 * allows you to access any parameter by name. This is convenient if a parameter
 * is not included in the automatically generated \ref CameraParameters, however
 * it reduces possibility to detect typos in compile time.
 *
 * We recommend using \ref CameraParameters as your primary way to access
 * parameters on the camera.
 *
 * \note This object depends on its parent \ref ICamera object, i.e., to use
 *       this object you must ensure the \ref ICamera object is connected and
 *       not destroyed.
 */
class GENISTREAM_API IAnyParameters
{
public:
  virtual ~IAnyParameters() = default;

  /**
   * \return the access mode of a parameter
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \deprecated Prefer using predicates \ref isImplemented(), \ref
   *             isAccessible(), \ref isReadable() and \ref isWritable()
   *             instead.
   * \deprecatedsince 2.7
   */
  AVOID virtual GenApi::EAccessMode
  getAccessMode(const std::string& parameter) const = 0;

  /**
   * \return true if the parameter is implemented. False for non-existing
   *         parameter. This value is static and will not change.
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   */
  virtual bool isImplemented(const std::string& parameter) const;

  /**
   * \return true if access mode is both available and implemented. False for
   *         non-existing parameter. This value is dynamic and can change, given
   *         changes to other parameters.
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   */
  virtual bool isAccessible(const std::string& parameter) const;

  /**
   * \return true if access mode is either "Read Only" or "Read Write". False
   *         for non-existing parameter.
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   */
  virtual bool isReadable(const std::string& parameter) const;

  /**
   * \return true if access mode is either "Write Only" or "Read Write". False
   *         for non-existing parameter.
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   */
  virtual bool isWritable(const std::string& parameter) const;

  /**
   * Some parameters are locked and cannot be changed, or executed for commands,
   * when acquisition is ongoing. This function checks whether a parameter is
   * currently locked by acquisition.
   *
   * \return true if the parameter is currently locked by acquisition.
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \incubating
   */
  virtual bool
  isParameterLockedByAcquisition(const std::string& parameter) const = 0;

  /**
   * Renamed to \ref isParameterLockedByAcquisition to clarify the meaning.
   *
   * \deprecated Prefer using \ref isParameterLockedByAcquisition
   * \deprecatedsince 3.4
   */
  AVOID virtual bool isParameterLocked(const std::string& parameter) const
  {
    return isParameterLockedByAcquisition(parameter);
  }

  /**
   * Renamed to avoid confusion with \ref lock() which locks access to the
   * underlying GenApi node map to the current thread.
   *
   * \deprecated Prefer using \ref isParameterLocked().
   * \deprecatedsince 2.9
   */
  AVOID bool isLocked(const std::string& parameter) const
  {
    return isParameterLockedByAcquisition(parameter);
  }

  /**
   * Executes a block of code with verification temporarily disabled.
   *
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   */
  virtual void withoutVerification(
    std::function<void(std::shared_ptr<IAnyParameters>)> action) = 0;

  /**
   * \return true if the parameter is a command
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   */
  virtual bool isCommand(const std::string& parameter) const = 0;

  /**
   * \return true if the parameter is a boolean
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   */
  virtual bool isBool(const std::string& parameter) const = 0;

  /**
   * \return true if the parameter is a float
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   */
  virtual bool isFloat(const std::string& parameter) const = 0;

  /**
   * \return true if the parameter is an integer
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   */
  virtual bool isInt(const std::string& parameter) const = 0;

  /**
   * \return true if the parameter is an enumeration
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   */
  virtual bool isEnum(const std::string& parameter) const = 0;

  /**
   * \return true if the parameter is a string
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   */
  virtual bool isString(const std::string& parameter) const = 0;

  /**
   * \return true if the parameter is a category
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   */
  virtual bool isCategory(const std::string& parameter) const = 0;

  /**
   * \return true if the parameter is a raw register
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   */
  virtual bool isRawRegister(const std::string& parameter) const = 0;

  /**
   * Executes a command.
   *
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the command does not exist or is not
   *         writable and available, e.g., because a register streaming session
   *         is ongoing
   * \throws GenIStreamException if the camera configuration was in an invalid
   *         state
   */
  virtual void executeCommand(const std::string& parameter,
                              bool waitForCompletion = true) = 0;

  /**
   * \return the value of a boolean parameter
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected.
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         available
   */
  virtual bool getBool(const std::string& parameter) const = 0;

  /**
   * \return the value of a float parameter
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         available
   */
  virtual float getFloat(const std::string& parameter) const = 0;

  /**
   * \return the value of an integer parameter
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected.
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         available
   */
  virtual int64_t getInt(const std::string& parameter) const = 0;

  /**
   * \return the value of an enumeration parameter as a string
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         available
   */
  virtual EnumEntrySymbolicName getEnum(const std::string& parameter) const = 0;

  /**
   * \return the value of an enumeration parameter as an integer
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         available
   */
  virtual int64_t getEnumInt(const std::string& parameter) const = 0;

  /**
   * Translates an enumeration entry unique identifier to an enum int value.
   *
   * \return the enumeration entry integer value
   * \throws ParameterAccessException if the parameter does not exist
   * \incubating
   */
  virtual int64_t
  getEnumEntryInt(const EnumEntryUniqueId& enumEntryId) const = 0;

  /**
   * \param parameter the name of the enum parameter to get entries for
   * \param includeAliases controls whether to include aliases to other enum
   *        entries. Such entries exist for backward compatibility with legacy
   *        code using GenIStream, when names are changed.
   * \return enum entry identifiers for all possible enumeration parameter
   *         entries
   * \throws ParameterAccessException if the parameter does not exist
   * \incubating
   */
  virtual std::vector<EnumEntryUniqueId>
  getEntryIdsForEnum(const std::string& parameter,
                     bool includeAliases = false) const = 0;

  /**
   * Get an enum entry unique identifier from an enum entry symbolic name.
   * However, since several different enums can have entries with the same
   * symbolic name, the enum parameter must also be given, in order to get the
   * correct unique enum entry id, a.k.a enum entry parameter name.
   *
   * For example, an identifier can be "FileOpenMode_EnumEntry_ReadWrite" if the
   * symbolic name is "ReadWrite" and is a part of the enum parameter
   * "FileOpenMode".
   *
   * \return enum entry identifier for enum parameter and entry symbolic name
   * \throws ParameterAccessException if the parameter does not exist
   * \incubating
   */
  virtual EnumEntryUniqueId
  getEnumEntryId(const std::string& parameter,
                 const EnumEntrySymbolicName& symbolicName) const;

  /**
   * Get an enum entry symbolic name from an enum entry unique identifier. For
   * example, an identifier can be "FileOpenMode_EnumEntry_ReadWrite" while the
   * symbolic name is "ReadWrite" and display name is "Read Write".
   *
   * The unique identifier is useful for looking up whether enum entry is for
   * example implemented or not. The symbolic name, which might not be globally
   * unique among several enumerators, is useful for when setting an enumerator
   * value.
   *
   * \return enum entry symbolic name for given unique identifier
   * \throws ParameterAccessException if the parameter does not exist
   * \incubating
   */
  virtual EnumEntrySymbolicName
  getEnumEntrySymbolicName(const EnumEntryUniqueId& enumEntryId) const = 0;

  /**
   * Looks up a symbolic name given enumeration entry int value.
   *
   * For example, a enumeration parameter "FileOpenMode" can have some different
   * entries, where each entry has both a numeric value and symbolic name. Given
   * the enum parameter name "FileOpenMode" and the enum entry numeric value 2,
   * it return to the symbolic name "ReadWrite".
   *
   * \return entry symbolic name for given enum parameter and entry numeric
   *         value
   * \throws ParameterAccessException if the parameter does not exist
   * \throws OutOfRangeException if the numeric value does not match some entry
   *         of given enum parameter
   */
  virtual EnumEntrySymbolicName
  getEnumEntrySymbolicName(const std::string& parameter,
                           int64_t numericValue) const;

  /**
   * \return the value of any value-based parameter as string
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         available
   */
  virtual std::string getValueAsString(const std::string& parameter) const = 0;

  /**
   * \return the value of a string parameter
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         available
   */
  virtual std::string getString(const std::string& parameter) const = 0;

  /**
   * Sets the value of a boolean parameter.
   *
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         writable and available
   * \throws ParameterValueException if the parameter value was not allowed or
   *         the camera configuration was in an invalid state and not called in
   *         a register streaming session
   */
  virtual void setBool(const std::string& parameter, bool value) = 0;

  /**
   * Sets the value of a float parameter
   *
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected. Sets the value of a
   *         float parameter
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         writable and available
   * \throws ParameterValueException if the parameter value was not allowed or
   *         the camera configuration was in an invalid state and not called in
   *         a register streaming session
   */
  virtual void setFloat(const std::string& parameter, float value) = 0;

  /**
   * Sets the value of an integer parameter
   *
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected. Sets the value of a
   *         float parameter
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         writable and available
   * \throws ParameterValueException if the parameter value was not allowed or
   *         the camera configuration was in an invalid state and not called in
   *         a register streaming session
   */
  virtual void setInt(const std::string& parameter, int64_t value) = 0;

  /**
   * Sets the value of an enumeration parameter
   *
   * \note Verification cannot be turned off when setting the enum with value as
   *       string because of limitations in GenApi. Prefer using \ref
   *       setEnumInt() in those cases.
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         writable and available
   * \throws ParameterValueException if the parameter value was not allowed or
   *         the camera configuration was in an invalid state and not called in
   *         a register streaming session
   */
  virtual void setEnum(const std::string& parameter,
                       const EnumEntrySymbolicName& value) = 0;

  /**
   * Sets the value of an enumeration parameter as an integer.
   *
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         writable and available
   * \throws ParameterValueException if the parameter value was not allowed or
   *         the camera configuration was in an invalid state and not called in
   *         a register streaming session
   */
  virtual void setEnumInt(const std::string& parameter, int64_t value) = 0;

  /**
   * Sets the value of a string parameter.
   *
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         writable and available
   * \throws ParameterValueException if the parameter value was not allowed or
   *         the camera configuration was in an invalid state and not called in
   *         a register streaming session
   */
  virtual void setString(const std::string& parameter,
                         const std::string& value) = 0;


  /**
   * Sets the value of any value-based parameter from string.
   *
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         writable and available
   * \throws ParameterValueException if the parameter value was not allowed or
   *         the camera configuration was in an invalid state and not called in
   *         a register streaming session
   */
  virtual void setValueFromString(const std::string& parameter,
                                  const std::string& value) = 0;

  /**
   * \return the min allowed value for a float parameter
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         available
   */
  virtual float getFloatMin(const std::string& parameter) const = 0;

  /**
   * \return the max allowed value for a float parameter
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         available
   */
  virtual float getFloatMax(const std::string& parameter) const = 0;

  /**
   * \return the allowed value increment for a float parameter or 0 if all
   *         values between min and max are allowed
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         available
   */
  virtual float getFloatIncrement(const std::string& parameter) const = 0;

  /**
   * \return the min allowed value for an integer parameter
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         available
   */
  virtual int64_t getIntMin(const std::string& parameter) const = 0;

  /**
   * \return the max allowed value for an integer parameter
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         available
   */
  virtual int64_t getIntMax(const std::string& parameter) const = 0;

  /**
   * \return the allowed value increment for a float parameter or 0 if all
   *         values between min and max are allowed
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist or is not
   *         available
   */
  virtual int64_t getIntIncrement(const std::string& parameter) const = 0;

  /**
   * \return name of all parameter space nodes
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   */
  virtual std::vector<std::string> getAllNodeNames() const = 0;

  /**
   * \return name of all parents of parameter
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist
   */
  virtual std::vector<std::string>
  getParents(const std::string& parameter) const = 0;

  /**
   * \return name of all direct child features
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist
   */
  virtual std::vector<std::string>
  getDirectChildren(const std::string& parameter) const = 0;

  /**
   * \return description of parameter
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist
   */
  virtual std::string getDescription(const std::string& parameter) const = 0;

  /**
   * \return display name of parameter
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist
   */
  virtual std::string getDisplayName(const std::string& parameter) const = 0;

  /**
   * Retrieves the name of direct or indirect selectors of a given parameter,
   * e.g., "PixelFormat" is selected by both "ComponentSelector" and
   * "RegionSelector".
   *
   * \return name of all parameters that selects this parameter
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected.
   * \throws ParameterAccessException if the parameter does not exist
   * \incubating
   */
  virtual std::vector<std::string>
  getSelectedBy(const std::string& parameter) const = 0;

  /**
   * Subscribes to get asynchronous notification when a parameter is
   * invalidated. Invalidation can occur when the value of a parameter is set
   * (not necessarily changed) or invalidated because it depends on another
   * parameter that is invalidated.
   *
   * When the returned subscription object is destroyed, unsubscription occurs
   * and notifications end. Re-entrant unsubscription is allowed, i.e., it is
   * allowed to destroy the subscription object from the
   * \refcpp{NodeInvalidationCallback} \refcs{NodeInvalidationObserver}
   * function.
   *
   * \see \ref md_doc_event-subscriptions
   * \warning The callback function may be invoked from a different thread
   *          context! The user must ensure thread safety when handling the
   *          call.
   * \warning Beware that changing a node from the callback function may cause
   *          changes that trigger another invocation of the same callback
   *          function. You need to handle this possibility to avoid infinite
   *          loops or other problems with re-entrant code.
   * \return a \ref event::SubscriptionEnvelope carrying a \ref
   *         event::ISubscription object. The ISubscription should be kept until
   *         not more callbacks are desired, destroying it will cause
   *         unsubscription. The envelope contains a mutex lock that is
   *         automatically kept until the ISubscription object is assigned to
   *         the final destination variable. This allows re-entrant
   *         unsubscription, i.e., unsubscription from within the callback
   *         function, without risk of using an uninitialized variable.
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist
   * \incubating
   */
  virtual event::SubscriptionEnvelope
  subscribeToInvalidation(const std::string& parameter,
                          NodeInvalidationCallback onInvalidation) = 0;

  /**
   * Set the poll interval to use. A zero length interval is the same as
   * disabling the polling.
   *
   * Polling is a way for the parameters to be automatically updated by
   * re-reading values from underlying resource, like the camera. Parameters
   * with a specified polling time are read when the polling time has been
   * reached.
   *
   * As an example, let say that connected camera has a parameter named X with a
   * specified polling time of 1000 ms. Using the poll interval 700 ms will
   * re-read X from camera after 1400ms.
   *
   * Using a short poll interval can affect performance of \ref IAnyParameters
   * and create large amount of request to underlying resource, such as
   * increased network traffic to camera.
   *
   * \incubating
   */
  virtual void setPollInterval(std::chrono::milliseconds pollInterval) = 0;

  /**
   * \return the poll interval currently in use. A zero length interval is the
   *         same as disabled polling.
   * \incubating
   */
  virtual std::chrono::milliseconds getPollInterval() = 0;

  /**
   * \return the visibility for given parameter
   * \throws DisconnectedException if the underlying node map is closed, e.g.,
   *         if the \ref ICamera has been disconnected
   * \throws ParameterAccessException if the parameter does not exist or
   *         visibility could not be determined
   * \incubating
   */
  virtual ParameterVisibility getVisibility(const std::string& parameter) = 0;

  /**
   * \return a `std::unique_lock` object that will restrict access to the
   *         underlying GenApi node map to the current thread as long as the
   *         object is kept.
   * \incubating
   */
  virtual std::unique_lock<NodeMapMutex> lock() const = 0;

  /**
   * \return a unique identifier representing the object
   * \internal
   */
  AVOID virtual int64_t getInstanceId() const = 0;

  /**
   * \return whether verification is enabled
   * \internal Used to re-implement withoutVerification in wrapping for C#.
   */
  AVOID virtual bool getVerification() const = 0;

  /**
   * Sets whether verification should be enabled.
   *
   * \internal Used to re-implement withoutVerification in wrapping for C#.
   */
  AVOID virtual void setVerification(bool value) = 0;

protected:
  friend class ParameterChangeAdapter;

  /**
   * Disables invalidation events from current thread until returned object is
   * destroyed.
   *
   * \internal
   */
  AVOID virtual DeferredUnsuppression suppressEventsFromThread() = 0;
};

}
