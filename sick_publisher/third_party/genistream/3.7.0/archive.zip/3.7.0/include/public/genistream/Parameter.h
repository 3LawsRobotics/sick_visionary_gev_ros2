// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "Avoid.h"
#include "Exceptions.h"
#include "GenIStreamDll.h"
#include "IAnyParameters.h"

#include <list>
#include <memory>
#include <string>
#include <vector>

/**
 * \file
 *
 * This file contains parameter classes that are used in the automatically
 * generated parameter API in CameraParameters.h. You shouldn't have to create
 * instances of these yourself, instead use \ref
 * genistream::ICamera::getCameraParameters().
 */

namespace genistream {

class Parameter;
class ParameterChangeAdapter;

/** A callback function that handles a parameter value change event. */
typedef std::function<void(Parameter& parameter)> ParameterChangeCallback;


/** Base class for all parameter classes. */
class GENISTREAM_API Parameter
{
public:
  /**
   * Selector value pair, i.e., the name of a GenICam selector and a desired
   * value for it.
   */
  struct SelectorValue
  {
    std::string selectorName;
    int64_t value;
  };

  /**
   * Enum to identify the type of a parameter.
   *
   * \internal
   */
  enum class ParameterType
  {
    BOOL,
    COMMAND,
    ENUM,
    FLOAT,
    INT,
    STRING,
    UINT,
    UINT64
  };

public:
  virtual ~Parameter();

  /**
   * \return the description of the parameter
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  std::string getDescription() const;

  /**
   * \return true if the parameter is accessible
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  bool isAccessible() const;

  /**
   * \return true if the parameter is writable
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  bool isWritable() const;

  /**
   * \return true if the parameter is readable
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  bool isReadable() const;

  /** \return the name of the parameter */
  std::string getName() const;

  /**
   * Function to identify the type of the parameter.
   *
   * \internal Prefer using language specific ways, like RTTI in C++, if you
   *           need to identify the type of the parameter.
   */
  AVOID virtual ParameterType getParameterType() const = 0;

  /**
   * Subscribes to get asynchronous notification when the parameter changes
   * value.
   *
   * When the returned subscription object is destroyed, unsubscription occurs
   * and notifications end. Re-entrant unsubscription is allowed, i.e., it is
   * allowed to destroy the subscription object from the \ref
   * ParameterChangeCallback function.
   *
   * \see \ref md_doc_event-subscriptions
   * \warning The callback function may be invoked from a different thread
   *          context! The user must ensure thread safety when handling the
   *          call.
   * \warning Beware that changing a parameter from the callback function may
   *          cause changes that trigger another invocation of the same callback
   *          function. You need to handle this possibility to avoid infinite
   *          loops or other problems with re-entrant code.
   * \note The callback function will _not_ be invoked when parameters are
   *       changed in a register streaming session, see \ref
   *       ICamera::withRegisterStreaming().
   * \throws DisconnectedException if the \ref ICamera has been disconnected.
   * \return a \ref event::SubscriptionEnvelope carrying a \ref
   *         event::ISubscription object. The ISubscription should be kept until
   *         not more callbacks are desired, destroying it will cause
   *         unsubscription. The envelope contains a mutex lock that is
   *         automatically kept until the ISubscription object is assigned to
   *         the final destination variable. This allows re-entrant
   *         unsubscription, i.e., unsubscription from within the callback
   *         function, without risk of using an uninitialized variable.
   * \incubating
   */
  virtual event::SubscriptionEnvelope
  subscribeToChange(ParameterChangeCallback onChange) const = 0;

  /**
   * \return the underlying \ref IAnyParameters object
   * \lowlevel
   */
  AVOID std::shared_ptr<IAnyParameters> getAnyParameters();

  /** \return the name and int value of selectors governing this parameter */
  std::vector<SelectorValue> getSelectorValues() const;

protected:
  Parameter(std::shared_ptr<IAnyParameters> parameters,
            std::vector<SelectorValue> selectorValues,
            std::string name);

  std::unique_lock<NodeMapMutex> setSelectorsAndLockIfNeeded() const;
  std::vector<SelectorValue> getCurrentSelectors() const;
  std::unique_lock<NodeMapMutex>
  setSelectorsAndLockIfNeeded(const std::vector<SelectorValue>& values) const;

  event::SubscriptionEnvelope
  subscribe(std::unique_ptr<ParameterChangeAdapter> adapter,
            ParameterChangeCallback onChange) const;

  event::SubscriptionEnvelope
  subscribeToIntegerChange(ParameterChangeCallback onChange) const;

  friend class ParameterChangeAdapter;

protected:
  // Mutable to allow setting selectors even in const operations
  mutable std::shared_ptr<IAnyParameters> mParameters;
  std::vector<SelectorValue> mSelectorValues;
  std::string mName;

private:
  mutable std::list<std::unique_ptr<ParameterChangeAdapter>>
    mSubscriptionAdapters;
};


/** Parameter type to execute a command on the device. */
class GENISTREAM_API CommandParameter : public Parameter
{
public:
  /** \lowlevel Access parameters with \ref ICamera::getCameraParameters(). */
  AVOID CommandParameter(std::shared_ptr<IAnyParameters> parameters,
                         std::vector<SelectorValue> selectorValues,
                         std::string name);

  CommandParameter(const CommandParameter&) = delete;
  CommandParameter(CommandParameter&&) = delete;
  CommandParameter& operator=(const CommandParameter&) = delete;
  CommandParameter& operator=(CommandParameter&&) = delete;

  /**
   * Executes the command on the device.
   *
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  void execute(bool waitForCompletion = true);

  AVOID ParameterType getParameterType() const override;

  event::SubscriptionEnvelope
  subscribeToChange(ParameterChangeCallback onChange) const override
  {
    throw GenIStreamException("Subscription not supported on commands");
  }

  // Allow implementation of interface functions marked as deprecated
#pragma warning(suppress : 4996)
};


/** A 32-bit floating point parameter on the camera. */
class GENISTREAM_API FloatParameter : public Parameter
{
public:
  /** \lowlevel Access parameters with \ref ICamera::getCameraParameters(). */
  AVOID FloatParameter(std::shared_ptr<IAnyParameters> parameters,
                       std::vector<SelectorValue> selectorValues,
                       std::string name);

  FloatParameter(const FloatParameter&) = delete;
  FloatParameter(FloatParameter&&) = delete;
  FloatParameter& operator=(const FloatParameter&) = delete;
  FloatParameter& operator=(FloatParameter&&) = delete;

  /**
   * \return the value of the parameter
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  operator float() const;

  /**
   * Sets a new value of the parameter.
   *
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  FloatParameter& operator=(float value);

  /**
   * \return the value of the parameter
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  float get() const;

  /**
   * Sets a new value of the parameter.
   *
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  void set(float value);

  /**
   * \return the minimum allowed value of the parameter
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  float getMin() const;

  /**
   * \return the maximum allowed value of the parameter
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  float getMax() const;

  /**
   * \return the allowed value increment or 0 if all values between min and max
   *         are allowed
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  float getIncrement() const;

  AVOID ParameterType getParameterType() const override;

  event::SubscriptionEnvelope
  subscribeToChange(ParameterChangeCallback onChange) const override;

  // Allow implementation of interface functions marked as deprecated
#pragma warning(suppress : 4996)
};


/** A boolean parameter on the camera. */
class GENISTREAM_API BoolParameter : public Parameter
{
public:
  /** \lowlevel Access parameters with \ref ICamera::getCameraParameters(). */
  AVOID BoolParameter(std::shared_ptr<IAnyParameters> parameters,
                      std::vector<SelectorValue> selectorValues,
                      std::string name);

  BoolParameter(const BoolParameter&) = delete;
  BoolParameter(BoolParameter&&) = delete;
  BoolParameter& operator=(const BoolParameter&) = delete;
  BoolParameter& operator=(BoolParameter&&) = delete;

  /**
   * \return the value of the parameter
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  operator bool() const;

  /**
   * Sets a new value of the parameter.
   *
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  BoolParameter& operator=(bool value);

  /**
   * \return the value of the parameter
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  bool get() const;

  /**
   * Sets a new value of the parameter.
   *
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  void set(bool value);

  AVOID ParameterType getParameterType() const override;

  event::SubscriptionEnvelope
  subscribeToChange(ParameterChangeCallback onChange) const override;

  // Allow implementation of interface functions marked as deprecated
#pragma warning(suppress : 4996)
};


/** A string parameter on the camera. */
class GENISTREAM_API StringParameter : public Parameter
{
public:
  /** \lowlevel Access parameters with \ref ICamera::getCameraParameters(). */
  AVOID StringParameter(std::shared_ptr<IAnyParameters> parameters,
                        std::vector<SelectorValue> selectorValues,
                        std::string name);

  StringParameter(const StringParameter&) = delete;
  StringParameter(StringParameter&&) = delete;
  StringParameter& operator=(const StringParameter&) = delete;
  StringParameter& operator=(StringParameter&&) = delete;

  /**
   * \return the value of the parameter
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  operator std::string() const;

  /**
   * Sets a new value of the parameter.
   *
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  StringParameter& operator=(const std::string& value);

  /**
   * \return the value of the parameter
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  std::string get() const;

  /**
   * Sets a new value of the parameter
   *
   * \throws DisconnectedException if the \ref ICamera has been disconnected.
   */
  void set(const std::string& value);

  AVOID ParameterType getParameterType() const override;

  event::SubscriptionEnvelope
  subscribeToChange(ParameterChangeCallback onChange) const override;

  // Allow implementation of interface functions marked as deprecated
#pragma warning(suppress : 4996)
};


/**
 * A template for different integer type parameters on the camera.
 *
 * \tparam CppType the integer type
 */
template<typename CppType>
class GENISTREAM_API IntegerParameter : public Parameter
{
public:
  /** \lowlevel Access parameters with \ref ICamera::getCameraParameters(). */
  AVOID IntegerParameter(std::shared_ptr<IAnyParameters> parameters,
                         std::vector<SelectorValue> selectorValues,
                         std::string name)
    : Parameter(std::move(parameters),
                std::move(selectorValues),
                std::move(name))
  {
  }

  IntegerParameter(const IntegerParameter&) = delete;
  IntegerParameter(IntegerParameter&&) = delete;
  IntegerParameter& operator=(const IntegerParameter&) = delete;
  IntegerParameter& operator=(IntegerParameter&&) = delete;

  /**
   * \return the value of the parameter
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  operator CppType() const { return get(); }

  /**
   * Sets a new value of the parameter.
   *
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  IntegerParameter& operator=(CppType value)
  {
    set(value);
    return *this;
  }

  /**
   * \return the value of the parameter
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  CppType get() const
  {
    std::unique_lock<NodeMapMutex> lock = setSelectorsAndLockIfNeeded();
    return static_cast<CppType>(mParameters->getInt(mName));
  }

  /**
   * Sets a new value of the parameter
   *
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  void set(CppType value)
  {
    std::unique_lock<NodeMapMutex> lock = setSelectorsAndLockIfNeeded();
    mParameters->setInt(mName, value);
  }

  /**
   * \return the minimum allowed value of the parameter
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  CppType getMin() const
  {
    std::unique_lock<NodeMapMutex> lock = setSelectorsAndLockIfNeeded();
    return static_cast<CppType>(mParameters->getIntMin(mName));
  }

  /**
   * \return the maximum allowed value of the parameter
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  CppType getMax() const
  {
    std::unique_lock<NodeMapMutex> lock = setSelectorsAndLockIfNeeded();
    return static_cast<CppType>(mParameters->getIntMax(mName));
  }

  /**
   * \return the allowed value increment or 0 if all values between min and max
   *         are allowed
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  CppType getIncrement() const
  {
    std::unique_lock<NodeMapMutex> lock = setSelectorsAndLockIfNeeded();
    return static_cast<CppType>(mParameters->getIntIncrement(mName));
  }

  AVOID ParameterType getParameterType() const override;

  event::SubscriptionEnvelope
  subscribeToChange(ParameterChangeCallback onChange) const override
  {
    return subscribeToIntegerChange(std::move(onChange));
  }

  // Allow implementation of interface functions marked as deprecated
#pragma warning(suppress : 4996)
};

/** A 32-bit unsigned integer parameter on the camera. */
typedef IntegerParameter<uint32_t> UintParameter;
template<>
inline Parameter::ParameterType
IntegerParameter<uint32_t>::getParameterType() const
{
  return ParameterType::UINT;
}

/** A 32-bit signed integer parameter on the camera. */
typedef IntegerParameter<int32_t> IntParameter;
template<>
inline Parameter::ParameterType
IntegerParameter<int32_t>::getParameterType() const
{
  return ParameterType::INT;
}

/** A 64-bit unsigned integer parameter on the camera. */
typedef IntegerParameter<uint64_t> Uint64Parameter;
template<>
inline Parameter::ParameterType
IntegerParameter<uint64_t>::getParameterType() const
{
  return ParameterType::UINT64;
}


/**
 * A template for different enum type parameters on the camera.
 *
 * \tparam CppEnumType the automatically generated C++ enumeration type for the
 *         GenICam enumeration
 */
template<typename CppEnumType>
class GENISTREAM_API EnumParameter : public Parameter
{
public:
  /** \lowlevel Access parameters with \ref ICamera::getCameraParameters(). */
  AVOID EnumParameter(std::shared_ptr<IAnyParameters> parameters,
                      std::vector<SelectorValue> selectorValues,
                      std::string name)
    : Parameter(std::move(parameters),
                std::move(selectorValues),
                std::move(name))
  {
  }

  EnumParameter(const EnumParameter&) = delete;
  EnumParameter(EnumParameter&&) = delete;
  EnumParameter& operator=(const EnumParameter&) = delete;
  EnumParameter& operator=(EnumParameter&&) = delete;

  /**
   * \return the value of the parameter
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  operator CppEnumType() const { return get(); }

  /**
   * Sets a new value of the parameter.
   *
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  EnumParameter& operator=(CppEnumType value)
  {
    set(value);
    return *this;
  }

  /**
   * \return the value of the parameter
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  CppEnumType get() const
  {
    std::unique_lock<NodeMapMutex> lock = setSelectorsAndLockIfNeeded();
    return static_cast<CppEnumType>(mParameters->getEnumInt(mName));
  }

  /**
   * Sets a new value of the parameter.
   *
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  void set(CppEnumType value)
  {
    std::unique_lock<NodeMapMutex> lock = setSelectorsAndLockIfNeeded();
    mParameters->setEnumInt(mName, static_cast<int64_t>(value));
  }

  AVOID ParameterType getParameterType() const override
  {
    return ParameterType::ENUM;
  }

  /**
   * \return true if the given enumeration entry int value exists and is
   *         accessible
   * \throws DisconnectedException if the \ref ICamera has been disconnected
   */
  bool isEnumEntryAccessible(CppEnumType value) const
  {
    std::unique_lock<NodeMapMutex> lock = setSelectorsAndLockIfNeeded();
    auto allEntryIds = mParameters->getEntryIdsForEnum(mName, true);

    for (const auto& entryId : allEntryIds)
    {
      const auto numericValue = static_cast<int64_t>(value);

      // This check is needed to ensure that the enum entry exists
      // in the current firmware
      if (numericValue == mParameters->getEnumEntryInt(entryId))
      {
        return mParameters->isAccessible(entryId);
      }
    }
    return false;
  }

  event::SubscriptionEnvelope
  subscribeToChange(ParameterChangeCallback onChange) const override
  {
    return subscribeToIntegerChange(std::move(onChange));
  }

  // Allow implementation of interface functions marked as deprecated
#pragma warning(suppress : 4996)
};

}
