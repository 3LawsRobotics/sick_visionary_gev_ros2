// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include "BasicTypes.h"
#include "IInterfaceInfo.h"

#include "../../public/gentlcpp/CApi.h"
#include "../genistream/GenIStreamDll.h"

#include <TLI/GenTL.h>

#include <memory>

namespace gentlcpp {

class CApi;
class TransportLayer;

class GENISTREAM_API InterfaceInfo : public IInterfaceInfo
{
public:
  ~InterfaceInfo() noexcept override;

  InterfaceId getId() const override;
  std::string getDisplayName() const override;
  std::string getTransportLayerType() const override;

  template<typename T>
  T getInfo(GenTL::INTERFACE_INFO_CMD_LIST command) const
  {
    T value;
    size_t size = sizeof(T);
    GenTL::INFO_DATATYPE dataType;
    ThrowIfError(mCApi,
                 mCApi->TLGetInterfaceInfo(getParentHandle(),
                                           mInterfaceId.c_str(),
                                           command,
                                           &dataType,
                                           &value,
                                           &size));
    return value;
  }

  template<typename T>
  T getInfo(uint32_t customCommand) const
  {
    return getInfo<T>(
      static_cast<GenTL::INTERFACE_INFO_CMD_LIST>(customCommand));
  }

private:
  friend class TransportLayer;
  InterfaceInfo(std::shared_ptr<const CApi> cApi,
                std::shared_ptr<TransportLayer> transportLayer,
                InterfaceId interfaceId);

  GenTL::TL_HANDLE getParentHandle() const;

private:
  std::shared_ptr<const CApi> mCApi;
  std::shared_ptr<TransportLayer> mParent;
  InterfaceId mInterfaceId;
};

/* (explicit specialization has to be declared in a scope where primary template can be defined) */
template<>
std::string InterfaceInfo::getInfo(GenTL::INTERFACE_INFO_CMD_LIST command) const;

}
