// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "genistream/Avoid.h"
#include "genistream/CameraParameters.h"
#include "genistream/GenIStreamDll.h"
#include "genistream/frame/CoordinateSystem.h"

namespace gentlcpp {
class IBufferPart;
}

namespace genistream { namespace frame {

class Image;

/**
 * This class corresponds to the concept of an "image", i.e., an abstraction of
 * a raster of pixels. It carries image data, possibly in several channels, and
 * information about the data such as size and pixel format.
 *
 * It it also an abstraction of the GenICam component concept, hence the name of
 * the interface. A component is part of a \ref IRegion within a \ref IFrame.
 * When data is received from a camera, the component accesses data within a
 * GenTL buffer part.
 *
 * Some pixel formats are divided into channels and transmitted separately,
 * rather than interleaved. Their data must then be accessed separately with
 * different data pointers. This is the case for calibrated data when using the
 * `Scan3dOutputMode` set to `CalibratedAC` and `PixelFormat` set to
 * `Coord3D_AC16_Planar`.
 *
 * In GenTL each channel is handled as a separate buffer part, see \ref
 * gentlcpp::IBufferPart.
 *
 * \note This object depends on its parent \ref IFrame object and \ref
 *       FrameGrabber object, i.e., to use this object you must ensure these are
 *       not destroyed. Otherwise the underlying buffer may have been
 *       deallocated or re-used by GenTL for a new frame, i.e., the data may
 *       have been replaced.
 */
class GENISTREAM_API IComponent
{
public:
  /**
   * A 3D point in the coordinates given by \ref getCoordinateSystem().
   *
   * The z value can be NaN if the point represents missing data.
   *
   * \incubating
   */
  struct Point
  {
    double x = 0;
    double y = 0;
    double z = 0;
  };

public:
  virtual ~IComponent() = default;

  /** \return the \ref ComponentId of the component */
  virtual ComponentId getId() const = 0;

  /** \return the pixel format of the component */
  virtual PixelFormat getPixelFormat() const = 0;

  /**
   * \param channel the index of the channel in planar data (non-interleaved) in
   *        a multi-channel component. Most components are non-planar, single
   *        channel, and then this function will return the same as \ref
   *        getPixelFormat.
   * \return the pixel format for a specific channel in the component
   * \throws OutOfRangeException if the channel is out of range
   */
  virtual PixelFormat getChannelPixelFormat(size_t channel) const = 0;

  /** \return the width of the component in pixels */
  virtual size_t getWidth() const = 0;

  /**
   * For 3D extraction regions this is the same as \ref
   * IFrame::getDeliveredLineCount and for 2D sensor images this is the same as
   * the height in \ref IRegion::getAoi().
   *
   * \return the height of the component. For a 3D extraction region, this is
   *         the number of lines scanned. If there are lines not delivered from
   *         the camera these are not counted.
   */
  virtual size_t getDeliveredHeight() const = 0;

  /**
   * For 3D extraction regions this is the same as \ref
   * IFrame::getConfiguredLineCount and for 2D sensor images this is the same as
   * the height in \ref IRegion::getAoi().
   *
   * \return the height of the component. For a 3D extraction region, this is
   *         the number of lines scanned. If there are lines not delivered from
   *         the camera these are not counted.
   */
  virtual size_t getConfiguredHeight() const = 0;

  /**
   * \param channel the index of the channel in planar data (non-interleaved) in
   *        a multi-channel component. Most components are non-planar, single
   *        channel, and then the argument can be omitted.
   * \return a pointer to the data corresponding to the channel in the component
   * \throws OutOfRangeException if the channel is out of range
   * \incubating We consider changing the function to returning `void*`.
   */
  virtual uint8_t* getData(size_t channel = 0) const = 0;

  /**
   * \return the amount of bytes delivered from the camera. For multi-channel
   *         components this is the size of one of the channels.
   */
  virtual size_t getDeliveredDataSize() const = 0;

  /**
   * \return the amount of bytes for one channel in a complete component. This
   *         may be larger than the delivered size if the camera is configured
   *         with Immediate AcquisitionStopMode. Normally it is safe to read the
   *         entire data buffer since the buffer is cleared with the missing
   *         data value when returned to be reused.
   */
  virtual size_t getConfiguredDataSize() const = 0;

  /** \return the number of bytes per image row */
  virtual size_t getStride() const = 0;

  /**
   * \return the bits per pixel for each channel of the component.
   * \incubating We consider deprecating this since you can use \ref
   *             pixelformat::bitsPerPixel() and \ref getPixelFormat().
   */
  virtual size_t getBitsPerPixel() const = 0;

  /** \return the coordinate system for the component */
  virtual const CoordinateSystem& getCoordinateSystem() const = 0;

  /**
   * \return the data resolution in the Y direction, i.e. the distance in
   *         millimeters between profiles.
   * \note The function is only valid for Range and P2 components.
   * \note The value can be set with wit \ref IRegion::setYResolution().
   * \incubating
   */
  virtual double getYResolution() const = 0;

  /** \return the number of channels in the component */
  virtual size_t getNumberOfChannels() const = 0;

  /**
   * \param channel the index of the channel in planar data (non-interleaved) in
   *        a multi-channel component. Most components are non-planar, single
   *        channel, and then the argument can be omitted.
   * \return the underlying \ref gentlcpp::IBufferPart if the frame was created
   *         from a buffer, if the buffer is multi-part and if buffer is not
   *         already released.
   * \throws NotAvailableException if the frame was created some other way
   * \throws OutOfRangeException if the channel is out of range
   * \lowlevel
   */
  AVOID virtual std::weak_ptr<gentlcpp::IBufferPart>
  getBufferPart(size_t channel = 0) const = 0;

  /**
   * Gets the value of a pixel. Provides direct access to the data, i.e., the
   * returned reference can be altered to allow modification.
   *
   * \tparam T data type matching the size of the pixel format
   * \param x column of the pixel in the image data
   * \param y row of the pixel in the image data
   * \param channel the index of the channel in planar data (non-interleaved) in
   *        a multi-channel component. Most components are non-planar, single
   *        channel, and then the argument can be omitted.
   * \return the value of a single pixel
   * \throws OutOfRangeException if any of the indices are out of range
   * \throws InvalidPixelFormat if template data type does not match the the
   *         pixel format
   * \incubating
   */
  template<typename T>
  T& at(size_t x, size_t y, size_t channel = 0)
  {
    throwIfWrongPixelSize(sizeof(T));
    throwIfOutOfBounds(x, y);
    return *(reinterpret_cast<T*>(getData(channel)) + y * getWidth() + x);
  }

  /**
   * Gets the value of a pixel.
   *
   * \tparam T data type matching the size of the pixel format
   * \param x column of the pixel in the image data
   * \param y row of the pixel in the image data
   * \param channel the index of the channel in planar data (non-interleaved) in
   *        a multi-channel component. Most components are non-planar, single
   *        channel, and then the argument can be omitted.
   * \return the value of a single pixel
   * \throws OutOfRangeException if any of the indices are out of range
   * \throws InvalidPixelFormat if template data type does not match the the
   *         pixel format
   * \incubating
   */
  template<typename T>
  T at(size_t x, size_t y, size_t channel = 0) const
  {
    throwIfWrongPixelSize(sizeof(T));
    throwIfOutOfBounds(x, y);
    return *(reinterpret_cast<T*>(getData(channel)) + y * getWidth() + x);
  }

  /**
   * Gets the value of a pixel converted to floating point. It is not
   * transformed with the coordinate system.
   *
   * \param x column of the pixel in the image data
   * \param y row of the pixel in the image data
   * \param channel the index of the channel in planar data (non-interleaved) in
   *        a multi-channel component. Most components are non-planar, single
   *        channel, and then the argument can be omitted.
   * \return The value of a single pixel as a double
   * \throws OutOfRangeException if any of the indices are out of range
   * \throws InvalidPixelFormat if the pixel format is packed, i.e., pixels
   *         cannot be evenly represented as multiples of bytes, e.g., 10- or
   *         12-bit formats
   * \incubating
   */
  virtual double getValue(size_t x, size_t y, size_t channel = 0) const = 0;

  /**
   * Gets the position of a pixel as a \ref IComponent::Point. It is transformed
   * with the coordinate system to the unit given by \ref getCoordinateSystem().
   *
   * \param x column of the pixel in the image data
   * \param y row of the pixel in the image data
   * \param missingDataValue the value returned for any missing data
   * \return the position of the pixel
   * \throws OutOfRangeException if any of the indices are out of range
   * \throws InvalidPixelFormat if the pixel format is packed, i.e., pixels
   *         cannot be evenly represented as multiples of bytes, e.g., 10- or
   *         12-bit formats
   * \incubating
   */
  virtual Point
  getPoint(size_t x,
           size_t y,
           double missingDataValue =
             std::numeric_limits<double>::signaling_NaN()) const = 0;

  /**
   * \return a copy of this \ref IComponent with the pixel format of each
   *         channel preserved. A new copy of the image data is always created,
   *         so the original \ref IComponent can be released to allow GenTL
   *         buffer reuse.
   */
  virtual std::shared_ptr<IComponent> copy() const = 0;

  /**
   * \return a copy of this \ref IComponent where the pixel format in each
   *         channel has been expanded to 16-bit format, if it was a 10- or
   *         12-bit packed format, or 8-bit format if it was a 4-bit packed
   *         format. A new copy of the image data is always created, so the
   *         original \ref IComponent can be released to allow GenTL buffer
   *         reuse.
   */
  virtual std::shared_ptr<IComponent> copyUnpacked() const = 0;

  /**
   * \param missingDataValue the new value of any missing data after applying Z
   *        axis transform
   * \return a copy of this \ref IComponent where the data is transformed using
   *         the Z axis transformation of the coordinate system to the unit
   *         given by \ref getCoordinateSystem(). The resulting data is stored
   *         as 64-bit floating point data, i.e., `double`.
   * \throws InvalidPixelFormat if a channel pixel format cannot be assumed to
   *         be A or C (range) axis formats. It is also thrown if the component
   *         has already been transformed and contains 64-bit floating point
   *         data.
   * \incubating
   */
  virtual std::shared_ptr<IComponent>
  copyTransformed(double missingDataValue =
                    std::numeric_limits<double>::signaling_NaN()) const = 0;

  /**
   * Creates an \ref Image object by copying the image data for one channel from
   * the underlying \ref gentlcpp::IBuffer of this component. If image data is
   * 10- or 12-bit packed format it is expanded to 16-bit format.
   *
   * \param channel the index of the channel in planar data (non-interleaved) in
   *        a multi-channel component. Most components are non-planar, single
   *        channel, and then the argument can be omitted.
   * \throws OutOfRangeException if the channel is out of range
   * \deprecated Prefer using \ref IComponent rather than \ref Image.
   * \deprecatedsince 3.4
   */
  AVOID virtual std::shared_ptr<Image>
  createCopiedImage(size_t channel = 0) const = 0;

  /**
   * Creates an \ref Image object which refers to the image data for one channel
   * in the underlying \ref gentlcpp::IBuffer of this component.
   *
   * \param channel the index of the channel in planar data (non-interleaved) in
   *        a multi-channel component. Most components are non-planar, single
   *        channel, and then the argument can be omitted.
   * \note It is up to you as a user to keep a reference to the \ref
   *       gentlcpp::IBuffer or \ref gentlcpp::IBufferPart so that the memory is
   *       not deallocated or reused. As long as you keep a reference to this
   *       component or its parent \ref IFrame this will be ensured.
   * \throws OutOfRangeException if the channel is out of range
   * \deprecated Prefer using \ref IComponent rather than \ref Image.
   * \deprecatedsince 3.4
   */
  AVOID virtual std::shared_ptr<Image>
  createReferringImage(size_t channel = 0) const = 0;

  /**
   * Logs information about a \ref IComponent.
   *
   * \incubating Prefer using operator<<().
   */
  virtual void logTo(std::ostream& s, size_t indentLevel) const = 0;

private:
  void throwIfWrongPixelSize(size_t pixelByteSize) const;
  void throwIfOutOfBounds(size_t x, size_t y) const;
};

typedef std::vector<std::shared_ptr<IComponent>> ComponentList;
typedef std::vector<std::shared_ptr<const IComponent>> ConstComponentList;

/**
 * Compares the components, including meta-information and actual image data.
 */
bool operator==(const IComponent& lhs, const IComponent& rhs);

/**
 * Compares the components, including meta-information and actual image data.
 */
bool operator!=(const IComponent& lhs, const IComponent& rhs);

/**
 * Compares the components, including meta-information and actual image data.
 *
 * \param lhs the left-hand side IComponent
 * \param rhs the right-hand side IComponent
 * \param allowedFraction the allowed difference fraction between
 *        meta-information that is floating point
 * \return true if the components are considered equal
 */
bool compare(const IComponent& lhs,
             const IComponent& rhs,
             double allowedFraction = 0.0);

/** Logs information about a \ref IComponent. */
std::ostream& operator<<(std::ostream& s, const IComponent& component);

}}
