// Copyright 2019-2023 SICK AG. All rights reserved.
#pragma once

#include "Avoid.h"
#include "GenIStreamDll.h"
#include "IAnyParameters.h"

#include "CushionWinHeaders.h"
#include <GenApi/NodeMapRef.h>

#include <functional>
#include <memory>
#include <mutex>


namespace gentlcpp {
class Port;
}

namespace genistream {
class NodeMap;
class TimerTask;
namespace event {
class NodeInvalidationDispatcher;
class NodeMapEventPusher;
}
}

namespace genistream {

/**
 * A holder of both a \ref gentlcpp::Port and \ref NodeMap. A \ref NodeMap does
 * not in it self keep a strong reference to underlying port, so if this class
 * is destructed, the port is released.
 *
 * \lowlevel Prefer using the \ref IAnyParameters interface or even \ref
 *           CameraParameters. See \ref ICamera::getAnyParameters() and \ref
 *           ICamera::getCameraParameters().
 */
class GENISTREAM_API NodeMapPortPair
{
public:
  /**
   * You should normally not have to create NodeMapPortPair%s yourself. Instead
   * use \ref ICamera::getAnyParameters() or \ref
   * ICamera::getCameraParameters().
   *
   * \param port the GenTL port to connect a GenApi node map to
   * \param withPolling true to activate a thread that automatically polls the
   *        node map to update nodes with a polling interval
   * \param nodeMapName name of the node map, mainly used for thread
   *        identification when debugging
   * \lowlevel
   */
  static AVOID std::shared_ptr<NodeMapPortPair>
  create(std::shared_ptr<gentlcpp::Port> port,
         bool withPolling,
         const std::string& nodeMapName);

public:
  std::shared_ptr<NodeMap> nodeMap;

private:
  friend class CameraTest;

  NodeMapPortPair(std::shared_ptr<gentlcpp::Port> port,
                  std::shared_ptr<NodeMap> nodeMap);

  static AVOID std::shared_ptr<NodeMapPortPair>
  createPortless(std::shared_ptr<NodeMap> nodeMap);

private:
  // Hold a reference to keep the port open
  std::shared_ptr<gentlcpp::Port> mPort;
};

/**
 * Wrapper class for GenApi node maps. This class has two responsibilities,
 * firstly serving as facade on more low level details, and secondly guard from
 * usage when underlying communication resource is closed.
 *
 * Contains convenience functions to get and set node values.
 *
 * \lowlevel Prefer using the \ref IAnyParameters interface or even \ref
 *           CameraParameters. See \ref ICamera::getAnyParameters() and \ref
 *           ICamera::getCameraParameters().
 */
#ifdef SWIG
class GENISTREAM_API NodeMap : public IAnyParameters
#else
class GENISTREAM_API NodeMap : public std::enable_shared_from_this<NodeMap>,
                public IAnyParameters
#endif
{
public:
  ~NodeMap() override;

  /**
   * Operator to allow implicit conversion to the underlying GenApi node map.
   *
   * \lowlevel
   * \deprecated The `CNodeMapRef` smart pointer constructor and destructor are
   *             not thread safe, thus prefer using \ref getRaw().
   * \deprecatedsince 2.9
   */
  AVOID operator GenApi::CNodeMapRef();

  /**
   * Operator to allow implicit conversion to the underlying GenApi node map.
   *
   * \lowlevel
   * \deprecated The `CNodeMapRef` smart pointer constructor and destructor are
   *             not thread safe, thus prefer using \ref getRaw().
   * \deprecatedsince 2.9
   */
  AVOID operator const GenApi::CNodeMapRef() const;

  /**
   * Function to explicitly get the underlying GenApi node map.
   *
   * \lowlevel
   * \deprecated The `CNodeMapRef` smart pointer constructor and destructor are
   *             not thread safe, thus prefer using \ref getRaw().
   * \deprecatedsince 2.9
   */
  AVOID GenApi::CNodeMapRef get();

  /**
   * Function to explicitly get the underlying GenApi node map.
   *
   * \lowlevel
   * \deprecated The `CNodeMapRef` smart pointer constructor and destructor are
   *             not thread safe, thus prefer using \ref getRaw().
   * \deprecatedsince 2.9
   */
  AVOID const GenApi::CNodeMapRef get() const;

  /**
   * Function to explicitly get the underlying GenApi node map.
   *
   * \lowlevel
   */
  GenApi::INodeMap* getRaw() { return mNodeMap._Ptr; }

  /**
   * Function to explicitly get the underlying GenApi node map.
   *
   * \lowlevel
   */
  const GenApi::INodeMap* getRaw() const { return mNodeMap._Ptr; }

  bool isParameterLockedByAcquisition(const std::string& parameter)
    const override;

  void withoutVerification(
    std::function<void(std::shared_ptr<IAnyParameters>)> action) override;

  GenApi::EAccessMode getAccessMode(const std::string& parameter)
    const override;

  bool isCommand(const std::string& parameter) const override;
  bool isBool(const std::string& parameter) const override;
  bool isFloat(const std::string& parameter) const override;
  bool isInt(const std::string& parameter) const override;
  bool isEnum(const std::string& parameter) const override;
  bool isString(const std::string& parameter) const override;
  bool isCategory(const std::string& parameter) const override;
  bool isRawRegister(const std::string& parameter) const override;

  void executeCommand(const std::string& parameter,
                      bool waitForCompletion = true) override;

  bool getBool(const std::string& parameter) const override;
  float getFloat(const std::string& parameter) const override;
  int64_t getInt(const std::string& parameter) const override;
  EnumEntrySymbolicName getEnum(const std::string& parameter) const override;
  int64_t getEnumInt(const std::string& parameter) const override;
  int64_t getEnumEntryInt(const EnumEntryUniqueId& enumEntryId) const override;
  std::vector<EnumEntryUniqueId> getEntryIdsForEnum(
    const std::string& parameter, bool includeAliases = false) const override;
  EnumEntrySymbolicName getEnumEntrySymbolicName(
    const EnumEntryUniqueId& enumEntryId) const override;
  std::string getString(const std::string& parameter) const override;
  std::string getValueAsString(const std::string& parameter) const override;

  void setBool(const std::string& parameter, bool value) override;
  void setFloat(const std::string& parameter, float value) override;
  void setInt(const std::string& parameter, int64_t value) override;
  void setEnum(const std::string& parameter, const EnumEntrySymbolicName& value)
    override;
  void setEnumInt(const std::string& parameter, int64_t value) override;
  void setString(const std::string& parameter, const std::string& value)
    override;
  void setValueFromString(const std::string& parameter, const std::string& value)
    override;

  float getFloatMin(const std::string& parameter) const override;
  float getFloatMax(const std::string& parameter) const override;
  float getFloatIncrement(const std::string& parameter) const override;
  int64_t getIntMin(const std::string& parameter) const override;
  int64_t getIntMax(const std::string& parameter) const override;
  int64_t getIntIncrement(const std::string& parameter) const override;

  std::vector<std::string> getAllNodeNames() const override;
  std::vector<std::string> getParents(const std::string& parameter)
    const override;
  std::vector<std::string> getDirectChildren(const std::string& parameter)
    const override;

  std::string getDescription(const std::string& parameter) const override;
  std::string getDisplayName(const std::string& parameter) const override;

  std::vector<std::string> getSelectedBy(const std::string& parameter)
    const override;

  event::SubscriptionEnvelope subscribeToInvalidation(
    const std::string& parameter, NodeInvalidationCallback onInvalidation)
    override;

  void setPollInterval(std::chrono::milliseconds pollInterval) override;
  std::chrono::milliseconds getPollInterval() override;

  ParameterVisibility getVisibility(const std::string& parameter) override;

  std::unique_lock<NodeMapMutex> lock() const override;

  AVOID int64_t getInstanceId() const override;
  AVOID bool getVerification() const override;
  AVOID void setVerification(bool value) override;
  AVOID DeferredUnsuppression suppressEventsFromThread() override;

protected:
  friend class NodeMapPortPair;
  friend class event::NodeMapEventPusher;
  friend class NodeMapTest;

  // Allows implementation of sub-class that doesn't use the normal generation
  // of node map from port. This NodeMap will never be regarded as closed.
  explicit NodeMap(GenApi::CNodeMapRef nodeMap);

private:
  NodeMap(std::shared_ptr<gentlcpp::Port> port,
          bool withPolling,
          const std::string& nodeMapName);
  // For unit testing only
  NodeMap(GenApi::INodeMap * nodeMap, GenApi::IPort * port);

  void throwIfClosed() const;
  bool probeConnection() const;
  std::shared_ptr<event::NodeInvalidationDispatcher> eventDispatcher();

protected:
  std::function<bool()> mIsClosed;

  // The CNodeMapRef smart pointer does not implement thread safe copying. So
  // we'll have to use a mutex to share it. However, just accessing the
  // internal _Ptr is safe without mutex locking
  GenApi::CNodeMapRef mNodeMap;
  // Mutex used to ensure thread safe copying of CNodeMapRef
  mutable std::mutex mCopyMutex;
  // Wrapper around underlying lock in GenApi node map
  std::unique_ptr<NodeMapMutex> mGenApiMutex;
  // The GenApi port that the node map wraps
  GenApi::IPort* mPort = nullptr;
  bool mIsRemoteDevice = true;

  std::shared_ptr<event::NodeInvalidationDispatcher> mEventDispatcher;

  bool mVerification = true;
  std::unique_ptr<TimerTask> mPollTask;

  // Allow implementation of interface functions marked as deprecated
#pragma warning(suppress : 4996)
};

}
