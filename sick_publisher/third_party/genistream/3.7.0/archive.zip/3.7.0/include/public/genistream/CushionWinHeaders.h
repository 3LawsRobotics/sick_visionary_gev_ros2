// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

/**
 * \file
 *
 * Header files in GenApi include Windows API headers which may cause problems,
 * e.g., name clashes with min/max. To reduce the impact, this header file is
 * included before any GenApi header is included.
 */

#ifndef WIN32_LEAN_AND_MEAN
#  define WIN32_LEAN_AND_MEAN
#endif

#ifndef NOMINMAX
#  define NOMINMAX
#endif
