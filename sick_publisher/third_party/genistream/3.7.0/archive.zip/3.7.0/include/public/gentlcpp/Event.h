// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include "IEvent.h"

#include "../../public/gentlcpp/CApi.h"
#include "../genistream/GenIStreamDll.h"

#include <string>

namespace gentlcpp {

class CApi;

class GENISTREAM_API Event : public virtual IEvent
{
public:
  ~Event() noexcept override;

  void unregister() override;
  void flush() override;

  GenTL::EVENT_HANDLE getHandle() override;
  std::shared_ptr<const IModule> getParentModule() const override;

  EventResult getData(void* pOutBuffer,
                      size_t bufferSize,
                      std::chrono::milliseconds timeout) const override;

  EventResult getData(void* pOutBuffer, size_t bufferSize) const override;

  GenTL::EVENT_TYPE_LIST getEventType() const override;
  size_t getQueuedCount() const override;
  uint64_t getFiredCount() const override;
  size_t getMaxSize() const override;
  size_t getInfoDataMaxSize() const override;
  uint64_t getDataNumericId(const void* pEventBuffer,
                            size_t eventBufferSize) const override;

  template<typename T>
  T getInfo(GenTL::EVENT_INFO_CMD_LIST command) const
  {
    T value;
    size_t size = sizeof(value);
    GenTL::INFO_DATATYPE dataType;
    ThrowIfError(
      mCApi,
      mCApi->EventGetInfo(mEventHandle, command, &dataType, &value, &size));
    return value;
  }

  template<typename T>
  T getInfo(uint32_t customCommand) const
  {
    return getInfo<T>(static_cast<GenTL::EVENT_INFO_CMD_LIST>(customCommand));
  }

#ifdef SWIG
    EXPLODE_TEMPLATE_TYPES(getInfo);
#endif

  template<typename T>
  T getDataInfo(const void* pEventBuffer,
                size_t eventBufferSize,
                GenTL::EVENT_DATA_INFO_CMD_LIST command) const
  {
    T value;
    size_t outSize = sizeof(value);
    GenTL::INFO_DATATYPE dataType;
    ThrowIfError(mCApi,
                 mCApi->EventGetDataInfo(mEventHandle,
                                         pEventBuffer,
                                         eventBufferSize,
                                         command,
                                         &dataType,
                                         &value,
                                         &outSize));
    return value;
  }

  template<typename T>
  T getDataInfo(const void* pEventBuffer,
                size_t eventBufferSize,
                uint32_t customCommand) const
  {
    return getDataInfo<T>(
      pEventBuffer,
      eventBufferSize,
      static_cast<GenTL::EVENT_DATA_INFO_CMD_LIST>(customCommand));
  }

#ifdef SWIG
    EXPLODE_TEMPLATE_TYPES(getDataInfo);
#endif

protected:
  friend class DataStream;
  friend class Device;
  friend class Interface;
  friend class TransportLayer;

  Event(std::shared_ptr<const CApi> cApi,
        std::shared_ptr<const IModule> module,
        GenTL::EVENT_TYPE_LIST eventType,
        GenTL::EVENTSRC_HANDLE eventSrcHandle);

private:
  EventResult resultFromGenTLError(GenTL::GC_ERROR errorCode,
                                   size_t bufferSizeFilled) const;

protected:
  std::shared_ptr<const CApi> mCApi;

private:
  std::shared_ptr<const IModule> mParentModule;
  GenTL::EVENT_TYPE_LIST mEventType;
  GenTL::EVENT_HANDLE mEventHandle;
  GenTL::EVENTSRC_HANDLE mEventSrcHandle;
  bool mIsRegistered;
};


/* (explicit specialization has to be declared in a scope where primary template can be defined) */
template<>
std::string Event::getInfo(GenTL::EVENT_INFO_CMD_LIST command) const;

template<>
std::string Event::getDataInfo(const void* pEventBuffer,
                               size_t eventBufferSize,
                               GenTL::EVENT_DATA_INFO_CMD_LIST command) const;

}
