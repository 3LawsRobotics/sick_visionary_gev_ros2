// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "GenIStreamDll.h"
#include "IAnyParameters.h"

namespace genistream {

/**
 * Class that can be used to temporarily set a value of a node in a NodeMap.
 * Mainly used for selectors but can be used for any parameter. The class uses
 * RAII to ensure that the value is reset to its original value when the object
 * goes out of scope.
 *
 * Use \ref ScopedEnumValue and \ref ScopedIntValue depending on the type of the
 * selector.
 */
template<typename T>
class GENISTREAM_API ScopedNodeValue
{
public:
  ScopedNodeValue(std::shared_ptr<IAnyParameters> parameters,
                  const std::string& parameterName,
                  T value);
  ~ScopedNodeValue();

private:
  T getValue();
  void setValue(T value);

private:
  std::shared_ptr<IAnyParameters> mParameters;
  std::string mNodeName;
  T mOriginalValue;
};

/** ScopedNodeValue for enumeration nodes. */
typedef ScopedNodeValue<std::string> ScopedEnumValue;

/** ScopedNodeValue for integer nodes. */
typedef ScopedNodeValue<int64_t> ScopedIntValue;


template<typename T>
ScopedNodeValue<T>::ScopedNodeValue(std::shared_ptr<IAnyParameters> parameters,
                                    const std::string& parameterName,
                                    T value)
  : mParameters(std::move(parameters))
  , mNodeName(parameterName)
{
  mOriginalValue = getValue();
  // Only set value if necessary to avoid unnecessary invalidation events
  if (value != mOriginalValue)
  {
    setValue(value);
  }
}

template<typename T>
ScopedNodeValue<T>::~ScopedNodeValue()
{
  try
  {
    // Only set value if necessary to avoid unnecessary invalidation events
    if (mOriginalValue != getValue())
    {
      setValue(mOriginalValue);
    }
  }
  catch (...)
  {
    // If we fail to reset the node it is likely because an exception has
    // been thrown in the scope of the RAII object. We are more likely
    // interested in throwing that exception so we ignore this.
  }
}

template<>
inline std::string ScopedNodeValue<std::string>::getValue()
{
  return mParameters->getEnum(mNodeName);
}

template<>
inline void ScopedNodeValue<std::string>::setValue(std::string value)
{
  mParameters->setEnum(mNodeName, value);
}

template<>
inline int64_t ScopedNodeValue<int64_t>::getValue()
{
  return mParameters->getInt(mNodeName);
}

template<>
inline void ScopedNodeValue<int64_t>::setValue(int64_t value)
{
  mParameters->setInt(mNodeName, value);
}

}
