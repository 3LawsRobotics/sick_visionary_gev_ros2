// Copyright 2019-2023 SICK AG. All rights reserved.
#pragma once

#include "CameraFile.h"
#include "CameraParameters.h"
#include "ConfigurationDataTypes.h"
#include "DataStreamStatistics.h"
#include "GenIStreamDll.h"
#include "NodeMap.h"
#include "UserSet.h"
#include "event/CameraLog.h"
#include "event/ISubscription.h"
#include "frame/IAdditionalInfoBuilder.h"

#include <chrono>

namespace gentlcpp {
class IDataStream;
class IDevice;
}

namespace genistream {

class FrameGrabber;

namespace event {
typedef std::function<void(const gentlcpp::DeviceId&)> DisconnectCallback;
class CameraLogPoller;
class CameraDisconnectPoller;
}

/**
 * An interface representing a camera and the connection to it.
 *
 * The class allows access to configuration parameters via \ref CameraParameters
 * and \ref IAnyParameters. It also allows you to create a \ref FrameGrabber to
 * grab \ref frame::IFrame%s.
 *
 * \note In C# you are required to explicitly \ref disconnect() (or dispose)
 *       when you are done with the object to ensure that underlying resources
 *       are released immediately and are not kept open until garbage collection
 *       occurs. In C++ this is handled in a RAII fashion by ensuring all
 *       std::shared_ptr%s to the object are released.
 */
class GENISTREAM_API ICamera
{
public:
  virtual ~ICamera() noexcept = default;

  /**
   * Creates a \ref FrameGrabber for this camera and allocates buffers that will
   * be used to store received frames.
   *
   * The size of the buffers will depend on the configured payload size, i.e.,
   * the settings of the camera. If you reconfigure the camera you need to
   * create a new FrameGrabber.
   *
   * The number of buffers you should choose depends on your application but is
   * a trade-off between the amount of memory used and the risk of losing data
   * because buffers are not readily available.
   *
   * See \ref md_doc_frame-queue-design for more information.
   *
   * \param buffersCount the number of buffers to allocate
   * \param infoToAdd controls which additional info to add to grabbed frames
   */
  virtual std::shared_ptr<FrameGrabber> createFrameGrabber(
    size_t buffersCount = 20,
    frame::AdditionalInfo infoToAdd = frame::AdditionalInfo::ALL_INFO) = 0;

  /**
   * Subscribes to get asynchronous notification when a camera is disconnected.
   * When the returned subscription object is destroyed, unsubscription occurs
   * and notifications end. Re-entrant unsubscription is allowed, i.e., it is
   * allowed to destroy the subscription object from the \ref
   * event::DisconnectCallback function.
   *
   * \see \ref md_doc_event-subscriptions
   * \warning The callback function is invoked from a different thread context!
   *          The user must ensure thread safety when handling the call.
   * \warning It is not allowed to destroy the ICamera object from within the
   *          \ref event::DisconnectCallback function since this would tear down
   *          camera resources while in use. You can call \ref disconnect() to
   *          explicitly close GenTL resources if you like, otherwise that will
   *          be done automatically.
   * \param onDisconnect the function that should be invoked when the camera
   *        disconnects
   * \return a \ref event::SubscriptionEnvelope carrying a \ref
   *         event::ISubscription object. The ISubscription should be kept until
   *         no more notifications are desired, destroying it will cause
   *         unsubscription. The envelope contains a mutex lock that is
   *         automatically kept until the ISubscription object is assigned to
   *         the final destination variable. This allows re-entrant
   *         unsubscription, i.e., unsubscription from within the callback
   *         function, without risk of using an uninitialized variable.
   */
  virtual event::SubscriptionEnvelope
  subscribeToDisconnectEvent(event::DisconnectCallback onDisconnect) = 0;

  /**
   * Subscribes to get asynchronous notification when the camera produces a log.
   * When the returned subscription object is destroyed, unsubscription occurs
   * and notifications end. Re-entrant unsubscription is allowed, i.e., it is
   * allowed to destroy the subscription object from the \ref event::LogCallback
   * function.
   *
   * \see \ref md_doc_event-subscriptions
   * \warning The callback function is invoked from a different thread context!
   *          The user must ensure thread safety when handling the call.
   * \param onLogMessage the function that should be invoked with the log
   *        message
   * \return a \ref event::SubscriptionEnvelope carrying a \ref
   *         event::ISubscription object. The ISubscription should be kept until
   *         not more notifications are desired, destroying it will cause
   *         unsubscription. The envelope contains a mutex lock that is
   *         automatically kept until the ISubscription object is assigned to
   *         the final destination variable. This allows re-entrant
   *         unsubscription, i.e., unsubscription from within the callback
   *         function, without risk of using an uninitialized variable.
   */
  virtual event::SubscriptionEnvelope
  subscribeToLogEvent(event::LogCallback onLogMessage) = 0;

  /**
   * Creates a \ref event::CameraLogPoller object that can be used for polling
   * for camera logs. Use \refcpp{subscribeToLogEvent()}
   * \refcs{ICamera.LogReceived} for notifications on a callback function.
   *
   * \return a object for polling camera logs
   * \incubating
   */
  virtual std::shared_ptr<event::CameraLogPoller> createLogPoller() = 0;

  /**
   * Creates a \ref event::CameraDisconnectPoller object that can be used for
   * polling for camera disconnections. Use
   * \refcpp{subscribeToDisconnectEvent()} \refcs{ICamera.Disconnected} for
   * notification on a callback function.
   *
   * \return a object for polling camera disconnects
   * \incubating
   */
  virtual std::shared_ptr<event::CameraDisconnectPoller>
  createDisconnectPoller() = 0;

  /** \return the id that uniquely identifies this camera */
  virtual gentlcpp::DeviceId getId() const = 0;

  /** \return the camera model name */
  virtual std::string getModel() const = 0;

  /**
   * \return the underlying \ref gentlcpp::IDevice object
   * \lowlevel
   */
  AVOID virtual std::shared_ptr<gentlcpp::IDevice> getDevice() = 0;

  /**
   * \return an object to set and get camera parameters in a type safe manner,
   *         i.e., strings are not used for parameter names or enum values.
   * \note When getting or setting a parameter with \ref CameraParameters,
   *       necessary selectors will be set and not restored. This may pose a
   *       problem if mixing using this object and setting parameters with name,
   *       e.g., through \ref IAnyParameters.
   */
  virtual std::shared_ptr<CameraParameters> getCameraParameters() = 0;

  /**
   * \return an interface to access parameters on the camera by name
   * \note It is preferable to use \ref getCameraParameters() to get an
   *       interface that is not sensitive to typos in parameter names.
   */
  virtual std::shared_ptr<IAnyParameters> getAnyParameters() = 0;

  /**
   * \return an interface to access parameters for the local device, i.e., the
   *         PC side GenTL view of the device.
   * \lowlevel
   */
  AVOID virtual std::shared_ptr<IAnyParameters> getLocalAnyParameters() = 0;

  /**
   * \return the node map for the remote device
   * \lowlevel Prefer using \ref getAnyParameters().
   */
  AVOID virtual std::shared_ptr<NodeMap> getNodeMap() = 0;

  /**
   * \return the node map for the local device, i.e., the PC side GenTL view of
   *         the device.
   * \lowlevel Prefer using \ref getLocalAnyParameters().
   */
  AVOID virtual std::shared_ptr<NodeMap> getLocalNodeMap() = 0;

  /**
   * \return the data stream from the camera
   * \lowlevel
   */
  AVOID virtual std::shared_ptr<gentlcpp::IDataStream> getDataStream() = 0;

  /**
   * Retrieves a snapshot of GigE Vision packet and block statistics from
   * currently connected camera data stream. The statistics is retrieved from
   * underlying GenTL producer and is implementation specific and hence this
   * method might not work if another producer than SICKGigEVisionTL is used.
   *
   * \return a collection of GigE Vision data stream statistics counters.
   * \incubating
   */
  virtual DataStreamStatistics getDataStreamStatistics() const = 0;

  /**
   * Performs an action where configuration is done in a register streaming
   * session.
   *
   * This allows setting several parameters atomically, i.e., verification is
   * done on the complete configuration when done rather than after each
   * parameter is set. This helps when there are dependencies between
   * parameters, e.g., setting offset and height.
   *
   * \throws InvalidConfiguration if the configuration was invalid
   */
  virtual void withRegisterStreaming(
    std::function<void(std::shared_ptr<CameraParameters>)> action) = 0;

  /**
   * Performs an action where configuration is done in a register streaming
   * session.
   *
   * This allows setting several parameters atomically, i.e., verification is
   * done on the complete configuration when done rather than after each
   * parameter is set. This helps when there are dependencies between
   * parameters, e.g., setting offset and height.
   *
   * \throws InvalidConfiguration if the configuration was invalid
   */
  virtual void withRegisterStreamingAny(
    std::function<void(std::shared_ptr<IAnyParameters>)> action) = 0;

  /**
   * Sets the heartbeat in microseconds. Useful when debugging to be able to
   * increase timeout to avoid losing connection to camera.
   */
  virtual void
  setHeartbeatTimeout(std::chrono::microseconds microSeconds) const = 0;

  /** \return an object to access a configuration stored on the camera */
  virtual std::shared_ptr<IUserSet> openUserSet(UserSetId userSetId) = 0;

  /**
   * Exports all writable parameters as a CSV file with the format
   * "<name>,<value>", one parameter per row.
   *
   * \see \ref importParameters()
   */
  virtual void exportParameters(std::ostream& outputCsv) = 0;

  /**
   * Imports parameters from a CSV file. The format is "<name>,<value>", one
   * parameter per row.
   *
   * Importing parameters will not cause node invalidation events or parameter
   * change events, see \ref IAnyParameters::subscribeToInvalidation() and \ref
   * Parameter::subscribeToChange().
   *
   * \see \ref exportParameters()
   */
  virtual ConfigurationResult importParameters(std::istream& inputCsv) = 0;

  /**
   * Sends contents to a camera file. The given camera file corresponds to the
   * value of GenICam parameter "FileSelector". File named "UserFile" can be
   * used for arbitrary file storage on camera, but has a limited size.
   *
   * \param cameraFileName the name of the GenICam file on the camera, i.e., the
   *        FileSelector
   * \param contents the contents to write to the camera file
   * \deprecated Prefer using \ref getFile() and \ref
   *             CameraFile::sendFileContentToCamera().
   * \deprecatedsince 2.7
   */
  AVOID virtual void sendFileContentToCamera(const std::string& cameraFileName,
                                             const std::string& contents) = 0;
  /**
   * Sends a file to the camera. The given camera file corresponds to the value
   * of GenICam parameter "FileSelector". File named "UserFile" can be used for
   * arbitrary file storage on camera, but has a limited size.
   *
   * \param cameraFileName the name of the GenICam file on the camera, i.e., the
   *        FileSelector
   * \param filePath path to the file
   * \deprecated Prefer using \ref getFile() and \ref
   *             CameraFile::sendFileToCamera().
   * \deprecatedsince 2.7
   */
  AVOID virtual void sendFileToCamera(const std::string& cameraFileName,
                                      const std::string& filePath) = 0;

  /**
   * Retrieves the contents of a camera file. The given camera file corresponds
   * to the value of GenICam parameter "FileSelector".
   *
   * \param cameraFileName the name of the GenICam file on the camera, i.e., the
   *        FileSelector
   * \return the camera file contents
   * \deprecated Prefer using \ref getFile() and \ref
   *             CameraFile::retrieveFileContentFromCamera().
   * \deprecatedsince 2.7
   */
  AVOID virtual std::string
  retrieveFileContentFromCamera(const std::string& cameraFileName) = 0;

  /**
   * Saves a camera file to a file path.
   *
   * \param cameraFileName the name of the GenICam file on the camera, i.e., the
   *        FileSelector
   * \param destinationFilePath path where to save the camera file
   * \deprecated Prefer using \ref getFile() and \ref
   *             CameraFile::retrieveFileFromCamera().
   * \deprecatedsince 2.7
   */
  AVOID virtual void
  retrieveFileFromCamera(const std::string& cameraFileName,
                         const std::string& destinationFilePath) = 0;

  /**
   * Deletes a file from the camera. The given camera file corresponds to the
   * value of camera GenICam parameter "FileSelector".
   *
   * \param cameraFileName the name of the GenICam file on the camera, i.e., the
   *        FileSelector
   * \deprecated Prefer using \ref getFile() and \ref
   *             CameraFile::deleteFromCamera().
   * \deprecatedsince 2.7
   */
  AVOID virtual void
  deleteFileFromCamera(const std::string& cameraFileName) = 0;

  /**
   * \return objects to for each file on the camera, to access the file or
   *         information about the file
   */
  virtual std::vector<std::shared_ptr<CameraFile>> listFiles() = 0;

  /**
   * \param cameraFileName the name of the file
   * \return an object to access a file or information about a file on the
   *         camera
   */
  virtual std::shared_ptr<CameraFile>
  getFile(const std::string& cameraFileName) = 0;

  /**
   * Updates the firmware of the camera. This function can wait for the firmware
   * update to complete and the camera to reboot. On reboot, the connection to
   * the camera is then lost and the user has to reconnect.
   *
   * \incubating
   */
  virtual void updateFirmware(const std::string& firmwarePackagePath,
                              bool waitForCompletion = true) = 0;

  /**
   * If the camera experiences problems, it can end up in rescue mode, which is
   * a secondary boot path with a firmware previously known to be working. In
   * the secondary boot path, image acquisition is not allowed. The reason for
   * booting up in rescue mode may be hardware related, interrupted firmware
   * update or a serious firmware bug causing a crash.
   *
   * \return true if the device is currently in rescue mode
   */
  virtual bool isInRescueMode() = 0;

  /**
   * A connected camera instance is originally always connected. However, by
   * losing the link to the camera due to some hardware issue, or by explicitly
   * calling the method \ref disconnect() this connected camera instance will
   * end up in an irrevocable disconnected state. use \ref CameraDiscovery to
   * connect to the camera again.
   *
   * \see \ref subscribeToDisconnectEvent()
   */
  virtual bool isConnected() const = 0;

  /**
   * Closes the connection to this camera. This allows explicit disconnection,
   * without destroying this camera object.
   *
   * \note After you call this function, some objects associated with the camera
   *       may not be possible to use, e.g., accessing parameters.
   * \note This should not be called from a \refcpp{event::DisconnectCallback}
   *       \refcs{CameraDisconnectObserver} registered with
   *       \refcpp{subscribeToDisconnectEvent()} \refcs{ICamera.Disconnected}
   *       since the object is busy dispatching the disconnect callback.
   */
  virtual void disconnect() = 0;
};

}
