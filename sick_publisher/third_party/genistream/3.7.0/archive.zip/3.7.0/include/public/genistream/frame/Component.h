// Copyright 2019-2023 SICK AG. All rights reserved.
#pragma once

#include "../GenIStreamDll.h"
#include "IComponent.h"
#include "Image.h"

// VISIONARY: temporary, bad idea to point from public to private header, but the DataPointer needs to be declared
// here because of the use in vector -> to be refactored...
#include "../../../private/genistream/frame/DataPointer.h"

namespace genistream { namespace frame {

/**
 * This is a concrete implementation of the \ref IComponent interface which can
 * be used to build components within \ref Region%s.
 *
 * There are public functions within this class, not exposed in the \ref
 * IComponent interface, for building. Instances are created with, e.g., \ref
 * Region::addComponent(ComponentId).
 */
#ifdef SWIG
class GENISTREAM_API Component : public IComponent
#else
class GENISTREAM_API Component : public IComponent,
                  public std::enable_shared_from_this<Component>
#endif
{
public:
  /** Sets the width. */
  std::shared_ptr<Component> width(size_t width);
  /** Sets the delivered height. */
  std::shared_ptr<Component> deliveredHeight(size_t deliveredHeight);
  /** Sets the configured height. */
  std::shared_ptr<Component> configuredHeight(size_t configuredHeight);
  /** Sets the \ref CoordinateSystem. */
  std::shared_ptr<Component> coordinateSystem(CoordinateSystem system);

  /**
   * Adds a channel, corresponding to a GenTL buffer part, e.g., A or C for the
   * uncalibrated AC format. For non-planar pixel formats a single channel
   * should be added when creating a component.
   *
   * The data pointed to will only be referred by the Component, i.e., it will
   * not deallocate the associated memory.
   *
   * \incubating We consider changing this to pass data as `void*`.
   */
  std::shared_ptr<Component> addReferringChannel(
    PixelFormat format,
    uint8_t * data,
    std::shared_ptr<gentlcpp::IBufferPart> part = nullptr);

  /**
   * Adds a channel, e.g., A or C for the uncalibrated AC format. For non-planar
   * pixel formats a single channel should be added when creating a component.
   *
   * The Component object will take ownership of the data pointed to, i.e., it
   * will deallocate the associated memory when the object is destroyed.
   *
   * \note The data must be allocated as an array of `uint8_t` since it will be
   *       deleted as such.
   * \incubating
   */
  std::shared_ptr<Component> addOwningChannel(PixelFormat format,
                                              uint8_t * data);

  ComponentId getId() const override;
  PixelFormat getPixelFormat() const override;
  PixelFormat getChannelPixelFormat(size_t channel) const override;
  size_t getWidth() const override;
  size_t getDeliveredHeight() const override;
  size_t getConfiguredHeight() const override;

  uint8_t* getData(size_t channel = 0) const override;
  size_t getDeliveredDataSize() const override;
  size_t getConfiguredDataSize() const override;

  size_t getStride() const override;
  size_t getBitsPerPixel() const override;

  const CoordinateSystem& getCoordinateSystem() const override;
  double getYResolution() const override;

  size_t getNumberOfChannels() const override;

  AVOID std::weak_ptr<gentlcpp::IBufferPart> getBufferPart(size_t channel = 0)
    const override;

  double getValue(size_t x, size_t y, size_t channel = 0) const override;
  Point getPoint(size_t x,
                 size_t y,
                 double missingDataValue =
                   std::numeric_limits<double>::signaling_NaN()) const override;

  std::shared_ptr<IComponent> copy() const override;
  std::shared_ptr<IComponent> copyUnpacked() const override;
  std::shared_ptr<IComponent> copyTransformed(
    double missingDataValue = std::numeric_limits<double>::signaling_NaN())
    const override;
  std::shared_ptr<Image> createCopiedImage(size_t channel = 0) const override;
  std::shared_ptr<Image> createReferringImage(size_t channel = 0)
    const override;

  void logTo(std::ostream & s, size_t indentLevel) const override;

private:
  friend class Region;
  friend class ComponentTest;
  Component(ComponentId componentId);

  Image::CoordinateInfo createCoordinateInfo(size_t channel) const;
  void throwIfChannelOutOfRange(size_t channel) const;
  std::shared_ptr<Component> addOwningChannel(PixelFormat format,
                                              DataPointer && data);
  std::shared_ptr<Component> copyConcrete() const;
  static std::shared_ptr<Component> concatenate(
    const ConstComponentList& components);

private:
  ComponentId mComponentId;

  PixelFormat mPixelFormat;
  size_t mWidth;
  size_t mDeliveredHeight;
  size_t mConfiguredHeight;
  CoordinateSystem mSystem;
  std::vector<DataPointer> mData;
  std::vector<std::weak_ptr<gentlcpp::IBufferPart>> mBufferParts;

// To allow implementing the deprecated getBufferPart() function
#pragma warning(suppress : 4996)
};

}}
