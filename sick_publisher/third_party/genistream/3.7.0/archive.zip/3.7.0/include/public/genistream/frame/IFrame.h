// Copyright 2019-2023 SICK AG. All rights reserved.
#pragma once

#include "genistream/Avoid.h"
#include "genistream/FrameMetadata.h"
#include "genistream/GenIStreamDll.h"
#include "genistream/LineMetadata.h"
#include "genistream/frame/Aoi.h"
#include "genistream/frame/CoordinateSystem.h"
#include "genistream/frame/IRegion.h"

#include <map>

namespace gentlcpp {
class IBuffer;
}
namespace genistream {
class NodeMap;
}

namespace genistream { namespace frame {

/**
 * Configuration info regarding a specific region that is cached in the Frame
 * class to avoid having to fetch the configuration from the camera during
 * acquisition.
 *
 * \lowlevel You should not have to create instances of this struct yourself.
 *           Prefer using \ref FrameGrabber.
 */
struct RegionConfigurationInfo
{
  Aoi aoi;
  /**
   * Coordinate system for range/peak 2 components in the region. Unused for
   * sensor regions.
   */
  CoordinateSystem rangeSystem;
  Scan3dExtractionMethod extractionMethod;
  Scan3dOutputMode outputMode;
};

/**
 * Complete configuration info that is cached in an \ref IFrame to avoid having
 * to fetch the configuration from the camera during acquisition.
 *
 * \lowlevel You should not have to create instances of this struct yourself.
 *           Prefer using \ref FrameGrabber.
 */
struct FrameConfigurationInfo
{
  DeviceScanType deviceScanType;
  AcquisitionMode acquisitionMode;
  AcquisitionStopMode acquisitionStopMode;
  std::map<RegionId, RegionConfigurationInfo> regions;
};

/**
 * This is an interface for classes that provide an abstraction on top of GenTL
 * buffers. Instead of working with buffers and parts it is easier to work with
 * region and component concepts, since that is what is configured in the
 * camera.
 *
 * Each buffer part contains data corresponding to a specific \ref IComponent in
 * a specific \ref IRegion.
 *
 * To receive frames from a camera, use the \ref FrameGrabber class. It is also
 * possible to load iCon formatted files to get IFrame objects, see the static
 * member function \refcs{Load(string,IFrame.LoadMode)} \refcpp{load()},
 * \refcpp{read()}.
 *
 * \note In C# you are required to explicitly \ref release the frame when you
 *       are done with it, to ensure that the underlying \ref gentlcpp::IBuffer
 *       can be reused immediately and isn't kept until garbage collection
 *       occurs. If you don't do this you may suffer from buffer depletion. In
 *       C++ this is handled in a RAII fashion by ensuring all std::shared_ptr%s
 *       to the object are released.
 * \note Frames grabbed with a \ref FrameGrabber depends on its parent object,
 *       i.e., to use this object you must ensure the \ref FrameGrabber object
 *       is not destroyed.
 */
class GENISTREAM_API IFrame
{
public:
  enum class SaveCalibratedMode
  {
    /**
     * Saves range components as floating point data when the image is
     * calibrated and possibly rectified. When saving such an image using this
     * mode, the range data is first transformed to world coordinates.
     *
     * This is a legacy mode and is used in Stream Setup version 7.8 and
     * earlier.
     */
    RANGE_AS_FLOAT,

    /**
     * Saves range components as unsigned integer data when the image is
     * calibrated and possibly rectified. This guarantees no loss of precision
     * and smaller file size, however the files may not be properly loaded in
     * Stream Setup version 7.8 and earlier.
     *
     * Prefer this option when building a new system that is not dependent on
     * these tools.
     */
    RANGE_AS_UNSIGNED
  };

  enum class LoadMode
  {
    /**
     * Loads floating point components as floating point data, without
     * conversion.
     *
     * This mode is intended to load images saved with previous generations of
     * the camera, or that have had operations performed on them that makes it
     * impossible to represent in the original unsigned integer format normally
     * used when saving frames in iCon format.
     */
    LOAD_FLOAT_AS_FLOAT,

    /**
     * Loads floating point components converting them to 16-bit unsigned
     * integer data. If the image has been saved with GenIStream, this is the
     * preferred loading method since it recreates the \ref IFrame exactly as it
     * was saved.
     *
     * For legacy frames with float data, not saved with GenIStream, loading as
     * unsigned may introduce a slight rounding since the same metadata is not
     * available.
     */
    LOAD_FLOAT_AS_UNSIGNED
  };

public:
  virtual ~IFrame() = default;

  /**
   * Loads a frame from iCon file format. Two files are read, one .xml file and
   * one .dat file.
   *
   * \param filePath path excluding file extension, or with .xml or .dat
   *        extension, where the frame is loaded from
   * \param mode the way to load calibrated range components saved as floating
   *        point.
   */
  static std::shared_ptr<IFrame>
  load(const std::string& filePath,
       LoadMode mode = LoadMode::LOAD_FLOAT_AS_UNSIGNED);

  /**
   * Loads a frame from iCon format from two different output streams.
   *
   * \param xmlStream stream containing the xml data.
   * \param datStream stream containing the dat data.
   * \param mode the way to read calibrated range components saved as floating
   *        point.
   */
  static std::shared_ptr<IFrame>
  read(std::istream& xmlStream,
       std::istream& datStream,
       LoadMode mode = LoadMode::LOAD_FLOAT_AS_UNSIGNED);

  /**
   * \return the number of lines delivered for a 3D frame, i.e., the height in
   *         the scan 3D extraction region according to GenICam
   * \throws NotAvailableException if the frame is a sensor image
   */
  virtual size_t getDeliveredLineCount() const = 0;

  /**
   * \return the number of lines for a completed 3D frame. This may be higher
   *         than the delivered lines if the camera is configured with Immediate
   *         AcquisitionStopMode.
   * \throws NotAvailableException if the frame is a sensor image
   */
  virtual size_t getConfiguredLineCount() const = 0;

  /**
   * \return true if the frame has a line count, i.e., is not a sensor image
   */
  virtual bool hasLineCount() const = 0;

  /**
   * Convenience function to know if the frame was ended early. Useful when the
   * camera is configured to use the AcquisitionStopMode Immediate.
   *
   * \return true if the number of delivered lines are less than the configured.
   */
  virtual bool wasEndedEarly() const;

  /** \return the \ref IRegion%s within the frame */
  virtual ConstRegionList getRegions() const;

  /** \return the \ref IRegion%s within the frame */
  virtual RegionList getRegions() = 0;

  /**
   * \return true if the frame contains a \ref IRegion with the given \ref
   *         RegionId
   */
  virtual bool hasRegion(RegionId regionId) const = 0;

  /**
   * \return the object for a specific RegionId
   * \throws std::invalid_argument if the RegionId is not available
   */
  virtual std::shared_ptr<const IRegion> getRegion(RegionId regionId) const;

  /**
   * \return the object for a specific RegionId
   * \throws std::invalid_argument if the RegionId is not available
   */
  virtual std::shared_ptr<IRegion> getRegion(RegionId regionId) = 0;

  /**
   * \return the sole \ref IComponent, in any \ref IRegion, with the given \ref
   *         ComponentId
   * \throws NotAvailableException if the frame contains no component with
   *         intensity
   * \throws GenIStreamException if the frame contains more than one component
   *         with intensity
   */
  virtual std::shared_ptr<const IComponent>
  getComponent(ComponentId componentId) const = 0;

  /**
   * \return the sole \ref IComponent, in any \ref IRegion, with intensity data
   * \throws NotAvailableException if the frame contains no component with
   *         intensity
   * \throws GenIStreamException if the frame contains more than one component
   *         with intensity
   */
  virtual std::shared_ptr<const IComponent> getIntensity() const;

  /**
   * \return the sole \ref IComponent, in any \ref IRegion, with range data
   * \throws NotAvailableException if the frame contains no component with range
   * \throws GenIStreamException if the frame contains more than one component
   *         with range
   */
  virtual std::shared_ptr<const IComponent> getRange() const;

  /**
   * \return the sole \ref IComponent, in any \ref IRegion, with reflectance
   *         data
   * \throws NotAvailableException if the frame contains no component with
   *         reflectance
   * \throws GenIStreamException if the frame contains more than one component
   *         with reflectance
   */
  virtual std::shared_ptr<const IComponent> getReflectance() const;

  /**
   * \return the sole \ref IComponent, in any \ref IRegion, with scatter data
   * \throws NotAvailableException if the frame contains no component with
   *         scatter
   * \throws GenIStreamException if the frame contains more than one component
   *         with scatter
   */
  virtual std::shared_ptr<const IComponent> getScatter() const;

  /** \return the chunk metadata per scanned line */
  virtual ConstLineMetadataVectorPtr getLineMetadata() const = 0;

  /** \return the chunk metadata for a frame */
  virtual const FrameMetadata& getFrameMetadata() const = 0;

  /**
   * Get additional information attached to frame. This information is currently
   * not set by GenIStream when grabbing frames but Ranger3 Studio uses it to
   * attach information regarding the state of the system during acquisition.
   * Useful for investigating problem with grabbed frame or camera.
   *
   * \return an arbitrary formatted string with extra information
   * \incubating
   */
  virtual std::string getAdditionalInfo() const = 0;

  /** \return the identification number of the frame */
  virtual uint64_t getFrameId() const = 0;

  /**
   * Indicates whether the buffer from the transport layer was considered
   * incomplete. If the frame is incomplete the data within the frame may be
   * corrupt, e.g., because some packets were not received.
   *
   * You cannot trust the image data or the line metadata unless this function
   * returns false! Image data that is not received will have the "missing data"
   * value. If line metadata cannot be accessed at all, it will have default
   * values.
   *
   * \note A frame that was ended early will not be considered incomplete unless
   *       the actually captured image data could not be fully received.
   * \return true if the frame was not fully received
   */
  virtual bool isIncomplete() const = 0;

  /**
   * Opposite of \ref isIncomplete() which may be more natural to use in some
   * circumstances.
   *
   * Indicates whether the buffer from the transport layer was considered
   * complete. If the frame is not complete the data within the frame may be
   * corrupt, e.g., because some packets were not received.
   *
   * You cannot trust the image data or the line metadata unless this function
   * returns true! Image data that is not received will have the "missing data"
   * value. If line metadata cannot be accessed at all, it will have default
   * values.
   *
   * \note A frame that was ended early will be considered complete unless the
   *       actually captured image data could not be fully received.
   * \return true if the frame was fully received
   */
  virtual bool isComplete() const;

  /**
   * Release the underlying borrowed frame payload memory buffer, if frame
   * implementation has that and it is not already released.
   *
   * The payload memory is normally managed by destructor of frame
   * implementation, but this method needs to be explicitly called in garbage
   * collected languages such as, e.g., C# and Java. The reason is that both
   * destruction and hence memory re-useability can be erratic in garbage
   * collected environments.
   *
   * \incubating
   */
  AVOID_IN_CPP virtual void release() = 0;

  /**
   * Saves this frame into iCon file format. Two files are produced, one .xml
   * file and one .dat file.
   *
   * Range data is automatically converted to 16-bit.
   *
   * \param filePath path excluding file extension, or with .xml or .dat
   *        extension, where the frame is saved to
   * \param mode the way to save calibrated range components
   */
  virtual void save(
    const std::string& filePath,
    SaveCalibratedMode mode = SaveCalibratedMode::RANGE_AS_UNSIGNED) const = 0;

  /**
   * Writes this frame into iCon file format to two different output streams.
   *
   * \param xmlStream stream containing the xml data.
   * \param datStream stream containing the dat data.
   * \param mode the way to write calibrated range components
   */
  virtual void write(
    std::ostream& xmlStream,
    std::ostream& datStream,
    SaveCalibratedMode mode = SaveCalibratedMode::RANGE_AS_UNSIGNED) const = 0;

  /**
   * \return the underlying \ref gentlcpp::Buffer if the frame was created from
   *         a buffer. The pointer expires when buffer is released.
   * \throws NotAvailableException if the frame was created some other way
   * \lowlevel
   */
  AVOID virtual std::weak_ptr<gentlcpp::IBuffer> getBuffer() = 0;

  /**
   * \return the underlying \ref gentlcpp::IBuffer if the frame was created from
   *         a buffer
   * \throws NotAvailableException if the frame was created some other way or if
   *         buffer is already released
   * \lowlevel
   */
  AVOID virtual std::shared_ptr<gentlcpp::IBuffer> tryGetBuffer();

  /**
   * \return a copy of this \ref IFrame, including all \ref IRegion%s and \ref
   *         IComponent%s. The image data in components is always copied, so the
   *         original \ref IFrame can be released to allow GenTL buffer reuse.
   */
  virtual std::shared_ptr<IFrame> copy() const = 0;

  /**
   * Concatenates consecutively grabbed frames into a new frame, including image
   * data. The image data is copied into newly allocated memory areas.
   *
   * Some meta information like frame ID, \ref FrameMetadata and additional info
   * (see \ref getAdditionalInfo()) cannot be concatenated but are taken from
   * the last frame.
   *
   * \param other another consecutive frame to concatenate to this one
   * \return a new frame with image data in components concatenated
   * \throws GenIStreamException if the frames are not in consecutive order
   *         (frame ID), don't have the same components or the frames contain
   *         intensity data
   * \incubating
   */
  virtual std::shared_ptr<IFrame>
  concatenate(std::shared_ptr<const IFrame> other) const = 0;

  /**
   * Concatenates consecutively grabbed frames into a new frame, including image
   * data. The image data is copied into newly allocated memory areas.
   *
   * Some meta information like frame ID, \ref FrameMetadata and additional info
   * (see \ref getAdditionalInfo()) cannot be concatenated but are taken from
   * the last frame.
   *
   * \param frames one or more consecutive frames to concatenate
   * \return a new frame with image data in components concatenated
   * \throws GenIStreamException if the frames are not in consecutive order
   *         (frame ID), don't have the same components or the frames contain
   *         intensity data
   * \incubating
   */
  static std::shared_ptr<IFrame>
  concatenate(const std::vector<std::shared_ptr<const IFrame>>& frames);

  /**
   * Produces a string representing the difference between two frames. The
   * algorithm is naive and may produce non-optimal strings.
   *
   * \param other the second frame
   * \return a string representing the difference between the frames
   * \incubating
   */
  std::string diff(std::shared_ptr<const IFrame> other) const;
};

/**
 * Compares the contents of two frames, including meta-information, chunk line
 * metadata and actual image data.
 */
bool operator==(const IFrame& lhs, const IFrame& rhs);

/**
 * Compares the contents of two frames, including meta-information, chunk line
 * metadata and actual image data.
 */
bool operator!=(const IFrame& lhs, const IFrame& rhs);

/**
 * Compares the contents of two frames, including meta-information, chunk line
 * metadata and actual image data.
 *
 * \param lhs the first frame
 * \param rhs the second frame
 * \param allowedFraction the allowed difference fraction between
 *        meta-information that is floating point
 * \return true if the frames are considered equal
 */
bool compare(const IFrame& lhs,
             const IFrame& rhs,
             double allowedFraction = 0.0);

/**
 * Logs information about a \ref IFrame and the \ref IRegion%s and \ref
 * IComponent%s within it.
 */
std::ostream& operator<<(std::ostream& s, const IFrame& frame);

/**
 * Creates a \ref FrameConfigurationInfo object that can be reused for each \ref
 * IFrame as long as parameters are not changed on the camera.
 *
 * The purpose is to cache the configuration to avoid asking the camera for the
 * interesting parameter settings each time a GenTL buffer is accessed via the
 * \ref IFrame interface.
 *
 * \lowlevel Prefer using \ref FrameGrabber instead.
 */
FrameConfigurationInfo
fromCameraConfiguration(std::shared_ptr<NodeMap> cameraNodeMap);

}}
