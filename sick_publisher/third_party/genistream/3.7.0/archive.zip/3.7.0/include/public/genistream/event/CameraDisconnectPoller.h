// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "genistream/GenIStreamDll.h"
#include "genistream/WaitResult.h"
#include "gentlcpp/BasicTypes.h"

#include <chrono>
#include <memory>

namespace genistream { namespace event {

class ICameraDisconnectDispatcher;

template<typename DispatcherType, typename EventDataType>
class EventPoller;

/**
 * This class allows polling for camera disconnection.
 *
 * \see \refcpp{ICamera::subscribeToDisconnectEvent()}
 *      \refcs{ICamera.Disconnected} for an API that provides notifications on a
 *      callback function.
 * \incubating
 */
class GENISTREAM_API CameraDisconnectPoller
{
public:
  /**
   * Creates an object to poll camera disconnect. Prefer using \ref
   * ICamera::createDisconnectPoller().
   *
   * From the point of creation, camera disconnect events are listened for.
   * Received disconnection is stored, i.e., you are guaranteed not to miss
   * disconnection when polling.
   */
  static std::shared_ptr<CameraDisconnectPoller>
  create(std::shared_ptr<ICameraDisconnectDispatcher> dispatcher);

  /** Destruction of the object will implicitly do \ref stopListening(). */
  ~CameraDisconnectPoller() = default;

  /**
   * Stops listening for camera disconnect events. If this is done while polling
   * from another thread, \ref poll(std::chrono::milliseconds) will return a
   * result which indicates that the operation has aborted.
   */
  void stopListening();

  /** \return true if listening for camera disconnect events */
  bool isListening() const;

  /**
   * Polls to see if the camera has been disconnected.
   *
   * \return a result \refcpp{WaitResult} \refcs{DeviceIdResult} object wrapping
   *         a \refcpp{gentlcpp::DeviceId} \refcs{string} representing the
   *         identity of the camera, if the camera has disconnected. Otherwise
   *         an object indicating timeout or aborted operation.
   */
  WaitResult<gentlcpp::DeviceId> poll(std::chrono::milliseconds timeout);

  /**
   * Polls to see if the camera has disconnected. This method will never time
   * out while waiting for disconnect.
   *
   * \return a result \refcpp{WaitResult} \refcs{DeviceIdResult} object wrapping
   *         a \refcpp{gentlcpp::DeviceId} \refcs{string} representing the
   *         identity of the camera, if the camera has disconnected. Otherwise
   *         an object indicating aborted operation.
   */
  WaitResult<gentlcpp::DeviceId> poll();

private:
  CameraDisconnectPoller(
    std::shared_ptr<ICameraDisconnectDispatcher> dispatcher);

private:
  std::unique_ptr<EventPoller<ICameraDisconnectDispatcher, gentlcpp::DeviceId>>
    mPoller;
};

}}
