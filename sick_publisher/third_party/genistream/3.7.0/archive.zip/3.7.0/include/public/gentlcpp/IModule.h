// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include "../genistream/GenIStreamDll.h"
#include <TLI/GenTL.h>
#include <memory>

namespace gentlcpp {

class IEvent;

/**
 * Interface for all modules.
 *
 * Used in event handling, all created Events need to be able to check if the
 * module they're registered to is still open when accessed.
 */
class GENISTREAM_API IModule
{
public:
  virtual ~IModule() noexcept = default;

  virtual std::shared_ptr<IEvent>
  registerEvent(GenTL::EVENT_TYPE_LIST eventType) = 0;
};

}
