// Copyright 2018-2023 SICK AG. All rights reserved.
#pragma once

#include "Avoid.h"
#include "GenIStreamDll.h"

#include <string>
#include <vector>

namespace genistream {

/**
 * A status of importing a configuration in CSV format or migrating a user set
 * to the current firmware version.
 *
 * The enum values are set explicitly and should not be changed, in order to
 * simplify customer support.
 */
enum class ConfigurationStatus
{
  /** Successful import or migration */
  OK = 0,

  /**
   * The imported or migrated configuration either was missing some parameters,
   * contained unknown parameters or both.
   */
  WARNING = 1000,

  /** Generic error. */
  ERROR_GENERIC = 2000,
  /** The format version of the configuration doesn't match the expected. */
  ERROR_VERSION_MISMATCH = 2001,
  /** The configuration is empty, and thus missing format version number. */
  ERROR_EMPTY_CONFIGURATION = 2002,
  /** One or more parameters are duplicated in the configuration. */
  ERROR_DUPLICATE_PARAMETER = 2003,
  /** The applied configuration is invalid. */
  ERROR_INVALID_CONFIGURATION = 2004,
};

/**
 * The complete result of importing a configuration in CSV format or migrating a
 * user set to the current firmware version.
 *
 * The result includes a \ref ConfigurationStatus as well as information on
 * which parameters are missing or unknown in the configuration.
 */
struct GENISTREAM_API ConfigurationResult
{
public:
  /** \internal */
  AVOID ConfigurationResult(ConfigurationStatus status, std::string message)
    : status(status)
    , message(std::move(message))
  {
  }

  /** \return true if the configuration is missing expected parameters */
  bool hasMissing() const { return !missingParameters.empty(); }
  /** \return true if the configuration contained missing parameters */
  bool hasUnknown() const { return !unknownParameters.empty(); }
  /** \return true if the configuration contained duplicate parameters */
  bool hasDuplicate() const { return !duplicateParameter.empty(); }

public:
  /** The status of the configuration operation. */
  ConfigurationStatus status;
  /**
   * A message explaining the reason if the status of the operations was not
   * \ref ConfigurationStatus::OK.
   */
  std::string message;

  /** Names of parameters missing in the configuration, if any. */
  std::vector<std::string> missingParameters;
  /** Names of unknown parameters in the configuration, if any. */
  std::vector<std::string> unknownParameters;
  /** Name of first duplicate parameter in the configuration, if any. */
  std::string duplicateParameter;
};

}
