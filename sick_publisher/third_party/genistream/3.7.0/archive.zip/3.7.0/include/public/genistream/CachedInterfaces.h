// Copyright 2019-2023 SICK AG. All rights reserved.
#pragma once

#include "Avoid.h"
#include "GenIStreamDll.h"
#include "ICachedInterfaces.h"

#include <gentlcpp/BasicTypes.h>

#include <chrono>
#include <map>
#include <memory>
#include <vector>

namespace gentlcpp {
class InterfaceInfo;
class Interface;
class ITransportLayer;
}

namespace genistream {

/**
 * Implementation of \ref ICachedInterfaces using GenTL.
 *
 * \lowlevel
 */
class GENISTREAM_API CachedInterfaces : public ICachedInterfaces
{
public:
  /**
   * You should normally not have to use this constructor. Instead use \ref
   * CameraDiscovery. If you want to write a camera discovery implementation
   * optimized for your use case it might still be relevant to use this class.
   *
   * \lowlevel
   */
  AVOID explicit CachedInterfaces(
    std::shared_ptr<gentlcpp::ITransportLayer> transportLayer);

  std::vector<std::shared_ptr<const gentlcpp::IInterfaceInfo>>
  getInterfaces(std::chrono::milliseconds timeout) override;

  std::shared_ptr<gentlcpp::IInterface>
  ensureOpen(const gentlcpp::InterfaceId& id) override;

  /**
   * \return the underlying \ref gentlcpp::TransportLayer
   * \lowlevel
   */
  AVOID std::shared_ptr<gentlcpp::ITransportLayer> getTransportLayer();

private:
  CachedInterfaces(const CachedInterfaces&) = delete;
  CachedInterfaces& operator=(const CachedInterfaces&) = delete;

private:
  std::shared_ptr<gentlcpp::ITransportLayer> mTransportLayer;

  /**
   * A cache of opened interfaces. Uses weak_ptr so that this cache prevents the
   * interfaces from closing when no longer used.
   */
  std::map<gentlcpp::InterfaceId, std::shared_ptr<gentlcpp::IInterface>>
    mOpenInterfaces;
};

}
