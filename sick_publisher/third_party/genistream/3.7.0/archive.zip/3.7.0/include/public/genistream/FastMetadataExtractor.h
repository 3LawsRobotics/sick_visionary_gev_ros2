// Copyright 2018-2023 SICK AG. All rights reserved.
#pragma once

#include "GenIStreamDll.h"
#include "LineMetadata.h"
#include "NodeMap.h"

namespace genistream {

class ChunkScanLineValueAccessor;

/**
 * Extracts metadata from chunk features given a NodeMap.
 *
 * This implementation does not use the GenApi standard way to iterate through
 * all the scan lines, by setting the ChunkScanLineSelector for every line.
 *
 * Instead this class will calculate the base address and offset for every
 * metadata feature, and assume that the offset is constant between every line.
 * This is fairly safe assumption for these features since they are selected by
 * a single selector.
 *
 * The registers will then be accessed directly via the ChunkPort, thereby
 * skipping the node map, selectors and swissknife calculations.
 *
 * \lowlevel Prefer accessing chunk metadata through \ref
 *           frame::IFrame::getLineMetadata.
 */
class GENISTREAM_API FastMetadataExtractor
{
public:
  /**
   * You should normally not have to use this constructor. Use \ref
   * frame::IFrame::getLineMetadata to access chunk metatadata.
   *
   * \throws ChunkFormatException if the chunk format is incorrect.
   * \lowlevel Prefer using \ref frame::IFrame::getLineMetadata.
   */
  AVOID FastMetadataExtractor(std::shared_ptr<NodeMap> cameraNodeMap);
  ~FastMetadataExtractor();

  std::vector<LineMetadata> extract() const;

private:
  GenApi::CIntegerPtr mChunkScanLineSelector;
  size_t mLineIncrement;
  std::unique_ptr<ChunkScanLineValueAccessor> mTimestamp;
  std::unique_ptr<ChunkScanLineValueAccessor> mEncoderValue;
  std::unique_ptr<ChunkScanLineValueAccessor> mOvertriggerCount;
  std::unique_ptr<ChunkScanLineValueAccessor> mFrameTriggerActive;
  std::unique_ptr<ChunkScanLineValueAccessor> mLineTriggerActive;
  std::unique_ptr<ChunkScanLineValueAccessor> mEncoderResetActive;
  std::unique_ptr<ChunkScanLineValueAccessor> mEncoderA;
  std::unique_ptr<ChunkScanLineValueAccessor> mEncoderB;
  GenApi::CChunkPortPtr mChunkPort;
};

}
