// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include "CushionWinHeaders.h"
#include "GenIStreamDll.h"
#include <Base/GCException.h>

#include <exception>
#include <string>

namespace genistream {

/**
 * Generic GenIStream exception class. Thrown whenever an error occurs in
 * GenIStream and in most cases where errors occur in the underlying GenApi and
 * GenTL. The messages from GenApi and GenTL exceptions are wrapped into
 * GenIStream exceptions as a causing messages.
 *
 * There may still exist unidentified cases where exceptions from GenTL or
 * GenApi leak from GenIStream. In C# these become `SystemException`.
 */
class GENISTREAM_API GenIStreamException : public std::exception
{
public:
  explicit GenIStreamException(std::string message);
  GenIStreamException(std::string message, const std::exception& cause);
  GenIStreamException(std::string message,
                      const GenICam::GenericException& cause);

  const char* what() const noexcept override;

  /**
   * \return true if this exception was caused by another exception that is
   *         carried as a part of this exception
   */
  bool wasCausedByOtherException() const;

  /**
   * \return the name of the exception type causing this exception, as returned
   *         from `std::type_info::name()`
   */
  const char* getCauseType() const;

  /**
   * \return the message from the exception causing this exception, as returned
   *         from `std::exception::what()`
   */
  const char* getCauseMessage() const;

private:
  std::string mMessage;

  // It is hard to copy and store a correct derived type or std::type_info so we
  // suffice with the name and message from std::exception::what()
  std::string mCauseType;
  std::string mCauseMessage;
};

// Convenience macro to declare derived exception types below
#define DECLARE_GENISTREAM_EXCEPTION(ExceptionName)                            \
  class ExceptionName : public GenIStreamException                             \
  {                                                                            \
  public:                                                                      \
    explicit ExceptionName(std::string message)                                \
      : GenIStreamException(std::move(message))                                \
    {                                                                          \
    }                                                                          \
                                                                               \
    ExceptionName(std::string message, const std::exception& cause)            \
      : GenIStreamException(std::move(message), cause)                         \
    {                                                                          \
    }                                                                          \
    ExceptionName(std::string message, const GenICam::GenericException& cause) \
      : GenIStreamException(std::move(message), cause)                         \
    {                                                                          \
    }                                                                          \
  }

/**
 * Exception thrown when calling a method on a camera that has been
 * disconnected. Also thrown when related objects need the camera to be
 * connected.
 */
DECLARE_GENISTREAM_EXCEPTION(DisconnectedException);

/** Exception indicating that the specified camera could not be found. */
DECLARE_GENISTREAM_EXCEPTION(CameraNotFoundException);

/** Exception indicating that it was not possible to connect to a camera. */
DECLARE_GENISTREAM_EXCEPTION(ConnectionFailedException);

/**
 * Indicates that something went wrong during export configuration from camera.
 */
DECLARE_GENISTREAM_EXCEPTION(ExportException);

/** Indicates that there is some problem when saving data to disk. */
DECLARE_GENISTREAM_EXCEPTION(SaveException);

/**
 * Error when accessing an Xml attribute.
 *
 * \deprecated Only used in legacy code to save iCon buffers.
 * \deprecatedsince 2.9
 */
DECLARE_GENISTREAM_EXCEPTION(XmlAttributeException);

/** Indicates that a resource or object is not available. */
DECLARE_GENISTREAM_EXCEPTION(NotAvailableException);

/** Indicates that an IP address is invalid. */
DECLARE_GENISTREAM_EXCEPTION(InvalidIpAddress);

/** Indicates that a MAC address is invalid. */
DECLARE_GENISTREAM_EXCEPTION(InvalidMacAddress);

/**
 * Indicates that there was some kind of problem with the chunk layout or that
 * the format was unexpected for a Ranger3/Ruler3000 camera.
 */
DECLARE_GENISTREAM_EXCEPTION(ChunkFormatException);

/**
 * Indicates that the configuration of the camera is invalid after a register
 * streaming session.
 */
DECLARE_GENISTREAM_EXCEPTION(InvalidConfiguration);

/** The pixel format given is not valid for the operation. */
DECLARE_GENISTREAM_EXCEPTION(InvalidPixelFormat);

/** The index given is out of range. */
DECLARE_GENISTREAM_EXCEPTION(OutOfRangeException);

/**
 * Indicates a problem when parsing the XML representation of a frame stored in
 * the iCon format.
 */
DECLARE_GENISTREAM_EXCEPTION(IconBufferException);

/**
 * Thrown when trying to do a file operation that is not allowed, like trying to
 * delete a non-deletable file.
 */
DECLARE_GENISTREAM_EXCEPTION(InvalidFileOperationException);

/**
 * Indicates that there is a problem accessing or operating on parameter. There
 * could for instance be a mismatch in parameter spelling, existence,
 * availability, type or writability.
 */
DECLARE_GENISTREAM_EXCEPTION(ParameterAccessException);

/**
 * Indicates that the set value was invalid. It was either rejected directly in
 * GenApi by range checks or rejected by the camera.
 */
DECLARE_GENISTREAM_EXCEPTION(ParameterValueException);

}
