// Copyright 2021-2023 SICK AG. All rights reserved.
#pragma once

#include "genistream/Avoid.h"
#include "genistream/GenIStreamDll.h"

#include <memory>
#include <string>

namespace genistream {
class IAnyParameters;

namespace frame {

/**
 * Enumeration to control which additional info is added to grabbed frames. The
 * additional info is written in the iCon XML file when saving frames with
 * \refcs{IFrame.Save(string,IFrame.SaveCalibratedMode)}
 * \refcpp{IFrame::save()}.
 *
 * By default all information is attached. Some of the information is subject to
 * time penalty which may be unacceptable in your use case. You can then choose
 * which info should be attached.
 *
 * \see \refcpp{ICamera::createFrameGrabber}
 *      \refcs{ICamera.CreateFrameGrabber(uint,AdditionalInfo)}
 */
enum class AdditionalInfo
{
  /**
   * Information with no or little time penalty which cannot be turned off,
   * e.g., acquisition start and grab times, device model and serial number,
   * information about the GenTL producer.
   */
  BASIC_INFO = 0,
  /**
   * Information about the device that needs to be fetched over the network,
   * e.g., firmware version and boot path. This typically has a penalty of ~1 ms
   * when creating the \ref FrameGrabber.
   */
  DEVICE_INFO_FROM_PARAMETERS = 1 << 0,
  /**
   * Information about GigE Vision that needs to be fetched over the network,
   * e.g., stream channel packet size. This typically has a penalty of ~1 ms
   * when creating the \ref FrameGrabber.
   */
  GEV_INFO_FROM_PARAMETERS = 1 << 1,
  /**
   * The complete camera configuration, i.e., the complete set of parameters,
   * same as produced by \ref ICamera::exportParameters(). This typically has
   * very large penalty of ~1 s when creating the \ref FrameGrabber.
   *
   * If you create \ref FrameGrabber%s over and over again or need to get your
   * frame very quickly after creating it, you might want to turn this off.
   */
  CAMERA_CONFIGURATION = 1 << 2,
  /**
   * Statistics from the GenTL data stream, similar to \ref
   * DataStreamStatistics. This typically has a penalty of <1 ms for each
   * grabbed frame in the \ref FrameGrabber.
   */
  DATA_STREAM_STATISTICS = 1 << 3,

  /**
   * Convenience value for all info that only has a time penalty when creating
   * the \ref FrameGrabber.
   */
  ALL_STATIC_INFO = BASIC_INFO | DEVICE_INFO_FROM_PARAMETERS
                    | GEV_INFO_FROM_PARAMETERS | CAMERA_CONFIGURATION,
  /**
   * Convenience value for all info that only has a time penalty when grabbing
   * with the \ref FrameGrabber.
   */
  ALL_DYNAMIC_INFO = BASIC_INFO | DATA_STREAM_STATISTICS,
  /** Convenience value for all info. This is the default. */
  ALL_INFO = ALL_STATIC_INFO | ALL_DYNAMIC_INFO,
  /**
   * Convenience value for all info except for the complete camera configuration
   * which has a huge time penalty when creating the \ref FrameGrabber.
   */
  ALL_INFO_EXCEPT_CAMERA_CONFIGURATION = ALL_INFO & ~CAMERA_CONFIGURATION,
};

/**
 * Operator to allow bitwise and of \ref AdditionalInfo to be able to check if a
 * particular info item is enabled or disabled.
 */
inline AdditionalInfo operator&(AdditionalInfo a, AdditionalInfo b)
{
  return static_cast<AdditionalInfo>(static_cast<int>(a) & static_cast<int>(b));
}

/**
 * Operator to allow bitwise or of \ref AdditionalInfo to be able to construct a
 * custom configuration with specific info items enabled.
 */
inline AdditionalInfo operator|(AdditionalInfo a, AdditionalInfo b)
{
  return static_cast<AdditionalInfo>(static_cast<int>(a) | static_cast<int>(b));
}

/**
 * Operator to allow bitwise not of \ref AdditionalInfo to be able to construct
 * a custom configuration with specific info items disabled.
 */
inline AdditionalInfo operator~(AdditionalInfo a)
{
  return static_cast<AdditionalInfo>(~static_cast<int>(a));
}


/**
 * Interface to get relevant XML formatted additional info which can be attached
 * to a frame with \ref Frame::additionalInfo().
 *
 * \lowlevel Prefer using \ref ICamera::createFrameGrabber().
 */
class IAdditionalInfoBuilder
{
public:
  virtual ~IAdditionalInfoBuilder() = default;

  /** Sets the acquisition start time to the current time. */
  AVOID virtual void setAcquisitionStartTime() = 0;
  /** Set the grab time to the current time. */
  AVOID virtual void setGrabTime() = 0;
  /** Sets the data stream statistics. */
  AVOID virtual void setDataStreamStatistics(
    std::shared_ptr<IAnyParameters> dataStreamParameters) = 0;

  /** \return a string with the complete information formatted as XML */
  AVOID virtual std::string getXml() const = 0;
};

}
}
