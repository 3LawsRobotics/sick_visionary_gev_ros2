// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include "../genistream/GenIStreamDll.h"
#include "gentlcpp/DataStream.h"
#include "gentlcpp/IBuffer.h"

#include <TLI/GenTL.h>

#include <cstdint>
#include <memory>
#include <string>

namespace gentlcpp {

class CApi;

#ifdef SWIG
class GENISTREAM_API Buffer : public IBuffer
#else
class GENISTREAM_API Buffer : public std::enable_shared_from_this<Buffer>, public IBuffer
#endif
{
public:
  Buffer(const Buffer&) = delete;
  ~Buffer() noexcept override;

  /** Clears all data from the allocated buffer. */
  void clear() override;

  GenTL::BUFFER_HANDLE getHandle() const override;

  BufferUserData getUserData() const override;
  GenTL::PAYLOADTYPE_INFO_IDS getPayloadType() const override;
  bool containsChunkData() const override;
  size_t getDeliveredChunkPayloadSize() const override;
  BufferPointerType getBase() override;
  size_t getSize() const override;
  size_t getSizeFilled() const override;
  size_t getDataSize() const override;
  uint64_t getFrameId() const override;
  uint64_t getTimeStamp() const override;
  size_t getWidth() const override;
  size_t getConfiguredHeight() const override;
  size_t getDeliveredHeight() const override;
  uint64_t getPixelFormat() const override;
  bool hasNewData() const override;
  bool isQueued() const override;
  bool isAcquiring() const override;
  bool isIncomplete() const override;
  std::string getTransportLayerType() const override;

  uint32_t getBufferPartCount() const override;
  std::shared_ptr<IBufferPart> getBufferPart(uint32_t partIndex) override;

  template<typename T>
  T getInfo(GenTL::BUFFER_INFO_CMD_LIST command) const
  {
    T value;
    size_t size = sizeof(T);
    GenTL::INFO_DATATYPE dataType;
    ThrowIfError(
      mCApi,
      mCApi->DSGetBufferInfo(
        mParent->getHandle(), mHandle, command, &dataType, &value, &size));
    return value;
  }

  template<typename T>
  T getInfo(uint32_t customCommand) const
  {
    return getInfo<T>(static_cast<GenTL::BUFFER_INFO_CMD_LIST>(customCommand));
  }

#ifdef SWIG
    EXPLODE_TEMPLATE_TYPES(getInfo);
#endif

private:
  friend class DataStream;
  friend class BufferPart;

  Buffer(std::shared_ptr<const CApi> cApi,
         std::shared_ptr<DataStream> dataStream,
         GenTL::BUFFER_HANDLE bufferHandle,
         BufferUserData userData);

private:
  std::shared_ptr<const CApi> mCApi;
  std::shared_ptr<DataStream> mParent;
  GenTL::BUFFER_HANDLE mHandle;
  BufferUserData mUserData;
};

/* (explicit specialization has to be declared in a scope where primary template can be defined) */
template<>
std::string Buffer::getInfo(GenTL::BUFFER_INFO_CMD_LIST command) const;

}
