// Copyright 2019-2023 SICK AG. All rights reserved.
#pragma once

#include "genistream/GenIStreamDll.h"
#include <cstdint>

namespace genistream { namespace frame {

/**
 * Represents an area of interest on the sensor, in pixel coordinates relative
 * to the top left corner.
 */
struct GENISTREAM_API Aoi
{
  Aoi()
    : Aoi(0, 0, 0, 0)
  {
  }

  Aoi(uint16_t offsetX, uint16_t offsetY, uint16_t width, uint16_t height)
    : offsetX(offsetX)
    , offsetY(offsetY)
    , width(width)
    , height(height)
  {
  }

  bool operator==(const Aoi& rhs) const
  {
    return offsetX == rhs.offsetX && offsetY == rhs.offsetY
           && width == rhs.width && height == rhs.height;
  }

  bool operator!=(const Aoi& rhs) const { return !operator==(rhs); }

  uint16_t offsetX;
  uint16_t offsetY;
  uint16_t width;
  uint16_t height;
};

}}
