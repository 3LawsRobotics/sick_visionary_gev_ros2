// Copyright 2019-2023 SICK AG. All rights reserved.
#pragma once

#include "Avoid.h"
#include "GenIStreamDll.h"
#include "ICamera.h"

namespace genistream {
class CameraTest;

namespace event {
class ICameraLogDispatcher;
class ICameraDisconnectDispatcher;
class NodeMapEventPusher;
class SubscriptionEnvelope;
}

/**
 * Implementation of the \ref ICamera interface, wrapping a \ref
 * gentlcpp::IDevice and a \ref gentlcpp::IDataStream (a single one is assumed
 * which is true for Ranger3 and Ruler3000 cameras).
 */
#ifdef SWIG
class GENISTREAM_API Camera : public ICamera
#else
class GENISTREAM_API Camera : public std::enable_shared_from_this<Camera>, public ICamera
#endif
{
public:
  /**
   * You should normally not have to use this constructor. Instead use \ref
   * CameraDiscovery to open a camera.
   *
   * \lowlevel
   */
  AVOID explicit Camera(std::shared_ptr<gentlcpp::IDevice> device);

  ~Camera() noexcept override;

  std::shared_ptr<FrameGrabber> createFrameGrabber(
    size_t buffersCount = 20,
    frame::AdditionalInfo infoToAdd = frame::AdditionalInfo::ALL_INFO) override;

  event::SubscriptionEnvelope subscribeToDisconnectEvent(
    event::DisconnectCallback onDisconnect) override;

  event::SubscriptionEnvelope subscribeToLogEvent(
    event::LogCallback onLogMessage) override;

  std::shared_ptr<event::CameraLogPoller> createLogPoller() override;

  std::shared_ptr<event::CameraDisconnectPoller> createDisconnectPoller()
    override;

  gentlcpp::DeviceId getId() const override;

  std::string getModel() const override;

  AVOID std::shared_ptr<gentlcpp::IDevice> getDevice() override;

  std::shared_ptr<CameraParameters> getCameraParameters() override;

  std::shared_ptr<IAnyParameters> getAnyParameters() override;

  std::shared_ptr<IAnyParameters> getLocalAnyParameters() override;

  AVOID std::shared_ptr<NodeMap> getNodeMap() override;

  AVOID std::shared_ptr<NodeMap> getLocalNodeMap() override;

  AVOID std::shared_ptr<gentlcpp::IDataStream> getDataStream() override;

  DataStreamStatistics getDataStreamStatistics() const override;

  void withRegisterStreaming(
    std::function<void(std::shared_ptr<CameraParameters>)> action) override;

  void withRegisterStreamingAny(
    std::function<void(std::shared_ptr<IAnyParameters>)> action) override;

  void setHeartbeatTimeout(std::chrono::microseconds microSeconds)
    const override;

  std::shared_ptr<IUserSet> openUserSet(UserSetId userSetId) override;

  void exportParameters(std::ostream & outputCsv) override;
  ConfigurationResult importParameters(std::istream & inputCsv) override;

  AVOID void sendFileContentToCamera(const std::string& cameraFileName,
                                     const std::string& contents) override;

  AVOID void sendFileToCamera(const std::string& cameraFileName,
                              const std::string& filePath) override;

  AVOID std::string retrieveFileContentFromCamera(
    const std::string& cameraFileName) override;

  AVOID void retrieveFileFromCamera(const std::string& cameraFileName,
                                    const std::string& destinationFilePath)
    override;

  AVOID void deleteFileFromCamera(const std::string& cameraFileName) override;

  std::vector<std::shared_ptr<CameraFile>> listFiles() override;

  std::shared_ptr<CameraFile> getFile(const std::string& cameraFileName)
    override;

  void updateFirmware(const std::string& firmwarePackagePath,
                      bool waitForCompletion = true) override;

  bool isInRescueMode() override;

  bool isConnected() const override;

  void disconnect() override;

private:
  /** Constructor used by test case. */
  Camera(
    std::shared_ptr<gentlcpp::IDevice> device,
    std::shared_ptr<NodeMapPortPair> localPair,
    std::shared_ptr<NodeMapPortPair> remotePair,
    std::shared_ptr<event::ICameraLogDispatcher> logDispatcher,
    std::shared_ptr<event::ICameraDisconnectDispatcher> disconnectDispatcher);

  void throwIfDisconnected() const;
  void addDefaultCallbacks();

  void createLogPusherAndDispatcher();
  void createDisconnectPusherAndDispatcher();
  void disconnectInternal();

private:
  std::shared_ptr<gentlcpp::IDevice> mDevice;
  gentlcpp::DeviceId mId;
  std::string mModel;
  std::shared_ptr<NodeMapPortPair> mLocalPair;
  std::shared_ptr<NodeMapPortPair> mRemotePair;
  std::shared_ptr<gentlcpp::IDataStream> mDataStream;
  std::shared_ptr<NodeMapPortPair> mDataStreamPair;
  bool mRegisterStreamingActive = false;

  // Keeping a single instance of CameraParameters since it now holds state when
  // able to subscribe to changes on parameters
  std::shared_ptr<CameraParameters> mCameraParameters;

  std::shared_ptr<event::ICameraLogDispatcher> mLogDispatcher;
  std::shared_ptr<event::ICameraDisconnectDispatcher> mDisconnectDispatcher;

  // Declared after dispatchers to ensure pushers are destroyed first
  std::shared_ptr<event::NodeMapEventPusher> mLogEventPusher;
  std::shared_ptr<event::NodeMapEventPusher> mDisconnectEventPusher;

  std::unique_ptr<event::ISubscription> mDefaultLogSubscription;
  std::unique_ptr<event::ISubscription> mIsConnectedStateSubscription;
  std::unique_ptr<event::ISubscription> mDefaultDisconnectSubscription;

  friend class CameraTest;

  // Allow implementation of interface functions marked as deprecated
#pragma warning(suppress : 4996)
};

}
