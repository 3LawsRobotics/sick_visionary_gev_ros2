// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "Exceptions.h"
#include "GenIStreamDll.h"

#include <functional>

namespace genistream {

/**
 * A generic result class to wrap data from an operation that may timeout or
 * abort.
 *
 * \tparam T the type of data in a completed result
 */
template<class T>
class GENISTREAM_API WaitResult
{
public:
  static WaitResult<T> completed(T data)
  {
    WaitResult<T> r(Status::COMPLETED);
    r.mData = std::move(data);
    return r;
  }

  static WaitResult<T> aborted()
  {
    WaitResult<T> r(Status::ABORTED);
    return r;
  }

  static WaitResult<T> timedOut()
  {
    WaitResult<T> r(Status::TIMED_OUT);
    return r;
  }

  /** \return true if the result from a completed operation */
  bool hasCompleted() const { return mStatus == Status::COMPLETED; }
  /** \return true if the result is from an aborted operation */
  bool hasAborted() const { return mStatus == Status::ABORTED; }
  /** \return true if the result is from an operation that timed out */
  bool hasTimedOut() const { return mStatus == Status::TIMED_OUT; }

  /** \return the result data if the result is not an error */
  T getOrThrow() const
  {
    switch (mStatus)
    {
    case Status::COMPLETED: return mData;
    case Status::ABORTED: throw GenIStreamException("Operation aborted");
    case Status::TIMED_OUT: throw GenIStreamException("Operation timed out");
    }
    // This should not be reached
    throw GenIStreamException("Unexpected error");
  }

  /** Executes an action if aborted. */
  const WaitResult<T>& ifAborted(std::function<void()> action) const
  {
    if (hasAborted())
    {
      action();
    }
    return *this;
  }

  /** Executes an action with completed result if available. */
  const WaitResult<T>& ifCompleted(std::function<void(T)> action) const
  {
    if (hasCompleted())
    {
      action(getOrThrow());
    }
    return *this;
  }

  /** Executes an action if timed out. */
  const WaitResult<T>& ifTimedOut(std::function<void()> action) const
  {
    if (hasTimedOut())
    {
      action();
    }
    return *this;
  }

  /**
   * If the status is completed, apply the provided mapping function to it.
   * Otherwise return the original status.
   *
   * \tparam MappedPayload the type to map original payload type T to
   */
  template<class MappedPayload>
  WaitResult<MappedPayload> map(std::function<MappedPayload(const T&)> fn) const
  {
    switch (mStatus)
    {
    case Status::ABORTED: return WaitResult<MappedPayload>::aborted();
    case Status::TIMED_OUT: return WaitResult<MappedPayload>::timedOut();
    default: return WaitResult<MappedPayload>::completed(fn(mData));
    }
  }

private:
  enum class Status
  {
    COMPLETED,
    ABORTED,
    TIMED_OUT
  };

private:
  WaitResult<T>(Status status)
    : mStatus(status)
  {
  }

private:
  Status mStatus;
  T mData;
};

}
