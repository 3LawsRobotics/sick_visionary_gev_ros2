// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include "../genistream/GenIStreamDll.h"
#include "gentlcpp/Buffer.h"
#include "gentlcpp/IBufferPart.h"

namespace gentlcpp {

class GENISTREAM_API BufferPart : public IBufferPart
{
public:
  BufferPart(const BufferPart&) = delete;
  ~BufferPart() noexcept override;

  uint32_t getIndex() const override;
  BufferPointerType getBase() override;
  ptrdiff_t getDataOffset() override;
  size_t getDataSize() override;
  GenTL::PARTDATATYPE_IDS getDataType() const override;
  uint64_t getDataFormat() const override;
  GenTL::PIXELFORMAT_NAMESPACE_IDS getDataFormatNamespace() const override;
  size_t getWidth() const override;
  size_t getConfiguredHeight() const override;
  size_t getXOffset() const override;
  size_t getYOffset() const override;
  size_t getXPadding() const override;
  uint64_t getSourceId() const override;
  size_t getDeliveredHeight() const override;
  uint64_t getInfo64(uint32_t customCommand) const override;

  template<typename T>
  T getInfo(GenTL::BUFFER_PART_INFO_CMD_LIST command) const
  {
    T value;
    size_t size = sizeof(T);
    GenTL::INFO_DATATYPE dataType;
    ThrowIfError(mCApi,
                 mCApi->DSGetBufferPartInfo(mParent->mParent->getHandle(),
                                            mParent->getHandle(),
                                            mPartIndex,
                                            command,
                                            &dataType,
                                            &value,
                                            &size));
    return value;
  }

  template<typename T>
  T getInfo(uint32_t customCommand) const
  {
    return getInfo<T>(
      static_cast<GenTL::BUFFER_PART_INFO_CMD_LIST>(customCommand));
  }

#ifdef SWIG
    EXPLODE_TEMPLATE_TYPES(getInfo);
#endif

private:
  friend class Buffer;

  BufferPart(std::shared_ptr<const CApi> cApi,
             std::shared_ptr<Buffer> buffer,
             uint32_t partIndex);

private:
  std::shared_ptr<const CApi> mCApi;
  std::shared_ptr<Buffer> mParent;
  uint32_t mPartIndex;
};


/* (explicit specialization has to be declared in a scope where primary template can be defined) */
template<>
std::string BufferPart::getInfo(GenTL::BUFFER_PART_INFO_CMD_LIST command) const;
}
