// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include "Avoid.h"
#include "GenIStreamDll.h"
#include "event/CameraLog.h"
#include "event/ISubscription.h"

#include "CushionWinHeaders.h"
#include <GenApi/NodeMapRef.h>

#include <fstream>

namespace genistream {
namespace event {
class ICameraLogDispatcher;
}
class ICamera;

/**
 * A class that writes camera log messages to file an possibly to stdout,
 * including the log message text, log level and timestamp.
 *
 * The log file has a limit to it, when this is reached it will be 'copied' by
 * being renamed with the added suffix '-backup'. It will then continue logging
 * to a new file with the original path.
 */
class GENISTREAM_API CameraLogWriter
{
public:
  /**
   * Constructs a log writer that can be used to explicitly push log messages to
   * the writer using \ref logToFile().
   *
   * \param path path where to store the log file, including name of the file
   * \param limit size limit of log file in bytes. Only when this has been
   *        exceeded will its contents be copied to a backup before being
   *        cleared.
   */
  static std::shared_ptr<CameraLogWriter> create(const std::string& path,
                                                 int64_t limit);

  /**
   * Constructs a log writer that subscribes to \ref event::CameraLogMessage%s
   * from a \ref Camera.
   *
   * \param dispatcher the dispatcher that will push log messages to the writer
   * \param path path where to store the log file, including name of the file
   * \param limit size limit of log file in bytes. Only when this has been
   *        exceeded will its contents be copied to a backup before being
   *        cleared.
   * \internal
   */
  AVOID static std::shared_ptr<CameraLogWriter>
  createFromDispatcher(std::shared_ptr<event::ICameraLogDispatcher> dispatcher,
                       const std::string& path,
                       int64_t limit);

  /**
   * Constructs a log writer that subscribes to \ref event::CameraLogMessage%s
   * from a \ref Camera.
   *
   * \param camera the camera that will push log messages to the writer
   * \param path path where to store the log file, including name of the file
   * \param limit size limit of log file in bytes. Only when this has been
   *        exceeded will its contents be copied to a backup before being
   *        cleared.
   */
  static std::shared_ptr<CameraLogWriter>
  createFromCamera(std::shared_ptr<ICamera> camera,
                   const std::string& path,
                   int64_t limit);

  /**
   * Constructs log writer that registers a callback to LogMessageEventID in
   * order to know when a new log message has been pushed into the cameraNodeMap
   * node map.
   *
   * A prerequisite for this to work is to attach the node map to a
   * GenApi::EventAdapterGEV. It will take a GenTL event buffer and extract its
   * contents into the node map.
   *
   * \param cameraNodeMap remote node map of the camera
   * \param path path where to store the log file, including name of the file
   * \param limit size limit of log file in bytes. Only when this has been
   *        exceeded will its contents be copied to a backup before being
   *        cleared.
   * \deprecated Prefer using createFromDispatcher instead.
   * \deprecatedsince 2.5
   */
  AVOID GENISTREAM_API static std::shared_ptr<CameraLogWriter>
  createFromNodeMap(GenApi::CNodeMapRef cameraNodeMap,
                    const std::string& path,
                    int64_t limit);

  GENISTREAM_API ~CameraLogWriter();

  /** Turn on/off logging to standard error (console). */
  void GENISTREAM_API enableConsoleLog(bool enable);

  /**
   * Pushes a log message to the writer. This can be used when explicitly
   * polling using \ref event::CameraLogPoller::poll().
   */
  void logToFile(const event::CameraLogMessage& message);

private:
  CameraLogWriter(const std::string& path, int64_t limit);
  void logNodeMapToFile(GenApi::INode*);
  bool isMaxFileSizeReached();
  void copyLogToBackup();

private:
  std::string mFilePath;
  std::string mBackupPath;
  int64_t mLimit;
  std::ofstream mLogStream;

  bool mConsoleLogging = false;

  // Note: These members are only used by the deprecated constructor used by
  // the java bindings Use of CNodeMapRef is considered okay, since it only
  // used internally in a thread safe way.
  GenApi::CNodeMapRef mCameraNodeMap;
  intptr_t mCallbackHandle = reinterpret_cast<intptr_t>(nullptr);

  std::unique_ptr<event::ISubscription> mSubscription;
};

}
