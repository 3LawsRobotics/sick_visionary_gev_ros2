// Copyright 2021-2023 SICK AG. All rights reserved.
#pragma once

#include "GenIStreamDll.h"
#include <cstdint>

namespace genistream {

/**
 * Container for metadata per frame in Ranger3/Ruler3000 family of cameras.
 *
 * See also \ref LineMetadata which contains metadata per scan line in frame.
 *
 * \note Currently only a subset of the available data is exposed here.
 * \incubating
 */
struct GENISTREAM_API FrameMetadata
{
  FrameMetadata() = default;
  FrameMetadata(uint32_t frameTriggerCounter)
    : frameTriggerCounter(frameTriggerCounter)
  {
  }

  bool operator==(const FrameMetadata& rhs) const
  {
    return frameTriggerCounter == rhs.frameTriggerCounter;
  }

  bool operator!=(const FrameMetadata& rhs) const { return !operator==(rhs); }

  /**
   * The number of rising edges that have arrived on the frame trigger I/O pin
   * at the point of triggering the first line in the frame.
   */
  uint32_t frameTriggerCounter = 0;
};

}
