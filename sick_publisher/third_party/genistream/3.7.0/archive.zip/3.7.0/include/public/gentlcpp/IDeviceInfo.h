// Copyright 2016-2023 SICK AG. All rights reserved.
#pragma once

#include "BasicTypes.h"

#include <TLI/GenTL.h>
#include "../genistream/GenIStreamDll.h"

#include <memory>
#include <string>

namespace gentlcpp {

class IInterface;

/**
 * Represents information about a device which can be retrieved without being
 * connected to it.
 *
 * \see \ref IInterface::getDevices() to get instances
 */
class GENISTREAM_API IDeviceInfo
{
public:
  virtual ~IDeviceInfo() noexcept = default;

  virtual DeviceId getId() const = 0;
  virtual std::string getVendor() const = 0;
  virtual std::string getModel() const = 0;
  virtual std::string getTransportLayerType() const = 0;
  virtual std::string getDisplayName() const = 0;
  virtual GenTL::DEVICE_ACCESS_STATUS_LIST getAccessStatus() const = 0;
  virtual std::string getUserDefinedName() const = 0;
  virtual std::string getSerialNumber() const = 0;
  virtual std::string getVersion() const = 0;

  virtual uint32_t getInfoUint32(uint32_t customCommand) = 0;
  virtual uint64_t getInfoUint64(uint32_t customCommand) = 0;

  virtual std::shared_ptr<IInterface> getParent() = 0;
};

}
