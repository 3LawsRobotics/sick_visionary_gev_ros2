// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "../GenIStreamDll.h"

namespace genistream { namespace event {

/**
 * This is an object to handle subscriptions in RAII fashion, i.e., if you
 * subscribe to some kind of events you will receive notifications until the
 * object is destroyed, or the object you subscribed on is destroyed.
 */
class GENISTREAM_API ISubscription
{
public:
  virtual ~ISubscription() = 0;
};

// The destructor is pure virtual to make this class abstract. Subclasses
// must override the destructor. However, the empty definition is needed in
// order to compile.
GENISTREAM_API inline ISubscription::~ISubscription() = default;

}}
