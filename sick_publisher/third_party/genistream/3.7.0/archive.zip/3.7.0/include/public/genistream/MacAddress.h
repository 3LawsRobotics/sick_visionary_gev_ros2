// Copyright 2019-2023 SICK AG. All rights reserved.
#pragma once

#include "GenIStreamDll.h"
#include <cstdint>
#include <string>

namespace genistream {

/** A representation of an Ethernet MAC address. */
class GENISTREAM_API MacAddress
{
public:
  /**
   * \param address the address as an integer in little endian.
   * \throws InvalidMacAddress if the value is too large
   */
  explicit MacAddress(uint64_t address);
  /**
   * \param address the address as colon separated string.
   * \throws InvalidMacAddress if the format is invalid
   */
  explicit MacAddress(const std::string& address);

  /** \return the MAC address as an integer on little endian */
  uint64_t value() const;

  /** \return the MAC address as colon separated string */
  std::string toString() const;

  bool operator==(const MacAddress& rhs) const
  {
    return mAddress == rhs.mAddress;
  }

private:
  uint64_t mAddress;
};

}
