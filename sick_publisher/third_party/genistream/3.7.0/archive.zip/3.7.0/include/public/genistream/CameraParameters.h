// Copyright 2023 SICK AG. All rights reserved.
// Automatically generated file.

#pragma once

#include "GenIStreamDll.h"
#include "Parameter.h"

#include <map>
#include <memory>

// Avoid definition from winnt.h
#undef DELETE

/**
 * \file
 *
 * This file contains automatically generated classes to access GenICam
 * features, i.e., parameters, on the camera. The parameters available on the
 * device depend on the version of the firmware and this file is generated for
 * the specific firmware version shipped together with GenIStream.
 */

namespace genistream {

class IAnyParameters;

/** Scan type of the sensor of the device. */
enum class DeviceScanType {
  AREASCAN = 0,
  LINESCAN_3D = 1,
};

/** Converts from DeviceScanType enumeration to GenApi parameter name. */
std::string genApiNameFromDeviceScanType(DeviceScanType value);

/** Alias for function genApiNameFromDeviceScanType(DeviceScanType). */
inline std::string toString(DeviceScanType value) { return genApiNameFromDeviceScanType(value); }

/** Converts from GenApi parameter name to DeviceScanType enumeration. */
DeviceScanType deviceScanTypeFromGenApiName(std::string name);

/**
 * Format of the pixels provided by the device. It represents all the
 * information provided by PixelSize, PixelColorFilter combined in a single
 * feature.
 */
enum class PixelFormat {
  MONO_4P = 17039417,
  MONO_8 = 17301505,
  MONO_10P = 17432646,
  MONO_12P = 17563719,
  MONO_16 = 17825799,
  RGB8 = 35127316,
  BGR8 = 35127317,
  COORD_3D_C8 = 17301681,
  COORD_3D_A8 = 17301679,
  COORD_3D_A12P = 17563864,
  COORD_3D_A16 = 17825974,
  COORD_3D_A10P = 17432789,
  COORD_3D_C10P = 17432791,
  COORD_3D_C12P = 17563866,
  COORD_3D_C16 = 17825976,
  COORD_3D_C32F = 18874559,
  COORD_3D_A64F = 20971814,
  COORD_3D_C64F = 20971816,
  COORD_3D_AC64F_PLANAR = 41943340,
  COORD_3D_AC8_PLANAR = 34603189,
  COORD_3D_AC10P_PLANAR = 34865393,
  COORD_3D_AC12P_PLANAR = 35127539,
  COORD_3D_AC16_PLANAR = 35651772,
};

/** Converts from PixelFormat enumeration to GenApi parameter name. */
std::string genApiNameFromPixelFormat(PixelFormat value);

/** Alias for function genApiNameFromPixelFormat(PixelFormat). */
inline std::string toString(PixelFormat value) { return genApiNameFromPixelFormat(value); }

/** Converts from GenApi parameter name to PixelFormat enumeration. */
PixelFormat pixelFormatFromGenApiName(std::string name);

/**
 * Selects which test pattern generator is controlled by the TestPattern
 * feature.
 */
enum class TestPattern {
  OFF = 0,
  GREY_HORIZONTAL_RAMP_MOVING = 1,
};

/** Converts from TestPattern enumeration to GenApi parameter name. */
std::string genApiNameFromTestPattern(TestPattern value);

/** Alias for function genApiNameFromTestPattern(TestPattern). */
inline std::string toString(TestPattern value) { return genApiNameFromTestPattern(value); }

/** Converts from GenApi parameter name to TestPattern enumeration. */
TestPattern testPatternFromGenApiName(std::string name);

/** Selects the sensor's data source region for 3D Extraction module. */
enum class Scan3dExtractionSource {
  REGION_1 = 1,
  REGION_1_DUAL_EXPOSURE = 6,
  REGION_2 = 2,
  REGION_3 = 3,
  REGION_4 = 4,
  REGION_5 = 5,
};

/**
 * Converts from Scan3dExtractionSource enumeration to GenApi parameter name.
 */
std::string genApiNameFromScan3dExtractionSource(Scan3dExtractionSource value);

/**
 * Alias for function
 * genApiNameFromScan3dExtractionSource(Scan3dExtractionSource).
 */
inline std::string toString(Scan3dExtractionSource value) { return genApiNameFromScan3dExtractionSource(value); }

/**
 * Converts from GenApi parameter name to Scan3dExtractionSource enumeration.
 */
Scan3dExtractionSource scan3dExtractionSourceFromGenApiName(std::string name);

/**
 * Selects the method for extracting 3D from the input sensor data. Hi3D is the
 * standard 3D algorithm with High subpixel resolution.
 */
enum class Scan3dExtractionMethod {
  HI_3D = 0,
  CENTER_OF_GRAVITY = 1,
  TRIPLE_LINE_GRAB = 2,
  OFFSET_SCATTER = 3,
  HORIZONTAL_THRESHOLD = 4,
  GRAY_SCATTER_LINE = 5,
};

/**
 * Converts from Scan3dExtractionMethod enumeration to GenApi parameter name.
 */
std::string genApiNameFromScan3dExtractionMethod(Scan3dExtractionMethod value);

/**
 * Alias for function
 * genApiNameFromScan3dExtractionMethod(Scan3dExtractionMethod).
 */
inline std::string toString(Scan3dExtractionMethod value) { return genApiNameFromScan3dExtractionMethod(value); }

/**
 * Converts from GenApi parameter name to Scan3dExtractionMethod enumeration.
 */
Scan3dExtractionMethod scan3dExtractionMethodFromGenApiName(std::string name);

/**
 * Size of Window Around Maximum for High-resolution Peak Fitting. Adapt to
 * laser peak width on sensor. Small: Size 7 pixels, peak width 2-4 pixels,
 * Normal: Size 15 pixels, peak width 3-8 pixels, Large: Size 31 pixels, peak
 * width 7-15 pixels.
 */
enum class WamSize {
  SMALL = 7,
  NORMAL = 15,
  LARGE = 31,
};

/** Converts from WamSize enumeration to GenApi parameter name. */
std::string genApiNameFromWamSize(WamSize value);

/** Alias for function genApiNameFromWamSize(WamSize). */
inline std::string toString(WamSize value) { return genApiNameFromWamSize(value); }

/** Converts from GenApi parameter name to WamSize enumeration. */
WamSize wamSizeFromGenApiName(std::string name);

/**
 * GlobalMax finds the global maximum. FirstLocalMax finds the first peak above
 * DetectionThreshold. That is, the search ends when the signal goes under
 * DetectionThreshold the first time after finding a local maxima above
 * DetectionThreshold. Use SearchDirection to define if first is from low to
 * high or high to low rows.
 */
enum class SearchMode3d {
  GLOBAL_MAX = 0,
  FIRST_LOCAL_MAX = 1,
  NO_MAX = 3,
};

/** Converts from SearchMode3d enumeration to GenApi parameter name. */
std::string genApiNameFromSearchMode3d(SearchMode3d value);

/** Alias for function genApiNameFromSearchMode3d(SearchMode3d). */
inline std::string toString(SearchMode3d value) { return genApiNameFromSearchMode3d(value); }

/** Converts from GenApi parameter name to SearchMode3d enumeration. */
SearchMode3d searchMode3dFromGenApiName(std::string name);

/**
 * Use this parameter to flip the coordinate axis of the range values, depending
 * on how the camera is mounted in relation to the laser line.
 */
enum class RangeAxis {
  STANDARD = 0,
  REVERSE = 1,
};

/** Converts from RangeAxis enumeration to GenApi parameter name. */
std::string genApiNameFromRangeAxis(RangeAxis value);

/** Alias for function genApiNameFromRangeAxis(RangeAxis). */
inline std::string toString(RangeAxis value) { return genApiNameFromRangeAxis(value); }

/** Converts from GenApi parameter name to RangeAxis enumeration. */
RangeAxis rangeAxisFromGenApiName(std::string name);

/**
 * The resolution of uncalibrated range data. RoiOptimal means that the highest
 * possible resolution is used for the given ROI height - the range data is
 * scaled to span the entire value range afforded by the current pixel format
 * bit width before rounding. Regardless of mode, only range steps of at least
 * one sixteenth pixel can be detected.
 */
enum class RangeResolution {
  ONE_PIXEL = 0,
  QUARTER_PIXEL = 2,
  SIXTEENTH_PIXEL = 4,
  ROI_OPTIMAL = 128,
};

/** Converts from RangeResolution enumeration to GenApi parameter name. */
std::string genApiNameFromRangeResolution(RangeResolution value);

/** Alias for function genApiNameFromRangeResolution(RangeResolution). */
inline std::string toString(RangeResolution value) { return genApiNameFromRangeResolution(value); }

/** Converts from GenApi parameter name to RangeResolution enumeration. */
RangeResolution rangeResolutionFromGenApiName(std::string name);

/**
 * In FirstLocalMax this defines "first" or "last" peak in Region. Standard
 * means increasing rows on the sensor.
 */
enum class SearchDirection {
  STANDARD = 0,
  REVERSE = 1,
};

/** Converts from SearchDirection enumeration to GenApi parameter name. */
std::string genApiNameFromSearchDirection(SearchDirection value);

/** Alias for function genApiNameFromSearchDirection(SearchDirection). */
inline std::string toString(SearchDirection value) { return genApiNameFromSearchDirection(value); }

/** Converts from GenApi parameter name to SearchDirection enumeration. */
SearchDirection searchDirectionFromGenApiName(std::string name);

/**
 * Mode for laser scatter, both sides, front (lower rows), back (higher rows)
 */
enum class ScatterMode {
  SYMMETRIC_SIDE_BAND = 1,
  FRONT_SIDE_BAND = 2,
  BACK_SIDE_BAND = 3,
};

/** Converts from ScatterMode enumeration to GenApi parameter name. */
std::string genApiNameFromScatterMode(ScatterMode value);

/** Alias for function genApiNameFromScatterMode(ScatterMode). */
inline std::string toString(ScatterMode value) { return genApiNameFromScatterMode(value); }

/** Converts from GenApi parameter name to ScatterMode enumeration. */
ScatterMode scatterModeFromGenApiName(std::string name);

/** Select mode for reducing scatter values from 16 to 8 bits. */
enum class ScatterReductionCurve {
  LINEAR = 0,
  ONE_KNEE = 1,
  TWO_KNEES = 2,
};

/** Converts from ScatterReductionCurve enumeration to GenApi parameter name. */
std::string genApiNameFromScatterReductionCurve(ScatterReductionCurve value);

/**
 * Alias for function
 * genApiNameFromScatterReductionCurve(ScatterReductionCurve).
 */
inline std::string toString(ScatterReductionCurve value) { return genApiNameFromScatterReductionCurve(value); }

/** Converts from GenApi parameter name to ScatterReductionCurve enumeration. */
ScatterReductionCurve scatterReductionCurveFromGenApiName(std::string name);

enum class Scan3dOutputMode {
  UNCALIBRATED_C = 0,
  CALIBRATED_AC = 2,
  CALIBRATED_AC_LINESCAN = 4,
  RECTIFIED_C = 5,
  RECTIFIED_C_LINESCAN = 6,
};

/** Converts from Scan3dOutputMode enumeration to GenApi parameter name. */
std::string genApiNameFromScan3dOutputMode(Scan3dOutputMode value);

/** Alias for function genApiNameFromScan3dOutputMode(Scan3dOutputMode). */
inline std::string toString(Scan3dOutputMode value) { return genApiNameFromScan3dOutputMode(value); }

/** Converts from GenApi parameter name to Scan3dOutputMode enumeration. */
Scan3dOutputMode scan3dOutputModeFromGenApiName(std::string name);

/**
 * The set of transformation parameters used for in-device calibration. For any
 * model, to achieve the desired coordinate system, Scan3dCoordinateScale and
 * Scan3dCoordinateOffset (or the Chunk counterparts) shall be applied. Identity
 * means that the data is identical to uncalibrated data. FactoryCalibration is
 * the device-specific model created when the device was manufactured. Only
 * available if a calibration model is stored in the device. UserCalibration
 * uses a calibration model uploaded by the user to the UserCalibration file.
 * LabSetup is intended only for SICK as a development and testing aid.
 * OverflowSetup is intended only for SICK as a development and testing aid.
 */
enum class Scan3dCalibrationModel {
  IDENTITY = 0,
  LAB_SETUP = 1,
  OVERFLOW_SETUP = 2,
  FACTORY_CALIBRATION = 3,
  USER_CALIBRATION = 4,
};

/**
 * Converts from Scan3dCalibrationModel enumeration to GenApi parameter name.
 */
std::string genApiNameFromScan3dCalibrationModel(Scan3dCalibrationModel value);

/**
 * Alias for function
 * genApiNameFromScan3dCalibrationModel(Scan3dCalibrationModel).
 */
inline std::string toString(Scan3dCalibrationModel value) { return genApiNameFromScan3dCalibrationModel(value); }

/**
 * Converts from GenApi parameter name to Scan3dCalibrationModel enumeration.
 */
Scan3dCalibrationModel scan3dCalibrationModelFromGenApiName(std::string name);

/**
 * Defines how the rectification output in a bin is created from (potentially)
 * multiple calibrated entries.
 */
enum class Scan3dRectificationMethod {
  TOP_MOST = 0,
  BOTTOM_MOST = 1,
};

/**
 * Converts from Scan3dRectificationMethod enumeration to GenApi parameter name.
 */
std::string genApiNameFromScan3dRectificationMethod(Scan3dRectificationMethod value);

/**
 * Alias for function
 * genApiNameFromScan3dRectificationMethod(Scan3dRectificationMethod).
 */
inline std::string toString(Scan3dRectificationMethod value) { return genApiNameFromScan3dRectificationMethod(value); }

/**
 * Converts from GenApi parameter name to Scan3dRectificationMethod enumeration.
 */
Scan3dRectificationMethod scan3dRectificationMethodFromGenApiName(std::string name);

/** Specifies the unit used when delivering distance data. */
enum class Scan3dDistanceUnit {
  MILLIMETER = 0,
  PIXEL = 1,
};

/** Converts from Scan3dDistanceUnit enumeration to GenApi parameter name. */
std::string genApiNameFromScan3dDistanceUnit(Scan3dDistanceUnit value);

/** Alias for function genApiNameFromScan3dDistanceUnit(Scan3dDistanceUnit). */
inline std::string toString(Scan3dDistanceUnit value) { return genApiNameFromScan3dDistanceUnit(value); }

/** Converts from GenApi parameter name to Scan3dDistanceUnit enumeration. */
Scan3dDistanceUnit scan3dDistanceUnitFromGenApiName(std::string name);

/**
 * Enables dual exposure in Region1. The additional exposure is configured in
 * Region1DualExposure. One of the regions should have a much longer
 * ExposureTime than the other.
 */
enum class Scan3dDualExposure {
  OFF = 0,
  BLEND = 1,
};

/** Converts from Scan3dDualExposure enumeration to GenApi parameter name. */
std::string genApiNameFromScan3dDualExposure(Scan3dDualExposure value);

/** Alias for function genApiNameFromScan3dDualExposure(Scan3dDualExposure). */
inline std::string toString(Scan3dDualExposure value) { return genApiNameFromScan3dDualExposure(value); }

/** Converts from GenApi parameter name to Scan3dDualExposure enumeration. */
Scan3dDualExposure scan3dDualExposureFromGenApiName(std::string name);

/**
 * Sets the acquisition mode of the device. It defines mainly the number of
 * frames to capture during an acquisition and the way the acquisition stops.
 */
enum class AcquisitionMode {
  SINGLE_FRAME = 0,
  CONTINUOUS = 1,
};

/** Converts from AcquisitionMode enumeration to GenApi parameter name. */
std::string genApiNameFromAcquisitionMode(AcquisitionMode value);

/** Alias for function genApiNameFromAcquisitionMode(AcquisitionMode). */
inline std::string toString(AcquisitionMode value) { return genApiNameFromAcquisitionMode(value); }

/** Converts from GenApi parameter name to AcquisitionMode enumeration. */
AcquisitionMode acquisitionModeFromGenApiName(std::string name);

/**
 * Controls how the AcquisitionStop command and the acquisition stopped using a
 * trigger (e.g. AcquisitionActive, FrameBurstActive, FrameActive or FrameEnd
 * trigger), ends an ongoing frame. * Complete: When stopped using the
 * AcquisitionStop command during a frame, the device stops acquisition of lines
 * but always reports the full Height in the trailer. This is suitable for
 * legacy receivers that expect only full height frames. When using frame
 * trigger input, the device will continue acquisition of lines until the
 * specified Height is reached to deliver a full height frame. * Immediate:
 * Acquisition stops immediately even during a frame and only the lines acquired
 * at the time are delivered.
 */
enum class AcquisitionStopMode {
  COMPLETE = 0,
  IMMEDIATE = 1,
};

/** Converts from AcquisitionStopMode enumeration to GenApi parameter name. */
std::string genApiNameFromAcquisitionStopMode(AcquisitionStopMode value);

/**
 * Alias for function genApiNameFromAcquisitionStopMode(AcquisitionStopMode).
 */
inline std::string toString(AcquisitionStopMode value) { return genApiNameFromAcquisitionStopMode(value); }

/** Converts from GenApi parameter name to AcquisitionStopMode enumeration. */
AcquisitionStopMode acquisitionStopModeFromGenApiName(std::string name);

/** Controls multi-slope exposure (HDR) state. */
enum class MultiSlopeMode {
  OFF = 0,
  PRESET_SOFT = 2,
  PRESET_MEDIUM = 3,
  PRESET_AGGRESSIVE = 4,
};

/** Converts from MultiSlopeMode enumeration to GenApi parameter name. */
std::string genApiNameFromMultiSlopeMode(MultiSlopeMode value);

/** Alias for function genApiNameFromMultiSlopeMode(MultiSlopeMode). */
inline std::string toString(MultiSlopeMode value) { return genApiNameFromMultiSlopeMode(value); }

/** Converts from GenApi parameter name to MultiSlopeMode enumeration. */
MultiSlopeMode multiSlopeModeFromGenApiName(std::string name);

/**
 * Controls if the selected trigger is active. Off means running on timer
 * controlled via Framerate/Linerate.
 */
enum class TriggerMode {
  OFF = 0,
  ON = 1,
};

/** Converts from TriggerMode enumeration to GenApi parameter name. */
std::string genApiNameFromTriggerMode(TriggerMode value);

/** Alias for function genApiNameFromTriggerMode(TriggerMode). */
inline std::string toString(TriggerMode value) { return genApiNameFromTriggerMode(value); }

/** Converts from GenApi parameter name to TriggerMode enumeration. */
TriggerMode triggerModeFromGenApiName(std::string name);

/**
 * Specifies the internal signal or physical input Line to use as the trigger
 * source. The selected trigger must have its TriggerMode set to On.
 */
enum class TriggerSource {
  ENCODER = 0,
  LINE_TRIGGER_INPUT = 1,
  FRAME_TRIGGER_INPUT = 2,
  LINE_START = 4,
};

/** Converts from TriggerSource enumeration to GenApi parameter name. */
std::string genApiNameFromTriggerSource(TriggerSource value);

/** Alias for function genApiNameFromTriggerSource(TriggerSource). */
inline std::string toString(TriggerSource value) { return genApiNameFromTriggerSource(value); }

/** Converts from GenApi parameter name to TriggerSource enumeration. */
TriggerSource triggerSourceFromGenApiName(std::string name);

/** Specifies the activation mode of the trigger. */
enum class TriggerActivation {
  RISING_EDGE = 0,
  LEVEL_HIGH = 3,
};

/** Converts from TriggerActivation enumeration to GenApi parameter name. */
std::string genApiNameFromTriggerActivation(TriggerActivation value);

/** Alias for function genApiNameFromTriggerActivation(TriggerActivation). */
inline std::string toString(TriggerActivation value) { return genApiNameFromTriggerActivation(value); }

/** Converts from GenApi parameter name to TriggerActivation enumeration. */
TriggerActivation triggerActivationFromGenApiName(std::string name);

/** Controls if the physical Line is used to Input or Output a signal. */
enum class LineMode {
  INPUT = 0,
  OUTPUT = 1,
};

/** Converts from LineMode enumeration to GenApi parameter name. */
std::string genApiNameFromLineMode(LineMode value);

/** Alias for function genApiNameFromLineMode(LineMode). */
inline std::string toString(LineMode value) { return genApiNameFromLineMode(value); }

/** Converts from GenApi parameter name to LineMode enumeration. */
LineMode lineModeFromGenApiName(std::string name);

/**
 * Selects which internal acquisition or I/O source signal to output on the
 * selected Line. LineMode must be Output.
 */
enum class LineSource {
  OFF = 0,
  ALWAYS_ACTIVE = 1,
  LASER_STROBE_1_TIMER = 2,
  LASER_STROBE_2_TIMER = 3,
  REGION_1_EXPOSURE = 4,
  FRAME_SYNCHRONIZATION_TIMER = 5,
  ALL_3D_EXPOSURES = 6,
};

/** Converts from LineSource enumeration to GenApi parameter name. */
std::string genApiNameFromLineSource(LineSource value);

/** Alias for function genApiNameFromLineSource(LineSource). */
inline std::string toString(LineSource value) { return genApiNameFromLineSource(value); }

/** Converts from GenApi parameter name to LineSource enumeration. */
LineSource lineSourceFromGenApiName(std::string name);

/**
 * Controls the current electrical format of the selected physical input or
 * output Line. For encoder Lines: RS422 corresponds to differential 5V (TTL)
 * logic mode. Line24V corresponds to single-ended 24V (HTL) logic mode.
 */
enum class LineFormat {
  RS422 = 0,
  TTL = 1,
  LINE_24V = 2,
};

/** Converts from LineFormat enumeration to GenApi parameter name. */
std::string genApiNameFromLineFormat(LineFormat value);

/** Alias for function genApiNameFromLineFormat(LineFormat). */
inline std::string toString(LineFormat value) { return genApiNameFromLineFormat(value); }

/** Converts from GenApi parameter name to LineFormat enumeration. */
LineFormat lineFormatFromGenApiName(std::string name);

/**
 * Configure the IO as input or output and select which source should drive the
 * outputs. (*) Input - The IO is input, disable signal source. (*)
 * OutputFrameSynchronization - The IO is output and the signal source is frame
 * synchronization. Developer-only configurations: (*) OutputHigh - The IO is
 * output and the signal source is a constant high. (*) OutputCpu - The IO is
 * output and the signal sources is GPIO pin from the CPU. (*) OutputPulse - The
 * IO is output and the signal source is pulse generator. (*) OutputIO1 - The IO
 * is output and the signal source is IO1 input. (*) OutputIO2 - The IO is
 * output and the signal source is IO2 input. (*) OutputIO3 - The IO is output
 * and the signal source is IO3 input. (*) OutputIO4 - The IO is output and the
 * signal source is IO4 input.
 */
enum class SignalConfiguration {
  INPUT = 0,
  OUTPUT_HIGH = 1,
  OUTPUT_CPU = 2,
  OUTPUT_PULSE = 3,
  OUTPUT_IO1 = 4,
  OUTPUT_IO2 = 5,
  OUTPUT_IO3 = 6,
  OUTPUT_IO4 = 7,
  OUTPUT_FRAME_SYNCHRONIZATION = 8,
};

/** Converts from SignalConfiguration enumeration to GenApi parameter name. */
std::string genApiNameFromSignalConfiguration(SignalConfiguration value);

/**
 * Alias for function genApiNameFromSignalConfiguration(SignalConfiguration).
 */
inline std::string toString(SignalConfiguration value) { return genApiNameFromSignalConfiguration(value); }

/** Converts from GenApi parameter name to SignalConfiguration enumeration. */
SignalConfiguration signalConfigurationFromGenApiName(std::string name);

/** Selects the source of the trigger to start the Timer. */
enum class TimerTriggerSource {
  OFF = 0,
  IMAGER_TRIGGER = 1,
  GPIO = 2,
  PULSE_GENERATOR = 3,
  FRAME_START = 4,
  FRAME_END = 5,
};

/** Converts from TimerTriggerSource enumeration to GenApi parameter name. */
std::string genApiNameFromTimerTriggerSource(TimerTriggerSource value);

/** Alias for function genApiNameFromTimerTriggerSource(TimerTriggerSource). */
inline std::string toString(TimerTriggerSource value) { return genApiNameFromTimerTriggerSource(value); }

/** Converts from GenApi parameter name to TimerTriggerSource enumeration. */
TimerTriggerSource timerTriggerSourceFromGenApiName(std::string name);

/**
 * FourPhase mode is the standard encoder mode where the EncoderValue increments
 * on each full four phase sequence which suppresses jitter. HighResolution
 * increments or decrements the EncoderValue every quadrature phase for high
 * resolution counting, but without jitter filtering. SingleChannel is a special
 * encoder mode where only the A channel is used.
 */
enum class EncoderMode {
  FOUR_PHASE = 0,
  HIGH_RESOLUTION = 1,
  SINGLE_CHANNEL = 2,
  UP_DOWN_PULSES = 3,
};

/** Converts from EncoderMode enumeration to GenApi parameter name. */
std::string genApiNameFromEncoderMode(EncoderMode value);

/** Alias for function genApiNameFromEncoderMode(EncoderMode). */
inline std::string toString(EncoderMode value) { return genApiNameFromEncoderMode(value); }

/** Converts from GenApi parameter name to EncoderMode enumeration. */
EncoderMode encoderModeFromGenApiName(std::string name);

/**
 * Selects the conditions for the Encoder interface to generate a valid Encoder
 * output signal.
 */
enum class EncoderOutputMode {
  POSITION_UP = 0,
  POSITION_DOWN = 1,
  DIRECTION_UP = 2,
  DIRECTION_DOWN = 3,
  MOTION = 4,
  OFF = 5,
};

/** Converts from EncoderOutputMode enumeration to GenApi parameter name. */
std::string genApiNameFromEncoderOutputMode(EncoderOutputMode value);

/** Alias for function genApiNameFromEncoderOutputMode(EncoderOutputMode). */
inline std::string toString(EncoderOutputMode value) { return genApiNameFromEncoderOutputMode(value); }

/** Converts from GenApi parameter name to EncoderOutputMode enumeration. */
EncoderOutputMode encoderOutputModeFromGenApiName(std::string name);

/** Selects the signals that will be the source to reset the Encoder. */
enum class EncoderResetSource {
  OFF = 0,
  ENCODER_RESET_INPUT = 1,
};

/** Converts from EncoderResetSource enumeration to GenApi parameter name. */
std::string genApiNameFromEncoderResetSource(EncoderResetSource value);

/** Alias for function genApiNameFromEncoderResetSource(EncoderResetSource). */
inline std::string toString(EncoderResetSource value) { return genApiNameFromEncoderResetSource(value); }

/** Converts from GenApi parameter name to EncoderResetSource enumeration. */
EncoderResetSource encoderResetSourceFromGenApiName(std::string name);

/** Selects the Activation mode of the Encoder Reset Source signal. */
enum class EncoderResetActivation {
  RISING_EDGE = 0,
};

/**
 * Converts from EncoderResetActivation enumeration to GenApi parameter name.
 */
std::string genApiNameFromEncoderResetActivation(EncoderResetActivation value);

/**
 * Alias for function
 * genApiNameFromEncoderResetActivation(EncoderResetActivation).
 */
inline std::string toString(EncoderResetActivation value) { return genApiNameFromEncoderResetActivation(value); }

/**
 * Converts from GenApi parameter name to EncoderResetActivation enumeration.
 */
EncoderResetActivation encoderResetActivationFromGenApiName(std::string name);

/**
 * Selects the location within the device, where the temperature will be
 * measured.
 */
enum class DeviceTemperatureId {
  SENSOR = 1,
  SENSOR_BOARD = 2,
  MAIN_BOARD = 3,
  ZPM_SOC = 4,
  ZPM_1 = 5,
  ZPM_2 = 6,
  ZPM_3 = 7,
  ZPM_4 = 8,
  FILTER = 9,
  LASER = 10,
};

/** Converts from DeviceTemperatureId enumeration to GenApi parameter name. */
std::string genApiNameFromDeviceTemperatureId(DeviceTemperatureId value);

/**
 * Alias for function genApiNameFromDeviceTemperatureId(DeviceTemperatureId).
 */
inline std::string toString(DeviceTemperatureId value) { return genApiNameFromDeviceTemperatureId(value); }

/** Converts from GenApi parameter name to DeviceTemperatureId enumeration. */
DeviceTemperatureId deviceTemperatureIdFromGenApiName(std::string name);

/**
 * Selects the Region of interest to control. The RegionSelector feature allows
 * devices that are able to extract multiple regions out of an image, to
 * configure the features of those individual regions independently.
 */
enum class RegionId {
  REGION_0 = 0,
  REGION_1 = 1,
  REGION_1_DUAL_EXPOSURE = 6,
  REGION_2 = 2,
  REGION_3 = 3,
  REGION_4 = 4,
  REGION_5 = 5,
  REGION_HIRES_GRAY = 7,
  REGION_HIRES_COLOR = 8,
  SCAN_3D_EXTRACTION_1 = 11,
  SCAN_3D_EXTRACTION_2 = 12,
  SCAN_3D_EXTRACTION_3 = 13,
  SCAN_3D_EXTRACTION_4 = 14,
  SCAN_3D_EXTRACTION_5 = 15,
  HIRES_EXTRACTION_GRAY = 17,
  HIRES_EXTRACTION_COLOR = 18,
};

/** Converts from RegionId enumeration to GenApi parameter name. */
std::string genApiNameFromRegionId(RegionId value);

/** Alias for function genApiNameFromRegionId(RegionId). */
inline std::string toString(RegionId value) { return genApiNameFromRegionId(value); }

/** Converts from GenApi parameter name to RegionId enumeration. */
RegionId regionIdFromGenApiName(std::string name);

/** Selects a component to activate data streaming from. */
enum class ComponentId {
  INTENSITY = 1,
  RANGE = 4,
  REFLECTANCE = 5,
  SCATTER = 7,
  MAC_0 = 65300,
  MAC_1 = 65301,
  MAC_2 = 65302,
  GAIN = 65303,
  PEAK_2 = 65304,
  // VISIONARY: IMU data pseudo image
  IMU_BASIC = 0xFF02
};

/** Converts from ComponentId enumeration to GenApi parameter name. */
std::string genApiNameFromComponentId(ComponentId value);

/** Alias for function genApiNameFromComponentId(ComponentId). */
inline std::string toString(ComponentId value) { return genApiNameFromComponentId(value); }

/** Converts from GenApi parameter name to ComponentId enumeration. */
ComponentId componentIdFromGenApiName(std::string name);

/**
 * Selects the 3DExtraction processing module to control (if multiple ones are
 * present).
 */
enum class Scan3dExtractionId {
  SCAN_3D_EXTRACTION_1 = 11,
  SCAN_3D_EXTRACTION_1_DUAL_EXPOSURE = 16,
  SCAN_3D_EXTRACTION_2 = 12,
  SCAN_3D_EXTRACTION_3 = 13,
  SCAN_3D_EXTRACTION_4 = 14,
  SCAN_3D_EXTRACTION_5 = 15,
};

/** Converts from Scan3dExtractionId enumeration to GenApi parameter name. */
std::string genApiNameFromScan3dExtractionId(Scan3dExtractionId value);

/** Alias for function genApiNameFromScan3dExtractionId(Scan3dExtractionId). */
inline std::string toString(Scan3dExtractionId value) { return genApiNameFromScan3dExtractionId(value); }

/** Converts from GenApi parameter name to Scan3dExtractionId enumeration. */
Scan3dExtractionId scan3dExtractionIdFromGenApiName(std::string name);

/**
 * Selects the individual coordinates in the vectors for 3D
 * information/transformation.
 */
enum class Scan3dCoordinateId {
  COORDINATE_A = 0,
  COORDINATE_B = 1,
  COORDINATE_C = 2,
};

/** Converts from Scan3dCoordinateId enumeration to GenApi parameter name. */
std::string genApiNameFromScan3dCoordinateId(Scan3dCoordinateId value);

/** Alias for function genApiNameFromScan3dCoordinateId(Scan3dCoordinateId). */
inline std::string toString(Scan3dCoordinateId value) { return genApiNameFromScan3dCoordinateId(value); }

/** Converts from GenApi parameter name to Scan3dCoordinateId enumeration. */
Scan3dCoordinateId scan3dCoordinateIdFromGenApiName(std::string name);

/**
 * Sets the index to read a coordinate system reference value defining the
 * transform of a point from the current (Anchor or Transformed) system to the
 * reference system.
 */
enum class Scan3dCoordinateReferenceId {
  ROTATION_X = 0,
  ROTATION_Y = 1,
  ROTATION_Z = 2,
  TRANSLATION_X = 3,
  TRANSLATION_Y = 4,
  TRANSLATION_Z = 5,
};

/**
 * Converts from Scan3dCoordinateReferenceId enumeration to GenApi parameter
 * name.
 */
std::string genApiNameFromScan3dCoordinateReferenceId(Scan3dCoordinateReferenceId value);

/**
 * Alias for function
 * genApiNameFromScan3dCoordinateReferenceId(Scan3dCoordinateReferenceId).
 */
inline std::string toString(Scan3dCoordinateReferenceId value) { return genApiNameFromScan3dCoordinateReferenceId(value); }

/**
 * Converts from GenApi parameter name to Scan3dCoordinateReferenceId
 * enumeration.
 */
Scan3dCoordinateReferenceId scan3dCoordinateReferenceIdFromGenApiName(std::string name);

/** Selects the type of trigger to configure. */
enum class TriggerId {
  LINE_START = 0,
  FRAME_START = 4,
  AREASCAN_FRAME_START = 7,
  REGION_1_EXPOSURE_START = 8,
  REGION_2_EXPOSURE_START = 9,
  REGION_3_EXPOSURE_START = 10,
  REGION_4_EXPOSURE_START = 11,
  REGION_5_EXPOSURE_START = 12,
};

/** Converts from TriggerId enumeration to GenApi parameter name. */
std::string genApiNameFromTriggerId(TriggerId value);

/** Alias for function genApiNameFromTriggerId(TriggerId). */
inline std::string toString(TriggerId value) { return genApiNameFromTriggerId(value); }

/** Converts from GenApi parameter name to TriggerId enumeration. */
TriggerId triggerIdFromGenApiName(std::string name);

/**
 * Selects the physical line (or pin) of the external device connector or the
 * virtual line of the Transport Layer to configure.
 */
enum class LineId {
  FRAME_TRIGGER_INPUT = 0,
  LINE_TRIGGER_INPUT = 1,
  ENCODER_RESET_INPUT = 2,
  ENCODER_A_INPUT = 3,
  ENCODER_B_INPUT = 4,
  LASER_STROBE_1_OUTPUT = 5,
  LASER_STROBE_2_OUTPUT = 6,
  FRAME_SYNCHRONIZATION_OUTPUT = 7,
};

/** Converts from LineId enumeration to GenApi parameter name. */
std::string genApiNameFromLineId(LineId value);

/** Alias for function genApiNameFromLineId(LineId). */
inline std::string toString(LineId value) { return genApiNameFromLineId(value); }

/** Converts from GenApi parameter name to LineId enumeration. */
LineId lineIdFromGenApiName(std::string name);

enum class IoPinId {
  IO1 = 1,
  IO2 = 2,
  IO3 = 3,
  IO4 = 4,
};

/** Converts from IoPinId enumeration to GenApi parameter name. */
std::string genApiNameFromIoPinId(IoPinId value);

/** Alias for function genApiNameFromIoPinId(IoPinId). */
inline std::string toString(IoPinId value) { return genApiNameFromIoPinId(value); }

/** Converts from GenApi parameter name to IoPinId enumeration. */
IoPinId ioPinIdFromGenApiName(std::string name);

/** Select the laser or frame synchronization output to configure. */
enum class TimerId {
  LASER_STROBE_1_TIMER = 0,
  LASER_STROBE_2_TIMER = 1,
  FRAME_SYNCHRONIZATION_TIMER = 2,
};

/** Converts from TimerId enumeration to GenApi parameter name. */
std::string genApiNameFromTimerId(TimerId value);

/** Alias for function genApiNameFromTimerId(TimerId). */
inline std::string toString(TimerId value) { return genApiNameFromTimerId(value); }

/** Converts from GenApi parameter name to TimerId enumeration. */
TimerId timerIdFromGenApiName(std::string name);

/**
 * Select the counter to read. (*) FrameTriggerCounter continuously counts how
 * many rising edges have arrived on the frame trigger I/O pin. The value is
 * frozen during acquisition of each frame.
 */
enum class CounterId {
  FRAME_TRIGGER_COUNTER = 0,
};

/** Converts from CounterId enumeration to GenApi parameter name. */
std::string genApiNameFromCounterId(CounterId value);

/** Alias for function genApiNameFromCounterId(CounterId). */
inline std::string toString(CounterId value) { return genApiNameFromCounterId(value); }

/** Converts from GenApi parameter name to CounterId enumeration. */
CounterId counterIdFromGenApiName(std::string name);


/**
 * Functionality to set and get parameter values from DeviceTemperature.
 *
 * Selects the location within the device, where the temperature will be
 * measured.
 */
class GENISTREAM_API DeviceTemperatureParameters
{
public:
  DeviceTemperatureParameters(std::shared_ptr<IAnyParameters> parameters, DeviceTemperatureId deviceTemperatureIndex);
  DeviceTemperatureParameters& operator=(const DeviceTemperatureParameters&) = delete;

  /**
   * Object to operate on camera parameter DeviceTemperature.
   *
   * Device temperature in degrees Celsius (C). It is measured at the location
   * selected by DeviceTemperatureSelector.
   */
  const FloatParameter deviceTemperature;

  /**
   * Object to operate on camera parameter DeviceTemperatureMin.
   *
   * The minimum temperature ever in degrees Celsius (C) measured at the
   * location selected by DeviceTemperatureSelector.
   */
  const IntParameter deviceTemperatureMin;

  /**
   * Object to operate on camera parameter DeviceTemperatureMax.
   *
   * The maximum temperature ever in degrees Celsius (C) measured at the
   * location selected by DeviceTemperatureSelector.
   */
  const IntParameter deviceTemperatureMax;

private:
  DeviceTemperatureId mDeviceTemperatureIndex;
};


/**
 * Functionality to set and get parameter values from Component.
 *
 * Selects a component to activate data streaming from.
 */
class GENISTREAM_API ComponentParameters
{
public:
  ComponentParameters(std::shared_ptr<IAnyParameters> parameters, RegionId regionIndex, ComponentId componentIndex);
  ComponentParameters& operator=(const ComponentParameters&) = delete;

  /**
   * Object to operate on camera parameter ComponentEnable.
   *
   * Controls if the selected component streaming is active.
   */
  BoolParameter componentEnable;

  /**
   * Object to operate on camera parameter PixelFormat.
   *
   * Format of the pixels provided by the device. It represents all the
   * information provided by PixelSize, PixelColorFilter combined in a single
   * feature.
   */
  EnumParameter<PixelFormat> pixelFormat;

  /**
   * Object to operate on camera parameter TestPattern.
   *
   * Selects which test pattern generator is controlled by the TestPattern
   * feature.
   */
  EnumParameter<TestPattern> testPattern;

private:
  RegionId mRegionIndex;
  ComponentId mComponentIndex;
};


/**
 * Functionality to set and get parameter values from Region.
 *
 * Selects the Region of interest to control. The RegionSelector feature allows
 * devices that are able to extract multiple regions out of an image, to
 * configure the features of those individual regions independently.
 */
class GENISTREAM_API RegionParameters
{
public:
  RegionParameters(std::shared_ptr<IAnyParameters> parameters, RegionId regionIndex);
  RegionParameters& operator=(const RegionParameters&) = delete;

  /**
   * Object to operate on camera parameter ExposureTime.
   *
   * Sets the exposure time in micro seconds. This controls the duration where
   * the photosensitive cells are exposed to light.
   */
  FloatParameter exposureTime;

  /**
   * Object to operate on camera parameter Width.
   *
   * Width of the image provided by the device (in pixels).
   */
  UintParameter width;

  /**
   * Object to operate on camera parameter Height.
   *
   * Height of the image provided by the device (in pixels).
   */
  UintParameter height;

  /**
   * Object to operate on camera parameter OffsetX.
   *
   * Horizontal offset from the origin to the region of interest (in pixels).
   */
  UintParameter offsetX;

  /**
   * Object to operate on camera parameter OffsetY.
   *
   * Vertical offset from the origin to the region of interest (in pixels).
   */
  UintParameter offsetY;

  /** \return an object to access parameters within a Component. */
  std::shared_ptr<ComponentParameters> component(ComponentId componentIndex);

private:
  std::map<ComponentId, std::shared_ptr<ComponentParameters>> mComponentParameters;
  RegionId mRegionIndex;
};


/**
 * Functionality to set and get parameter values from Scan3dCoordinate.
 *
 * Selects the individual coordinates in the vectors for 3D
 * information/transformation.
 */
class GENISTREAM_API Scan3dCoordinateParameters
{
public:
  Scan3dCoordinateParameters(std::shared_ptr<IAnyParameters> parameters, Scan3dExtractionId scan3dExtractionIndex, Scan3dCoordinateId scan3dCoordinateIndex);
  Scan3dCoordinateParameters& operator=(const Scan3dCoordinateParameters&) = delete;

  /**
   * Object to operate on camera parameter Scan3dCoordinateScale.
   *
   * Scale factor when transforming a value from transmitted relative
   * coordinates to sensor or world coordinates.
   */
  const FloatParameter scan3dCoordinateScale;

  /**
   * Object to operate on camera parameter Scan3dCoordinateOffset.
   *
   * Offset when transforming a value from transmitted relative coordinates to
   * sensor or world coordinates.
   */
  const FloatParameter scan3dCoordinateOffset;

  /**
   * Object to operate on camera parameter Scan3dInvalidDataFlag.
   *
   * Enables the definition of a non-valid flag value in the data stream.
   */
  const BoolParameter scan3dInvalidDataFlag;

  /**
   * Object to operate on camera parameter Scan3dInvalidDataValue.
   *
   * Value which identifies a non-valid pixel if Scan3dInvalidDataFlag is
   * enabled.
   */
  const FloatParameter scan3dInvalidDataValue;

  /**
   * Object to operate on camera parameter Scan3dAxisMin.
   *
   * Minimum valid transmitted coordinate value of the selected axis.
   */
  const FloatParameter scan3dAxisMin;

  /**
   * Object to operate on camera parameter Scan3dAxisMax.
   *
   * Maximum valid transmitted coordinate value of the selected axis.
   */
  const FloatParameter scan3dAxisMax;

private:
  Scan3dExtractionId mScan3dExtractionIndex;
  Scan3dCoordinateId mScan3dCoordinateIndex;
};


/**
 * Functionality to set and get parameter values from Scan3dCoordinateReference.
 *
 * Sets the index to read a coordinate system reference value defining the
 * transform of a point from the current (Anchor or Transformed) system to the
 * reference system.
 */
class GENISTREAM_API Scan3dCoordinateReferenceParameters
{
public:
  Scan3dCoordinateReferenceParameters(std::shared_ptr<IAnyParameters> parameters, Scan3dExtractionId scan3dExtractionIndex, Scan3dCoordinateReferenceId scan3dCoordinateReferenceIndex);
  Scan3dCoordinateReferenceParameters& operator=(const Scan3dCoordinateReferenceParameters&) = delete;

  /**
   * Object to operate on camera parameter Scan3dCoordinateReferenceValue.
   *
   * Returns the reference value selected.
   */
  const FloatParameter scan3dCoordinateReferenceValue;

private:
  Scan3dExtractionId mScan3dExtractionIndex;
  Scan3dCoordinateReferenceId mScan3dCoordinateReferenceIndex;
};


/**
 * Functionality to set and get parameter values from Scan3dExtraction.
 *
 * Selects the 3DExtraction processing module to control (if multiple ones are
 * present).
 */
class GENISTREAM_API Scan3dExtractionParameters
{
public:
  Scan3dExtractionParameters(std::shared_ptr<IAnyParameters> parameters, Scan3dExtractionId scan3dExtractionIndex);
  Scan3dExtractionParameters& operator=(const Scan3dExtractionParameters&) = delete;

  /**
   * Object to operate on camera parameter Scan3dExtractionSource.
   *
   * Selects the sensor's data source region for 3D Extraction module.
   */
  const EnumParameter<Scan3dExtractionSource> scan3dExtractionSource;

  /**
   * Object to operate on camera parameter Scan3dExtractionMethod.
   *
   * Selects the method for extracting 3D from the input sensor data. Hi3D is
   * the standard 3D algorithm with High subpixel resolution.
   */
  EnumParameter<Scan3dExtractionMethod> scan3dExtractionMethod;

  /**
   * Object to operate on camera parameter WamSize.
   *
   * Size of Window Around Maximum for High-resolution Peak Fitting. Adapt to
   * laser peak width on sensor. Small: Size 7 pixels, peak width 2-4 pixels,
   * Normal: Size 15 pixels, peak width 3-8 pixels, Large: Size 31 pixels,
   * peak width 7-15 pixels.
   */
  EnumParameter<WamSize> wamSize;

  /**
   * Object to operate on camera parameter SearchMode3D.
   *
   * GlobalMax finds the global maximum. FirstLocalMax finds the first peak
   * above DetectionThreshold. That is, the search ends when the signal goes
   * under DetectionThreshold the first time after finding a local maxima
   * above DetectionThreshold. Use SearchDirection to define if first is from
   * low to high or high to low rows.
   */
  EnumParameter<SearchMode3d> searchMode3d;

  /**
   * Object to operate on camera parameter RangeAxis.
   *
   * Use this parameter to flip the coordinate axis of the range values,
   * depending on how the camera is mounted in relation to the laser line.
   */
  EnumParameter<RangeAxis> rangeAxis;

  /**
   * Object to operate on camera parameter RangeResolution.
   *
   * The resolution of uncalibrated range data. RoiOptimal means that the
   * highest possible resolution is used for the given ROI height - the range
   * data is scaled to span the entire value range afforded by the current
   * pixel format bit width before rounding. Regardless of mode, only range
   * steps of at least one sixteenth pixel can be detected.
   */
  EnumParameter<RangeResolution> rangeResolution;

  /**
   * Object to operate on camera parameter PeakThreshold.
   *
   * Defines the threshold for locking the peak detection. In Hi3D Set to ~240
   * for default GlobalMax. In Horizontal Thresholding algorithm it defines
   * the threshold.
   */
  UintParameter peakThreshold;

  /**
   * Object to operate on camera parameter DetectionThreshold.
   *
   * Minimum reflectance signal that can be detected as a peak position.
   */
  UintParameter detectionThreshold;

  /**
   * Object to operate on camera parameter SearchDirection.
   *
   * In FirstLocalMax this defines "first" or "last" peak in Region. Standard
   * means increasing rows on the sensor.
   */
  EnumParameter<SearchDirection> searchDirection;

  /**
   * Object to operate on camera parameter ReflectanceFilter.
   *
   * Speckle reduction smoothing of reflectance data.
   */
  BoolParameter reflectanceFilter;

  /**
   * Object to operate on camera parameter ScatterMode.
   *
   * Mode for laser scatter, both sides, front (lower rows), back (higher
   * rows)
   */
  EnumParameter<ScatterMode> scatterMode;

  /**
   * Object to operate on camera parameter ScatterOffset.
   *
   * Distance in pixels from the center of the window to the start of the
   * scatter measurement. A distance of 0 includes the center pixel.
   */
  UintParameter scatterOffset;

  /**
   * Object to operate on camera parameter ScatterWidth.
   *
   * Number of pixels to add in scatter measurement side band
   */
  UintParameter scatterWidth;

  /**
   * Object to operate on camera parameter ScatterReductionCurve.
   *
   * Select mode for reducing scatter values from 16 to 8 bits.
   */
  EnumParameter<ScatterReductionCurve> scatterReductionCurve;

  /**
   * Object to operate on camera parameter ScatterReductionLowerLimit.
   *
   * Scatter values below this value will be clipped to zero.
   */
  UintParameter scatterReductionLowerLimit;

  /**
   * Object to operate on camera parameter ScatterReductionUpperLimit.
   *
   * Scatter values above this value will be clipped to 255.
   */
  UintParameter scatterReductionUpperLimit;

  /**
   * Object to operate on camera parameter ScatterReductionKnee1Input.
   *
   * Input coordinate of the first knee, expressed as a percentage of the
   * specified input range.
   */
  UintParameter scatterReductionKnee1Input;

  /**
   * Object to operate on camera parameter ScatterReductionKnee1Output.
   *
   * Output coordinate of the first knee, expressed as a percentage of the
   * output range.
   */
  UintParameter scatterReductionKnee1Output;

  /**
   * Object to operate on camera parameter ScatterReductionKnee2Input.
   *
   * Input coordinate of the second knee, expressed as a percentage of the
   * specified input range.
   */
  UintParameter scatterReductionKnee2Input;

  /**
   * Object to operate on camera parameter ScatterReductionKnee2Output.
   *
   * Output coordinate of the second knee, expressed as a percentage of the
   * output range.
   */
  UintParameter scatterReductionKnee2Output;

  /** Object to operate on camera parameter Scan3dOutputMode. */
  EnumParameter<Scan3dOutputMode> scan3dOutputMode;

  /**
   * Object to operate on camera parameter Scan3dCalibrationModel.
   *
   * The set of transformation parameters used for in-device calibration. For
   * any model, to achieve the desired coordinate system,
   * Scan3dCoordinateScale and Scan3dCoordinateOffset (or the Chunk
   * counterparts) shall be applied. Identity means that the data is identical
   * to uncalibrated data. FactoryCalibration is the device-specific model
   * created when the device was manufactured. Only available if a calibration
   * model is stored in the device. UserCalibration uses a calibration model
   * uploaded by the user to the UserCalibration file. LabSetup is intended
   * only for SICK as a development and testing aid. OverflowSetup is intended
   * only for SICK as a development and testing aid.
   */
  EnumParameter<Scan3dCalibrationModel> scan3dCalibrationModel;

  /**
   * Object to operate on camera parameter Scan3dRectificationWidth.
   *
   * Rectification can be made to a higher or lower resolution than the
   * resolution from the calibration step. A higher resolution avoids losing
   * detail in the region close to the camera, a lower resolution gives
   * smoothing filters.
   */
  UintParameter scan3dRectificationWidth;

  /**
   * Object to operate on camera parameter Scan3dRectificationMethod.
   *
   * Defines how the rectification output in a bin is created from
   * (potentially) multiple calibrated entries.
   */
  EnumParameter<Scan3dRectificationMethod> scan3dRectificationMethod;

  /**
   * Object to operate on camera parameter Scan3dRectificationSpread.
   *
   * To avoid missing data in rectified regions, each calibrated data point
   * can be spread to multiple adjacent rectification bins. This parameter
   * controls the spread width. A higher value includes more bins. Setting
   * this parameter to 0.0 disables spreading.
   */
  FloatParameter scan3dRectificationSpread;

  /**
   * Object to operate on camera parameter Scan3dDistanceUnit.
   *
   * Specifies the unit used when delivering distance data.
   */
  const EnumParameter<Scan3dDistanceUnit> scan3dDistanceUnit;

  /**
   * Object to operate on camera parameter Scan3dDualExposure.
   *
   * Enables dual exposure in Region1. The additional exposure is configured
   * in Region1DualExposure. One of the regions should have a much longer
   * ExposureTime than the other.
   */
  EnumParameter<Scan3dDualExposure> scan3dDualExposure;

  /**
   * Object to operate on camera parameter Scan3dBlendingThreshold.
   *
   * The reflectance threshold that decides which exposure to use data from.
   * Also controls the location of the knee-point in the reflectance blending.
   * If the long exposure reflectance is less than this threshold, data from
   * the long exposure is used. Otherwise data from the short exposure is used
   * and the short exposure reflectance is compressed into a value above the
   * threshold.
   */
  UintParameter scan3dBlendingThreshold;

  /** \return an object to access parameters within a Scan3dCoordinate. */
  std::shared_ptr<Scan3dCoordinateParameters> scan3dCoordinate(Scan3dCoordinateId scan3dCoordinateIndex);

  /**
   * \return an object to access parameters within a
   * Scan3dCoordinateReference.
   */
  std::shared_ptr<Scan3dCoordinateReferenceParameters> scan3dCoordinateReference(Scan3dCoordinateReferenceId scan3dCoordinateReferenceIndex);

private:
  std::map<Scan3dCoordinateId, std::shared_ptr<Scan3dCoordinateParameters>> mScan3dCoordinateParameters;
  std::map<Scan3dCoordinateReferenceId, std::shared_ptr<Scan3dCoordinateReferenceParameters>> mScan3dCoordinateReferenceParameters;
  Scan3dExtractionId mScan3dExtractionIndex;
};


/**
 * Functionality to set and get parameter values from Trigger.
 *
 * Selects the type of trigger to configure.
 */
class GENISTREAM_API TriggerParameters
{
public:
  TriggerParameters(std::shared_ptr<IAnyParameters> parameters, TriggerId triggerIndex);
  TriggerParameters& operator=(const TriggerParameters&) = delete;

  /**
   * Object to operate on camera parameter TriggerMode.
   *
   * Controls if the selected trigger is active. Off means running on timer
   * controlled via Framerate/Linerate.
   */
  EnumParameter<TriggerMode> triggerMode;

  /**
   * Object to operate on camera parameter TriggerSource.
   *
   * Specifies the internal signal or physical input Line to use as the
   * trigger source. The selected trigger must have its TriggerMode set to On.
   */
  EnumParameter<TriggerSource> triggerSource;

  /**
   * Object to operate on camera parameter TriggerActivation.
   *
   * Specifies the activation mode of the trigger.
   */
  EnumParameter<TriggerActivation> triggerActivation;

  /**
   * Object to operate on camera parameter TriggerDelay.
   *
   * Specifies the delay in microseconds (us) to apply after the trigger
   * reception before activating it. For RegionExposureStart triggers this
   * means a delay in addition to the delay required by the sensor schedule.
   * Note that the actual maximum value possible to set can be lower than the
   * seen TriggerDelay max. For Regions except Region1 the maximum is not
   * recalculated dynamically.
   */
  FloatParameter triggerDelay;

  /**
   * Object to operate on camera parameter TriggerEffectiveDelay.
   *
   * The total delay from line start to the region's exposure start. Affected
   * by TriggerDelay and the effective delay of regions earlier in the sensor
   * schedule. If a component is not active TriggerEffectiveDelay is -1. Note
   * that due to alignment to internal clocks there might be a small, sub
   * microsecond, TriggerEffectiveDelay even with TriggerDelay set to 0.
   */
  const FloatParameter triggerEffectiveDelay;

private:
  TriggerId mTriggerIndex;
};


/**
 * Functionality to set and get parameter values from Line.
 *
 * Selects the physical line (or pin) of the external device connector or the
 * virtual line of the Transport Layer to configure.
 */
class GENISTREAM_API LineParameters
{
public:
  LineParameters(std::shared_ptr<IAnyParameters> parameters, LineId lineIndex);
  LineParameters& operator=(const LineParameters&) = delete;

  /**
   * Object to operate on camera parameter LineMode.
   *
   * Controls if the physical Line is used to Input or Output a signal.
   */
  const EnumParameter<LineMode> lineMode;

  /**
   * Object to operate on camera parameter LineInverter.
   *
   * Controls the inversion of the selected input or output line. The line
   * signal is inverted if checked (i.e. set to true).
   */
  BoolParameter lineInverter;

  /**
   * Object to operate on camera parameter LineStatus.
   *
   * Returns the current status of the selected input or output Line.
   */
  const BoolParameter lineStatus;

  /**
   * Object to operate on camera parameter LineSource.
   *
   * Selects which internal acquisition or I/O source signal to output on the
   * selected Line. LineMode must be Output.
   */
  EnumParameter<LineSource> lineSource;

  /**
   * Object to operate on camera parameter LineFormat.
   *
   * Controls the current electrical format of the selected physical input or
   * output Line. For encoder Lines: RS422 corresponds to differential 5V
   * (TTL) logic mode. Line24V corresponds to single-ended 24V (HTL) logic
   * mode.
   */
  EnumParameter<LineFormat> lineFormat;

private:
  LineId mLineIndex;
};


/** Functionality to set and get parameter values from IOPin. */
class GENISTREAM_API IoPinParameters
{
public:
  IoPinParameters(std::shared_ptr<IAnyParameters> parameters, IoPinId ioPinIndex);
  IoPinParameters& operator=(const IoPinParameters&) = delete;

  /**
   * Object to operate on camera parameter SignalConfiguration.
   *
   * Configure the IO as input or output and select which source should drive
   * the outputs. (*) Input - The IO is input, disable signal source. (*)
   * OutputFrameSynchronization - The IO is output and the signal source is
   * frame synchronization. Developer-only configurations: (*) OutputHigh -
   * The IO is output and the signal source is a constant high. (*) OutputCpu
   * - The IO is output and the signal sources is GPIO pin from the CPU. (*)
   * OutputPulse - The IO is output and the signal source is pulse generator.
   * (*) OutputIO1 - The IO is output and the signal source is IO1 input. (*)
   * OutputIO2 - The IO is output and the signal source is IO2 input. (*)
   * OutputIO3 - The IO is output and the signal source is IO3 input. (*)
   * OutputIO4 - The IO is output and the signal source is IO4 input.
   */
  EnumParameter<SignalConfiguration> signalConfiguration;

private:
  IoPinId mIoPinIndex;
};


/**
 * Functionality to set and get parameter values from Timer.
 *
 * Select the laser or frame synchronization output to configure.
 */
class GENISTREAM_API TimerParameters
{
public:
  TimerParameters(std::shared_ptr<IAnyParameters> parameters, TimerId timerIndex);
  TimerParameters& operator=(const TimerParameters&) = delete;

  /**
   * Object to operate on camera parameter TimerDuration.
   *
   * Sets the duration (in microseconds) of the Timer pulse. The maximum value
   * depends on AcquisitionLineRate and for laser strobe also
   * AcquisitionFrameRate.
   */
  FloatParameter timerDuration;

  /**
   * Object to operate on camera parameter TimerDelay.
   *
   * Sets the duration (in microseconds) of the delay to apply at the
   * reception of an internal trigger before starting the Timer. The maximum
   * value depends on AcquisitionLineRate and AcquisitionFrameRate.
   */
  FloatParameter timerDelay;

  /**
   * Object to operate on camera parameter TimerTriggerSource.
   *
   * Selects the source of the trigger to start the Timer.
   */
  EnumParameter<TimerTriggerSource> timerTriggerSource;

private:
  TimerId mTimerIndex;
};


/**
 * Functionality to set and get parameter values from Counter.
 *
 * Select the counter to read. (*) FrameTriggerCounter continuously counts how
 * many rising edges have arrived on the frame trigger I/O pin. The value is
 * frozen during acquisition of each frame.
 */
class GENISTREAM_API CounterParameters
{
public:
  CounterParameters(std::shared_ptr<IAnyParameters> parameters, CounterId counterIndex);
  CounterParameters& operator=(const CounterParameters&) = delete;

  /**
   * Object to execute camera command CounterReset.
   *
   * Does a software reset of the selected Counter and starts it.
   */
  CommandParameter counterReset;

  /**
   * Object to operate on camera parameter CounterValue.
   *
   * Reads or writes the current value of the selected Counter.
   */
  const UintParameter counterValue;

private:
  CounterId mCounterIndex;
};


/**
 * Functionality to set and get parameter values from Root.
 *
 * \note This object depends on its parent \ref ICamera object, i.e., to use
 * this object you must ensure the \ref ICamera object is connected and not
 * destroyed.
 */
class GENISTREAM_API CameraParameters
{
public:
  CameraParameters(std::shared_ptr<IAnyParameters> parameters);
  CameraParameters& operator=(const CameraParameters&) = delete;

  /**
   * Object to operate on camera parameter DeviceScanType.
   *
   * Scan type of the sensor of the device.
   */
  EnumParameter<DeviceScanType> deviceScanType;

  /**
   * Object to operate on camera parameter DeviceVendorName.
   *
   * Name of the manufacturer of the device.
   */
  const StringParameter deviceVendorName;

  /**
   * Object to operate on camera parameter DeviceModelName.
   *
   * Model of the device.
   */
  const StringParameter deviceModelName;

  /**
   * Object to operate on camera parameter DeviceFirmwareVersion.
   *
   * Detailed information of the version of the currently running firmware in
   * the device.
   */
  const StringParameter deviceFirmwareVersion;

  /**
   * Object to operate on camera parameter DevicePrimaryFirmware.
   *
   * Version of the firmware in the primary boot path of the device.
   */
  const StringParameter devicePrimaryFirmware;

  /**
   * Object to operate on camera parameter DeviceSecondaryFirmware.
   *
   * Version of the firmware in the secondary boot path of the device.
   */
  const StringParameter deviceSecondaryFirmware;

  /**
   * Object to operate on camera parameter DeviceManufacturerInfo.
   *
   * Manufacturer information about the device.
   */
  const StringParameter deviceManufacturerInfo;

  /**
   * Object to operate on camera parameter DeviceSerialNumber.
   *
   * Device's serial number. This string is a unique identifier of the device.
   */
  const StringParameter deviceSerialNumber;

  /**
   * Object to operate on camera parameter DeviceUserID.
   *
   * User-programmable device identifier.
   */
  StringParameter deviceUserId;

  /**
   * Object to operate on camera parameter DeviceLinkThroughputCurrent.
   *
   * An approximation of the bandwidth required for the current configuration.
   * This only includes the actual image data, and does not include the
   * overhead of transmission. In externally triggered mode the value is an
   * upper bound on the bandwidth.
   */
  const UintParameter deviceLinkThroughputCurrent;

  /**
   * Object to operate on camera parameter DeviceLinkThroughputLimit.
   *
   * Limits the maximum bandwidth of the data that will be streamed out by the
   * device on the selected Link.
   */
  UintParameter deviceLinkThroughputLimit;

  /**
   * Object to operate on camera parameter DeviceLinkHeartbeatTimeout.
   *
   * Controls the current heartbeat timeout of the specific Link.
   */
  FloatParameter deviceLinkHeartbeatTimeout;

  /**
   * Object to execute camera command DeviceReset.
   *
   * Resets the device to its power up state. After reset, the device must be
   * rediscovered.
   */
  CommandParameter deviceReset;

  /**
   * Object to operate on camera parameter DeviceRegistersValid.
   *
   * True if the current register set is valid and consistent.
   */
  const BoolParameter deviceRegistersValid;

  /**
   * Object to operate on camera parameter DeviceCameraLaserAngle.
   *
   * Angle between laser plane and camera, for cameras with internal laser and
   * hence known optical geometries.
   */
  const FloatParameter deviceCameraLaserAngle;

  /**
   * Object to operate on camera parameter ReverseX.
   *
   * Flip horizontally the image sent by the device. The Region of interest is
   * applied after the flipping. Care should be taken when using calibrated
   * data; Changing this parameter will invalidate calibration results.
   */
  BoolParameter reverseX;

  /**
   * Object to operate on camera parameter ReverseY.
   *
   * Flip vertically the image sent by the device. The Region of interest is
   * applied after the flipping. Care should be taken when using calibrated
   * data; Changing this parameter will invalidate calibration results.
   */
  BoolParameter reverseY;

  /**
   * Object to operate on camera parameter AcquisitionMode.
   *
   * Sets the acquisition mode of the device. It defines mainly the number of
   * frames to capture during an acquisition and the way the acquisition
   * stops.
   */
  EnumParameter<AcquisitionMode> acquisitionMode;

  /**
   * Object to operate on camera parameter AcquisitionStopMode.
   *
   * Controls how the AcquisitionStop command and the acquisition stopped
   * using a trigger (e.g. AcquisitionActive, FrameBurstActive, FrameActive or
   * FrameEnd trigger), ends an ongoing frame. * Complete: When stopped using
   * the AcquisitionStop command during a frame, the device stops acquisition
   * of lines but always reports the full Height in the trailer. This is
   * suitable for legacy receivers that expect only full height frames. When
   * using frame trigger input, the device will continue acquisition of lines
   * until the specified Height is reached to deliver a full height frame. *
   * Immediate: Acquisition stops immediately even during a frame and only the
   * lines acquired at the time are delivered.
   */
  EnumParameter<AcquisitionStopMode> acquisitionStopMode;

  /**
   * Object to operate on camera parameter AcquisitionFrameRate.
   *
   * Controls the acquisition rate (in Hertz) at which the frames are
   * captured. Valid in Areascan mode and when not using external triggering.
   */
  FloatParameter acquisitionFrameRate;

  /**
   * Object to operate on camera parameter MaxFrameRate.
   *
   * The maximum rate at which frames can be captured in Areascan mode. Valid
   * in both free-running and triggered mode.
   */
  const FloatParameter maxFrameRate;

  /**
   * Object to operate on camera parameter AcquisitionLineRate.
   *
   * Controls the rate (in Hertz) at which the lines in a frame are captured.
   * Valid in Linescan3D mode and when not using external triggering.
   */
  FloatParameter acquisitionLineRate;

  /**
   * Object to operate on camera parameter MaxLineRate.
   *
   * The maximum rate at which lines can be captured in Linescan3D mode. Valid
   * in both free-running and triggered mode.
   */
  const FloatParameter maxLineRate;

  /**
   * Object to operate on camera parameter HoldFrameLevelOneLineAfterPulseEnd.
   *
   * Allow one additional line to be triggered even after the frame trigger
   * value level has gone low. This is useful for making sure that every set
   * of frames from a frame trigger pulse ends with a line with metadata that
   * shows the frame trigger going low.
   */
  BoolParameter holdFrameLevelOneLineAfterPulseEnd;

  /**
   * Object to operate on camera parameter MultiSlopeMode.
   *
   * Controls multi-slope exposure (HDR) state.
   */
  EnumParameter<MultiSlopeMode> multiSlopeMode;

  /**
   * Object to operate on camera parameter MultiSlopeKneePointCount.
   *
   * The number of knee-points as well as the number of additional exposure
   * slopes used for multi-slope exposure.
   */
  UintParameter multiSlopeKneePointCount;

  /**
   * Object to operate on camera parameter EncoderResolution.
   *
   * Defines the resolution of one encoder step.
   */
  FloatParameter encoderResolution;

  /**
   * Object to operate on camera parameter EncoderMode.
   *
   * FourPhase mode is the standard encoder mode where the EncoderValue
   * increments on each full four phase sequence which suppresses jitter.
   * HighResolution increments or decrements the EncoderValue every quadrature
   * phase for high resolution counting, but without jitter filtering.
   * SingleChannel is a special encoder mode where only the A channel is used.
   */
  EnumParameter<EncoderMode> encoderMode;

  /**
   * Object to operate on camera parameter EncoderDivider.
   *
   * Sets how many Encoder increment/decrements that are needed to generate a
   * trigger.
   */
  UintParameter encoderDivider;

  /**
   * Object to operate on camera parameter EncoderOutputMode.
   *
   * Selects the conditions for the Encoder interface to generate a valid
   * Encoder output signal.
   */
  EnumParameter<EncoderOutputMode> encoderOutputMode;

  /**
   * Object to operate on camera parameter EncoderResetSource.
   *
   * Selects the signals that will be the source to reset the Encoder.
   */
  EnumParameter<EncoderResetSource> encoderResetSource;

  /**
   * Object to operate on camera parameter EncoderResetActivation.
   *
   * Selects the Activation mode of the Encoder Reset Source signal.
   */
  const EnumParameter<EncoderResetActivation> encoderResetActivation;

  /**
   * Object to execute camera command EncoderReset.
   *
   * Resets the EncoderValue of the selected Encoder. The Encoder starts
   * counting events immediately after the reset. EncoderReset can be used to
   * reset the Encoder independently from the EncoderResetSource.
   */
  CommandParameter encoderReset;

  /**
   * Object to operate on camera parameter EncoderValue.
   *
   * Reads the current value of the position counter of the selected Encoder.
   */
  const IntParameter encoderValue;

  /**
   * Object to operate on camera parameter ChunkModeActive.
   *
   * Activates the inclusion of metadata in the payload of the image. Metadata
   * is only included when the DeviceScanType is Linescan3D.
   */
  BoolParameter chunkModeActive;

  /**
   * Object to operate on camera parameter PayloadSize.
   *
   * Provides the number of bytes transferred for each image or chunk on the
   * stream channel. This includes any end-of-line, end-of-frame statistics or
   * other stamp data. This is the total size of data payload for a data
   * block.
   */
  const UintParameter payloadSize;

  /**
   * Object to operate on camera parameter GevSCPSPacketSize.
   *
   * Specifies the stream packet size, in bytes, to send on the selected
   * channel for a GVSP transmitter. The value is typically negotiated between
   * the receiver (e.g. GenTL producer) and the device before starting
   * streaming. Note that re-negotiation of the value via e.g. the
   * DeviceStreamChannelControl features in a GenTL producer can change this
   * value, so ensure refreshing the value from the device before using it.
   */
  UintParameter gevScpsPacketSize;

  /**
   * Object to operate on camera parameter GevSCPD.
   *
   * Controls the delay (in GEV timestamp counter unit) to insert between each
   * packet for this stream channel. This can be used as a crude flow-control
   * mechanism if the application or the network infrastructure cannot keep up
   * with the packets coming from the device.
   */
  UintParameter gevScpd;

  /**
   * Object to operate on camera parameter MultiPartSupport.
   *
   * Manual Enable/Disable of multipart-configuration bit (25) in SCCFGx
   * register for testing.
   */
  BoolParameter multiPartSupport;

  /**
   * Object to operate on camera parameter GevMACAddress.
   *
   * MAC address of the logical link.
   */
  const Uint64Parameter gevMacAddress;

  /**
   * Object to operate on camera parameter
   * GevCurrentIPConfigurationPersistentIP.
   *
   * Controls whether the PersistentIP configuration scheme is activated on
   * the given logical link. The device falls back to DHCP (or secondarily
   * LLA, depending on GevCurrentIPConfigurationDHCP) in case the persistent
   * IP is already occupied.
   */
  BoolParameter gevCurrentIpConfigurationPersistentIp;

  /**
   * Object to operate on camera parameter GevCurrentIPConfigurationDHCP.
   *
   * Controls whether the DHCP IP configuration scheme is activated on the
   * given logical link. The device falls back to Link Local Address in case
   * no DHCP response is received after several timed out requests.
   */
  BoolParameter gevCurrentIpConfigurationDhcp;

  /**
   * Object to operate on camera parameter GevCurrentIPConfigurationLLA.
   *
   * Controls whether the Link Local Address IP configuration scheme is
   * activated on the given logical link. A Link Local IP address is always
   * within the 169.254.0.0/16 range.
   */
  const BoolParameter gevCurrentIpConfigurationLla;

  /**
   * Object to operate on camera parameter GevCurrentIPAddress.
   *
   * Reports the IP address for the given logical link.
   */
  const UintParameter gevCurrentIpAddress;

  /**
   * Object to operate on camera parameter GevCurrentSubnetMask.
   *
   * Reports the subnet mask of the given logical link.
   */
  const UintParameter gevCurrentSubnetMask;

  /**
   * Object to operate on camera parameter GevCurrentDefaultGateway.
   *
   * Reports the default gateway IP address to be used on the given logical
   * link.
   */
  const UintParameter gevCurrentDefaultGateway;

  /**
   * Object to operate on camera parameter GevPersistentIPAddress.
   *
   * Controls the persistent IP address for this logical link. It is only used
   * when the device boots with the Persistent IP configuration scheme.
   */
  UintParameter gevPersistentIpAddress;

  /**
   * Object to operate on camera parameter GevPersistentSubnetMask.
   *
   * Controls the persistent subnet mask associated with the Persistent IP
   * address on this logical link. It is only used when the device boots with
   * the Persistent IP configuration scheme.
   */
  UintParameter gevPersistentSubnetMask;

  /**
   * Object to operate on camera parameter GevPersistentDefaultGateway.
   *
   * Controls the persistent default gateway for this logical link. It is only
   * used when the device boots with the Persistent IP configuration scheme.
   */
  UintParameter gevPersistentDefaultGateway;

  /**
   * Object to execute camera command GevNetworkInterfaceReconfigure.
   *
   * Reconfigures the network interface according to the settings made. If the
   * settings have changed the connection will be lost to the device and it
   * may get a new IP address.
   */
  CommandParameter gevNetworkInterfaceReconfigure;

  /**
   * Object to operate on camera parameter LaserOnDelayTime.
   *
   * The estimated internal activation delay of the laser module. This delay
   * is propagated as the minimum of the Trigger Delay for ExposureStart. It
   * is added to the duration of the generated exposure-following pulse.
   */
  FloatParameter laserOnDelayTime;

  /**
   * Object to operate on camera parameter LaserPower.
   *
   * Set the laser power within the device laser power limits.
   */
  UintParameter laserPower;

  /**
   * Object to operate on camera parameter LaserCurrent.
   *
   * The electric current presently used by the laser.
   */
  const UintParameter laserCurrent;

  /** \return an object to access parameters within a DeviceTemperature. */
  std::shared_ptr<DeviceTemperatureParameters> deviceTemperature(DeviceTemperatureId deviceTemperatureIndex);

  /** \return an object to access parameters within a Region. */
  std::shared_ptr<RegionParameters> region(RegionId regionIndex);

  /** \return an object to access parameters within a Scan3dExtraction. */
  std::shared_ptr<Scan3dExtractionParameters> scan3dExtraction(Scan3dExtractionId scan3dExtractionIndex);

  /** \return an object to access parameters within a Trigger. */
  std::shared_ptr<TriggerParameters> trigger(TriggerId triggerIndex);

  /** \return an object to access parameters within a Line. */
  std::shared_ptr<LineParameters> line(LineId lineIndex);

  /** \return an object to access parameters within a IOPin. */
  std::shared_ptr<IoPinParameters> ioPin(IoPinId ioPinIndex);

  /** \return an object to access parameters within a Timer. */
  std::shared_ptr<TimerParameters> timer(TimerId timerIndex);

  /** \return an object to access parameters within a Counter. */
  std::shared_ptr<CounterParameters> counter(CounterId counterIndex);

private:
  std::map<DeviceTemperatureId, std::shared_ptr<DeviceTemperatureParameters>> mDeviceTemperatureParameters;
  std::map<RegionId, std::shared_ptr<RegionParameters>> mRegionParameters;
  std::map<Scan3dExtractionId, std::shared_ptr<Scan3dExtractionParameters>> mScan3dExtractionParameters;
  std::map<TriggerId, std::shared_ptr<TriggerParameters>> mTriggerParameters;
  std::map<LineId, std::shared_ptr<LineParameters>> mLineParameters;
  std::map<IoPinId, std::shared_ptr<IoPinParameters>> mIoPinParameters;
  std::map<TimerId, std::shared_ptr<TimerParameters>> mTimerParameters;
  std::map<CounterId, std::shared_ptr<CounterParameters>> mCounterParameters;
};

}
