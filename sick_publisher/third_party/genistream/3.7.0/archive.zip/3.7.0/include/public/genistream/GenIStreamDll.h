// Copyright 2017-2023 SICK AG. All rights reserved.
#pragma once

/**
 * \file
 *
 * This file contains preprocessor control that in the future will allow
 * building and using the GenIStream library as a dynamically linked library.
 * Currently only static linking is supported, thus you need to define
 * GENISTREAM_LINKAGE_STATIC when building your project.
 *
 * Old names to control the building are kept for backwards compatibility but
 * should be considered deprecated.
 */

// Translate defines for backwards compatibility
#ifdef GENIRANGER_LINKAGE_SHARED_EXPORT
#  define GENISTREAM_LINKAGE_SHARED_EXPORT 1
#  pragma message(                                                             \
    "You have defined GENIRANGER_LINKAGE_SHARED_EXPORT which has been replaced with GENISTREAM_LINKAGE_SHARED_EXPORT")
#elif defined(GENIRANGER_LINKAGE_STATIC)
#  define GENISTREAM_LINKAGE_STATIC 1
#  pragma message(                                                             \
    "You have defined GENIRANGER_LINKAGE_STATIC which has been replaced with GENISTREAM_LINKAGE_STATIC")
#endif

// Define GENISTREAM_API based on the linkage type
#if defined(GENISTREAM_LINKAGE_SHARED_EXPORT)
#  ifdef _WIN32
#    define GENISTREAM_API __declspec(dllexport)
#  else
#    define GENISTREAM_API __attribute__((visibility("default")))
#  endif
#elif defined(GENISTREAM_LINKAGE_STATIC)
#  define GENISTREAM_API
#else
#  ifdef _WIN32
#    define GENISTREAM_API __declspec(dllimport)
#  else
#    define GENISTREAM_API
#  endif
#endif
