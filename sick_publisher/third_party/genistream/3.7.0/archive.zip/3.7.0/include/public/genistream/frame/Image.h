// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include <cstdint>
#include <memory>

#include "../PixelFormat.h"
#include "CoordinateSystem.h"
#include "IComponent.h"
#include "genistream/GenIStreamDll.h"

namespace genistream { namespace frame {

/**
 * Simple class for holding image data. Can be created from a \ref IComponent,
 * either referring to the component's data or copying it.
 *
 * \note For referring images, this object depends on its parent \ref IFrame
 *       object and \ref FrameGrabber object, i.e., to use this object you must
 *       ensure these are not destroyed. Otherwise the underlying buffer may
 *       have been deallocated or re-used by GenTL for a new frame, i.e., the
 *       data may have been replaced.
 * \deprecated Prefer using \ref IComponent rather than \ref Image.
 * \deprecatedsince 3.4
 */
class GENISTREAM_API Image
{
public:
  // Earlier member type was moved to pixelformat namespace. Keeping alias for
  // backwards compatibility.
  using PixelDataType = pixelformat::PixelDataType;

  // Earlier member type was moved to IComponent. Keeping alias for backwards
  // compatibility.
  using Point = IComponent::Point;

  /**
   * The 3D coordinate system of an image.
   *
   * The defined coordinate systems are right-hand oriented Cartesian (X,Y,Z),
   * The image pixel values are rescaled by the X or Z axis.
   *
   * This coordinate system is aligned with the image, not the world. X is along
   * the width, Y along the height and Z in the value range of the pixels. So
   * depending on the image type Z might not be corresponding to a GenICam C
   * coordinate, and Y might not point in the direction of the scan.
   *
   * An example:
   *
   * If the image has coordinate type A, the pixel may be transformed as
   *
   * \code{.cpp}
   * // C++
   * double pixelValue =
   *   static_cast<double>(image.at<uint16_t>(u, v)) * x.scale + x.offset;
   * \endcode
   *
   * \code{.cs}
   * // C#
   * double pixelValue = image.At(u, v) * x.Scale + x.Offset;
   * \endcode
   *
   * \deprecated Prefer using \ref CoordinateSystem.
   * \deprecatedsince 3.4
   */
  struct CoordinateInfo
  {
    /** The x-axis, along the width of the image. */
    AxisTransform x;

    /** The y-axis, along the height of the image. */
    AxisTransform y;

    /**
     * The z-axis, along the values of the pixels. A complete \ref Axis rather
     * than \ref AxisTransform to hold representation of missing data.
     */
    Axis z;

    /** What the data represents. */
    Unit unit;

    /** Defines which data is in the image, A B and C are actual 3D data. */
    CoordinateType valueAxis;
  };

public:
  /**
   * Creates an image that does not own its data. User needs to make sure the
   * data stays valid.
   *
   * \param info what kind of data the image represents and the coordinates of
   *        that image
   * \param dataType the data type of the image pixels
   * \param width the number of columns in the image
   * \param height the number of rows in the image
   * \param data a pointer to the data which the image should contain. Must be
   *        the size of width * height * (byte size of dataType)
   * \deprecated Prefer using \ref IComponent rather than \ref Image.
   * \deprecatedsince 3.4
   */
  AVOID static std::shared_ptr<Image>
  createReferring(CoordinateInfo info,
                  pixelformat::PixelDataType dataType,
                  size_t width,
                  size_t height,
                  uint8_t* data);

  /**
   * Creates an image that copies the provided data.
   *
   * \param info what kind of data the image represents and the coordinates of
   *        that image
   * \param dataType the data type of the image pixels
   * \param width the number of columns in the image
   * \param height the number of rows in the image
   * \param data a pointer to the data which the image should contain. Must be
   *        the size of width * height * (byte size of dataType)
   * \deprecated Prefer using \ref IComponent rather than \ref Image.
   * \deprecatedsince 3.4
   */
  AVOID static std::shared_ptr<Image>
  createCopy(CoordinateInfo info,
             pixelformat::PixelDataType dataType,
             size_t width,
             size_t height,
             const uint8_t* data);

  /**
   * Creates an image which allocates its own data. The memory is uninitialized
   * by default.
   *
   * \param info what kind of data the image represents and the coordinates of
   *        that image
   * \param dataType the data type of the image pixels
   * \param width the number of columns in the image
   * \param height the number of rows in the image
   * \deprecated Prefer using \ref IComponent rather than \ref Image.
   * \deprecatedsince 3.4
   */
  AVOID static std::shared_ptr<Image>
  createBlank(CoordinateInfo info,
              pixelformat::PixelDataType dataType,
              size_t width,
              size_t height);

  ~Image();

  /**
   * \return the image coordinate system
   * \deprecated Prefer using \ref IComponent::getCoordinateSystem().
   * \deprecatedsince 3.4
   */
  AVOID const CoordinateInfo& getCoordinateInfo() const;

  /**
   * \return the data type used to represent pixels of the image
   * \deprecated Prefer using \ref genistream::pixelformat::channelDataType()
   *             together with IComponent::getPixelFormat().
   * \deprecatedsince 3.4
   */
  AVOID genistream::pixelformat::PixelDataType getPixelDataType() const;

  /**
   * \return the width of the image
   * \deprecated Prefer using \ref IComponent::getWidth().
   * \deprecatedsince 3.4
   */
  AVOID size_t getWidth() const;

  /**
   * \return the height of the image. For a 3D image this is the the number of
   *         lines scanned. This corresponds to \ref
   *         IComponent::getDeliveredHeight().
   * \deprecated Prefer using \ref IComponent::getDeliveredHeight().
   * \deprecatedsince 3.4
   */
  AVOID size_t getHeight() const;

  /**
   * \return A pointer to the image data. The pointer is always pointer to bytes
   *         but the data contained is of the type indicated by \ref
   *         getPixelDataType(). The user must cast the the data to a pointer of
   *         appropriate type.
   * \deprecated Prefer using \ref IComponent::getData().
   * \deprecatedsince 3.4
   */
  AVOID uint8_t* getData() const;

  /**
   * \return the amount of bytes in image
   * \deprecated Prefer using \ref IComponent::getDeliveredDataSize().
   * \deprecatedsince 3.4
   */
  AVOID size_t getDataSize() const;

  /**
   * \param missingDataValue the new value of any missing data after applying Z
   *        axis transform
   * \return a new image with the data transformed using the Z axis
   *         transformation of the coordinate system to the unit given by \ref
   *         getCoordinateInfo()
   * \deprecated Prefer using \ref IComponent::copyTransformed().
   * \deprecatedsince 3.4
   */
  AVOID std::shared_ptr<Image>
  transform(double missingDataValue =
              std::numeric_limits<double>::signaling_NaN()) const;

  /**
   * \return the number of bytes per image row
   * \deprecated Prefer using \ref IComponent::getStride().
   * \deprecatedsince 3.4
   */
  AVOID size_t getStride() const;

  /**
   * \return the bytes per pixel
   * \deprecated Prefer using \ref IComponent::getBitsPerPixel() divided by 8.
   * \deprecatedsince 3.4
   */
  AVOID uint8_t getPixelSize() const;

  /**
   * Provides direct access to image data.
   *
   * \tparam T data type matching the size of the pixel format
   * \param index the pixel index to read
   * \return the value for a single pixel
   * \throws OutOfRangeException if the index is out of range
   * \throws InvalidPixelFormat if template data type size does not match the
   *         size of the pixel format
   * \deprecated Prefer using \ref IComponent::at().
   * \deprecatedsince 3.4
   */
  template<typename T>
  AVOID const T& at(size_t index) const
  {
    throwIfWrongPixelSize(sizeof(T));
    throwIfOutOfBound(index);
    return *(reinterpret_cast<T*>(ALLOW_DEPRECATED(getData())) + index);
  }

  /**
   * Provides direct access to image data.
   *
   * \tparam T data type matching the size of the pixel format
   * \param index the pixel index to read
   * \return the value for a single pixel
   * \throws OutOfRangeException if the index is out of range
   * \throws InvalidPixelFormat if template data type size does not match the
   *         size of the pixel format
   * \deprecated Prefer using \ref IComponent::at().
   * \deprecatedsince 3.4
   */
  template<typename T>
  AVOID T& at(size_t index)
  {
    throwIfWrongPixelSize(sizeof(T));
    throwIfOutOfBound(index);
    return *(reinterpret_cast<T*>(ALLOW_DEPRECATED(getData())) + index);
  }

  /**
   * Provides direct access to image data.
   *
   * \tparam T data type matching the size of the pixel format
   * \param x column of the of the image
   * \param y row of the of the image
   * \return the value for a single pixel
   * \throws OutOfRangeException if any of the indices is out of range
   * \throws InvalidPixelFormat if template data type size does not match the
   *         size of the pixel format
   * \deprecated Prefer using \ref IComponent::at().
   * \deprecatedsince 3.4
   */
  template<typename T>
  AVOID const T& at(size_t x, size_t y) const
  {
    throwIfWrongPixelSize(sizeof(T));
    throwIfOutOfBounds(x, y);
    return *(reinterpret_cast<T*>(ALLOW_DEPRECATED(getData()))
             + y * ALLOW_DEPRECATED(getWidth()) + x);
  }

  /**
   * Provides direct access to image data.
   *
   * \tparam T data type matching the size of the pixel format
   * \param x column of the of the image
   * \param y row of the of the image
   * \return the value for a single pixel
   * \throws OutOfRangeException if any of the indices is out of range
   * \throws InvalidPixelFormat if template data type size does not match the
   *         size of the pixel format
   * \deprecated Prefer using \ref IComponent::at().
   * \deprecatedsince 3.4
   */
  template<typename T>
  AVOID T& at(size_t x, size_t y)
  {
    throwIfWrongPixelSize(sizeof(T));
    throwIfOutOfBounds(x, y);
    return *(reinterpret_cast<T*>(ALLOW_DEPRECATED(getData()))
             + y * ALLOW_DEPRECATED(getWidth()) + x);
  }


  /**
   * Gets the value of a pixel. It is not transformed with the coordinate
   * system.
   *
   * \param x column of the pixel in the image
   * \param y row of the pixel in the image
   * \return The value of the an image pixel as a double
   * \throws OutOfRangeException if any of the indices is out of range
   * \throws InvalidPixelFormat if template size does not match the size of the
   *         pixel format
   * \deprecated Prefer using \ref IComponent::getValue().
   * \deprecatedsince 3.4
   */
  AVOID double getValue(size_t x, size_t y);

  /**
   * Gets the position of an image pixel as a \ref IComponent::Point. It is
   * transformed with the coordinate system to the unit given by \ref
   * getCoordinateInfo(). Handles A and C value axis image components.
   *
   * \param x column of the pixel in the image
   * \param y row of the pixel in the image
   * \param missingDataValue the value returned for any missing data
   * \return the position of the pixel
   * \throws OutOfRangeException if any of the indices is out of range
   * \throws InvalidPixelFormat if template size does not match the size of the
   *         pixel format
   * \deprecated Prefer using \ref IComponent::getPoint().
   * \deprecatedsince 3.4
   */
  AVOID genistream::frame::IComponent::Point getPoint(
    size_t x,
    size_t y,
    double missingDataValue = std::numeric_limits<double>::signaling_NaN());

private:
  Image(CoordinateInfo info,
        pixelformat::PixelDataType dataType,
        size_t width,
        size_t height,
        uint8_t* data,
        bool ownsData);

  Image(CoordinateInfo info,
        pixelformat::PixelDataType dataType,
        size_t width,
        size_t height);

  void throwIfWrongPixelSize(size_t pixelSize) const;
  void throwIfOutOfBounds(size_t x, size_t y) const;
  void throwIfOutOfBound(size_t index) const;

private:
  uint8_t* mData;
  bool mOwnsData;
  pixelformat::PixelDataType mDataType;
  CoordinateInfo mInfo;
  size_t mWidth;
  size_t mHeight;
};

}}
