// Copyright 2019-2023 SICK AG. All rights reserved.
#pragma once

#include "Avoid.h"
#include "Ip4Address.h"
#include "MacAddress.h"
#include "GenIStreamDll.h"

#include <chrono>
#include <memory>
#include <vector>

namespace genistream {

class DiscoveredCamera;
class ICamera;
class ICameraScanner;
class ICachedInterfaces;

/**
 * Entry point class to discover and connect to cameras. Use \ref
 * createFromProducerFile() to create an instance.
 *
 * Discovery is performed with \ref scanForCameras(std::chrono::milliseconds)
 * and you can use one of the returned \ref DiscoveredCamera objects to connect
 * to a camera with \ref connectTo(std::shared_ptr<DiscoveredCamera>). You can
 * also use \ref connectTo(Ip4Address,std::chrono::milliseconds) or \ref
 * connectTo(MacAddress,std::chrono::milliseconds) directly with an IP or MAC
 * address.
 *
 * \note You should not create more than one instance of this class. Re-use this
 *       as a singleton if you want to connect to several cameras at once or at
 *       different occasions.
 */
class GENISTREAM_API CameraDiscovery
{
public:
  CameraDiscovery(const CameraDiscovery&) = delete;
  CameraDiscovery& operator=(const CameraDiscovery&) = delete;

  /**
   * Creates an instance of CameraDiscovery given the path to a GenTL producer
   * library file (.cti).
   */
  static std::shared_ptr<CameraDiscovery>
  createFromProducerFile(const std::string& absolutePath);

  /**
   * Creates an instance of CameraDiscovery given a \ref ICachedInterfaces
   * object.
   *
   * \lowlevel
   */
  AVOID static std::shared_ptr<CameraDiscovery>
  createFromCachedInterfaces(std::shared_ptr<ICachedInterfaces> interfaces);

  /**
   * Scans all network interfaces and returns information on found cameras.
   *
   * \param timeout timeout per network interface to scan
   */
  std::vector<std::shared_ptr<DiscoveredCamera>> scanForCameras(
    std::chrono::milliseconds timeout = std::chrono::milliseconds(500));

  /**
   * Connects to a camera given an information object, e.g., received from \ref
   * scanForCameras(std::chrono::milliseconds).
   *
   * \throws ConnectionFailedException if not able to connect
   */
  std::shared_ptr<ICamera>
  connectTo(std::shared_ptr<DiscoveredCamera> discoveredCamera);

  /**
   * Connects to a camera by IP address.
   *
   * \param ipAddress an IPv4 address, for example 192.168.0.1
   * \param timeout timeout per network interface to scan
   * \throws CameraNotFoundException if no camera is found with the given
   *         address
   * \throws ConnectionFailedException if not able to connect
   */
  std::shared_ptr<ICamera>
  connectTo(Ip4Address ipAddress,
            std::chrono::milliseconds timeout = std::chrono::milliseconds(500));

  /**
   * Connects to a camera by a mac address.
   *
   * \param macAddress MAC address of the camera to connect to
   * \param timeout timeout per network interface to scan
   * \throws CameraNotFoundException if no camera is found with the given
   *         address
   * \throws ConnectionFailedException if not able to connect
   */
  std::shared_ptr<ICamera>
  connectTo(MacAddress macAddress,
            std::chrono::milliseconds timeout = std::chrono::milliseconds(500));

  /**
   * This function can be used to reconnect to a camera when it is known to be
   * rebooting, e.g., after a firmware update.
   *
   * \note This function will close the \ref ICamera object before reconnecting.
   * \param camera the object for a camera that we lost connection to.
   * \param interval the time between each attempt to reconnect
   * \param timeout the maximum amount of time to try to reconnect
   * \return the newly connected camera object
   * \throws CameraNotFoundException if the camera is not found within the
   *         timeout
   * \throws ConnectionFailedException if not able to connect
   * \incubating
   */
  std::shared_ptr<ICamera>
  reconnect(std::shared_ptr<ICamera> camera,
            std::chrono::seconds interval = std::chrono::seconds(5),
            std::chrono::seconds timeout = std::chrono::seconds(60));

  /**
   * Temporarily sets the IP address of a camera.
   *
   * This can be used to move an unreachable camera to another subnet, so that
   * connection is possible.
   *
   * In general, this is only a temporary change of IP address. In order to make
   * the new IP address persistent, one also has to configure the camera
   * parameter `GevPersistentIPAddress`.
   *
   * \note After using this method, one must re-scan with \ref
   *       scanForCameras(std::chrono::milliseconds) to find the camera on the
   *       new IP address.
   * \param camera the camera for which to set IP address
   * \param newIpAddress the new IP address to set
   * \param newSubnetMask the new subnet mask to set
   * \param timeout to re-scan the interface where the camera was once found
   * \throws CameraNotFoundException if the camera can no longer be found on the
   *         network
   */
  void
  forceIp(std::shared_ptr<DiscoveredCamera> camera,
          Ip4Address newIpAddress,
          Ip4Address newSubnetMask,
          std::chrono::milliseconds timeout = std::chrono::milliseconds(500));

  /**
   * \return the underlying \ref ICachedInterfaces
   * \lowlevel
   */
  AVOID std::shared_ptr<ICachedInterfaces> getInterfaces();

  /**
   * Propose a suitable IP address and subnet mask for the device to match the
   * interface configuration.
   *
   * \param camera the camera for which to propose IP
   * \return proposed IP address and subnet mask
   */
  IpAddressPair proposeIp(std::shared_ptr<DiscoveredCamera> camera);

private:
  explicit CameraDiscovery(std::shared_ptr<ICachedInterfaces> interfaces);
  explicit CameraDiscovery(std::shared_ptr<ICachedInterfaces> interfaces,
                           std::shared_ptr<ICameraScanner> scanner);

private:
  std::shared_ptr<ICachedInterfaces> mInterfaces;
  std::shared_ptr<ICameraScanner> mScanner;

  friend class CameraDiscoveryTest;
};

}
