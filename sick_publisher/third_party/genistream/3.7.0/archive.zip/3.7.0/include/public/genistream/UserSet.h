// Copyright 2020-2023 SICK AG. All rights reserved.
#pragma once

#include "Avoid.h"
#include "ConfigurationDataTypes.h"
#include "GenIStreamDll.h"
#include "NodeMap.h"

namespace genistream {

/**
 * Identifier for different GenICam User Sets. Values are the same as for the
 * UserSetSelector to avoid confusion but you should not rely on this in your
 * code.
 */
enum class UserSetId
{
  DEFAULT = 0,
  USER_SET_1 = 1,
  USER_SET_2 = 2,
  USER_SET_3 = 3,
  USER_SET_4 = 4,
  USER_SET_5 = 5,
};

/** All user set identifiers in an iterable array. */
static const UserSetId allUserSetIds[] = {UserSetId::DEFAULT,
                                          UserSetId::USER_SET_1,
                                          UserSetId::USER_SET_2,
                                          UserSetId::USER_SET_2,
                                          UserSetId::USER_SET_3,
                                          UserSetId::USER_SET_4,
                                          UserSetId::USER_SET_5};

/** \return a \ref UserSetId corresponding to the name used by GenApi */
UserSetId userSetIdFromString(const std::string& genapiName);
/** \return the name of a user set, as used in GenApi */
std::string toString(UserSetId userSet);

/**
 * Earlier camera firmware versions do not support GenICam User Sets. Before
 * trying to access them on a camera with unknown firmware it is a good idea to
 * call this function to check.
 */
bool firmwareSupportsUserSets(std::shared_ptr<IAnyParameters> cameraParameters);

/**
 * Earlier camera firmware versions do not support removal of GenICam User Sets.
 */
bool firmwareSupportsUserSetDelete(
  std::shared_ptr<IAnyParameters> cameraParameters);

/*
 * Representation of a GenICam User Set, i.e., a camera parameter stored on the
 * camera.
 */
class GENISTREAM_API IUserSet
{
public:
  virtual ~IUserSet() = default;

  virtual UserSetId getId() const = 0;
  virtual std::string getName() const = 0;

  /** \return the description string for the user set */
  virtual std::string getDescription() const = 0;

  /** Sets the description string for the user set. */
  virtual void setDescription(const std::string& description) = 0;

  virtual std::string getUserSetFirmwareVersion() const = 0;

  /** \return true if the user sets exists on the camera. */
  virtual bool exists() const = 0;

  /**
   * Loads the configuration from the user set and makes it active.
   *
   * \throws GenIStreamException if the user set doesn't exist or needs
   *         migration
   */
  virtual void load() = 0;

  /**
   * Saves the current configuration to the user set.
   *
   * \throws GenIStreamException if this is the Default user set
   */
  virtual void save() = 0;

  /**
   * Deletes the user set from the camera.
   *
   * \throws GenIStreamException if this is the Default user set
   */
  virtual void remove() = 0;

  /**
   * \return the user set as complete configuration in CSV format. The same
   *         format is used for import and export
   * \see \refcpp{ICamera::importParameters()}
   *      \refcs{ICamera.ImportParametersFromFile(string)}
   * \throws GenIStreamException if this is the Default user set
   */
  virtual std::string retrieveFromCamera() const = 0;

  /**
   * Set this user set to be the one to use when the camera is started.
   *
   * \throws GenIStreamException if the user set does not exist or needs
   *         migration
   */
  virtual void useAtStartup() = 0;

  virtual bool isUsedAtStartup() const = 0;

  /**
   * \return true if the user set needs to be migrated to the current firmware
   *         version
   */
  virtual bool needsMigration() const = 0;

  /**
   * Migrates the user set to the current firmware version. The import mechanism
   * is used to re-import the configuration to the camera and thus the returned
   * ConfigurationResult may look like importing a parameter file created for
   * another firmware version.
   *
   * \return a ConfigurationResult. The result may have the status invalid even
   *         though the migration resulted in a valid configuration, this will
   *         happen if an old configuration parameter is no longer available for
   *         the current firmware.
   * \throws GenIStreamException if the migration results in configuration that
   *         is not valid
   */
  virtual ConfigurationResult migrate() = 0;
};


class GENISTREAM_API UserSet : public IUserSet
{
public:
  /** \lowlevel Prefer using \ref ICamera::openUserSet(). */
  AVOID explicit UserSet(std::shared_ptr<NodeMap> cameraNodeMap,
                         UserSetId userSetId);

  UserSetId getId() const override { return mUserSetId; }
  std::string getName() const override { return toString(mUserSetId); }
  std::string getDescription() const override;
  void setDescription(const std::string& description) override;
  std::string getUserSetFirmwareVersion() const override;
  bool exists() const override;
  void load() override;
  void save() override;
  void remove() override;
  std::string retrieveFromCamera() const override;
  void useAtStartup() override;
  bool isUsedAtStartup() const override;
  bool needsMigration() const override;
  ConfigurationResult migrate() override;

private:
  void checkExistsAndMigrated(const std::string& messageSuffix) const;

private:
  std::shared_ptr<NodeMap> mCameraNodeMap;
  UserSetId mUserSetId;
};

}
